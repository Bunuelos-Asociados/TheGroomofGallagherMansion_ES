﻿# TODO: Translation updated at 2025-10-03 10:41

translate es strings:

    # game/screens.rpy:308
    old "Back"
    new "Atrás"

    # game/screens.rpy:309
    old "History"
    new "Historial"

    # game/screens.rpy:310
    old "Skip"
    new "Saltar"

    # game/screens.rpy:311
    old "Auto"
    new "Automático"

    # game/screens.rpy:312
    old "Research"
    new "Investigación"

    # game/screens.rpy:313
    old "Save"
    new "Guardar"

    # game/screens.rpy:314
    old "Load"
    new "Cargar"

    # game/screens.rpy:315
    old "Prefs"
    new "Preferencias"

    # game/screens.rpy:367
    old "Start"
    new "Iniciar"

    # game/screens.rpy:374
    old "Save/Load"
    new "Guardar/Cargar"

    # game/screens.rpy:376
    old "Preferences"
    new "Preferencias"

    # game/screens.rpy:380
    old "End Replay"
    new "Finalizar Repetición"

    # game/screens.rpy:384
    old "Main Menu"
    new "Menú Principal"

    # game/screens.rpy:386
    old "About"
    new "Acerca de"

    # game/screens.rpy:391
    old "Help"
    new "Ayuda"

    # game/screens.rpy:397
    old "Extras"
    new "Extras"

    # game/screens.rpy:407
    old "Quit"
    new "Salir"

    # game/screens.rpy:579
    old "Return"
    new "Regresar"

    # game/screens.rpy:670
    old "Credits"
    new "Créditos"

    # game/screens.rpy:672
    old "Patrons"
    new "Patrocinadores"

    # game/screens.rpy:684
    old "Team"
    new "Equipo"

    # game/screens.rpy:686
    old "Resources"
    new "Recursos"

    # game/screens.rpy:688
    old "[config.name!t] Version [config.version!t] is made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "[config.name!t] Versión [config.version!t] realizada con {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:693
    old "The Groom of Gallagher Mansion is made possible by\n"
    new "The Groom of Gallagher Mansion es posible gracias a\n"

    # game/screens.rpy:846
    old "Page {}"
    new "Página {}"

    # game/screens.rpy:846
    old "Automatic saves"
    new "Guardados automáticos"

    # game/screens.rpy:846
    old "Quick saves"
    new "Guardados rápidos"

    # game/screens.rpy:908
    old "<<"
    new "<<"

    # game/screens.rpy:911
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:914
    old "{#quick_page}Q"
    new "{#quick_page}Q"

    # game/screens.rpy:921
    old ">>"
    new ">>"

    # game/screens.rpy:946
    old "Empty Slot"
    new "Espacio vacío"

    # game/screens.rpy:990
    old "Delete"
    new "Borrar"

    # game/screens.rpy:1230
    old "Display"
    new "Pantalla"

    # game/screens.rpy:1231
    old "Window"
    new "Ventana"

    # game/screens.rpy:1232
    old "Fullscreen"
    new "Pantalla completa"

    # game/screens.rpy:1237
    old "Unseen Text"
    new "Texto no visto"

    # game/screens.rpy:1238
    old "After Choices"
    new "Después de elecciones"

    # game/screens.rpy:1239
    old "Transitions"
    new "Transiciones"

    # game/screens.rpy:1245
    old "Toggles"
    new "Interruptores"

    # game/screens.rpy:1247
    old "Audio Titles"
    new "Títulos de audio"

    # game/screens.rpy:1251
    old "Self-Voicing"
    new "Lectura automática"

    # game/screens.rpy:1256
    old "Typeface"
    new "Tipografía"

    # game/screens.rpy:1258
    old "Sylexiad Serif"
    new "Sylexiad Serif"

    # game/screens.rpy:1259
    old "{font=gui/font/KintoSans-Medium.ttf}{size=28}Kinto{/size}{/font}"
    new "{font=gui/font/KintoSans-Medium.ttf}{size=28}Kinto{/size}{/font}"

    # game/screens.rpy:1259
    old "Change font to Kinto"
    new "Cambiar tipografía a Kinto"

    # game/screens.rpy:1261
    old "{font=gui/font/SylexiadSerifMedium.ttf}{size=38}Sylexiad Serif{/size}{/font}"
    new "{font=gui/font/SylexiadSerifMedium.ttf}{size=38}Sylexiad Serif{/size}{/font}"

    # game/screens.rpy:1262
    old "{font=gui/font/KintoSans-Medium.ttf}Kinto{/font}"
    new "{font=gui/font/KintoSans-Medium.ttf}Kinto{/font}"

    # game/screens.rpy:1266
    old "Font Size"
    new "Tamaño de fuente"

    # game/screens.rpy:1268
    old "Large"
    new "Grande"

    # game/screens.rpy:1269
    old "Regular"
    new "Normal"

    # game/screens.rpy:1276
    old "Text Color"
    new "Color del texto"

    # game/screens.rpy:1277
    old "White"
    new "Blanco"

    # game/screens.rpy:1278
    old "Cream"
    new "Crema"

    # game/screens.rpy:1282
    old "Line Spacing"
    new "Espaciado de líneas"

    # game/screens.rpy:1283
    old "Taller"
    new "Mayor"

    # game/screens.rpy:1312
    old "Text Speed"
    new "Velocidad del texto"

    # game/screens.rpy:1316
    old "Auto-Forward Time"
    new "Tiempo de avance automático"

    # game/screens.rpy:1320
    old "Textbox Opacity"
    new "Opacidad del cuadro de texto"

    # game/screens.rpy:1328
    old "Music Volume"
    new "Volumen de música"

    # game/screens.rpy:1335
    old "Sound Volume"
    new "Volumen de sonido"

    # game/screens.rpy:1341
    old "Test"
    new "Prueba"

    # game/screens.rpy:1345
    old "Voice Volume"
    new "Volumen de voz"

    # game/screens.rpy:1354
    old "Mute Voices"
    new "Silenciar voces"

    # game/screens.rpy:1362
    old "Mute All"
    new "Silenciar todo"

    # game/screens.rpy:1678
    old "Keyboard"
    new "Teclado"

    # game/screens.rpy:1680
    old "Mouse"
    new "Ratón"

    # game/screens.rpy:1684
    old "Gamepad"
    new "Mando"

    # game/screens.rpy:1697
    old "Enter"
    new "Enter"

    # game/screens.rpy:1698
    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    # game/screens.rpy:1701
    old "Space"
    new "Espacio"

    # game/screens.rpy:1702
    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    # game/screens.rpy:1705
    old "Arrow Keys"
    new "Flechas"

    # game/screens.rpy:1706
    old "Navigate the interface."
    new "Navega por la interfaz."

    # game/screens.rpy:1709
    old "Escape"
    new "Escape"

    # game/screens.rpy:1710
    old "Accesses the game menu."
    new "Accede al menú del juego."

    # game/screens.rpy:1713
    old "Ctrl"
    new "Ctrl"

    # game/screens.rpy:1714
    old "Skips dialogue while held down."
    new "Salta el diálogo mientras se mantiene presionado."

    # game/screens.rpy:1717
    old "Tab"
    new "Tab"

    # game/screens.rpy:1718
    old "Toggles dialogue skipping."
    new "Activa/desactiva el salto de diálogo."

    # game/screens.rpy:1721
    old "Page Up"
    new "Av Pág"

    # game/screens.rpy:1722
    old "Rolls back to earlier dialogue."
    new "Retrocede al diálogo anterior."

    # game/screens.rpy:1725
    old "Page Down"
    new "Re Pág"

    # game/screens.rpy:1726
    old "Rolls forward to later dialogue."
    new "Avanza al diálogo siguiente."

    # game/screens.rpy:1730
    old "Hides the user interface."
    new "Oculta la interfaz de usuario."

    # game/screens.rpy:1734
    old "Takes a screenshot."
    new "Toma una captura de pantalla."

    # game/screens.rpy:1738
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa/desactiva la {a=https://www.renpy.org/l/voicing}lectura automática{/a}."

    # game/screens.rpy:1742
    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."

    # game/screens.rpy:1748
    old "Left Click"
    new "Clic izquierdo"

    # game/screens.rpy:1752
    old "Middle Click"
    new "Clic central"

    # game/screens.rpy:1756
    old "Right Click"
    new "Clic derecho"

    # game/screens.rpy:1760
    old "Mouse Wheel Up\nClick Rollback Side"
    new "Rueda del ratón arriba\nClic en lado de retroceso"

    # game/screens.rpy:1764
    old "Mouse Wheel Down"
    new "Rueda del ratón abajo"

    # game/screens.rpy:1771
    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nBotón A/Inferior"

    # game/screens.rpy:1775
    old "Left Trigger\nLeft Shoulder"
    new "Gatillo izquierdo\nHombro izquierdo"

    # game/screens.rpy:1779
    old "Right Shoulder"
    new "Hombro derecho"

    # game/screens.rpy:1784
    old "D-Pad, Sticks"
    new "D-Pad, Palancas"

    # game/screens.rpy:1788
    old "Start, Guide"
    new "Inicio, Guía"

    # game/screens.rpy:1792
    old "Y/Top Button"
    new "Y/Botón superior"

    # game/screens.rpy:1795
    old "Calibrate"
    new "Calibrar"

    # game/screens.rpy:1861
    old "Yes"
    new "Sí"

    # game/screens.rpy:1862
    old "No "
    new "No "

    # game/screens.rpy:1921
    old "Skipping"
    new "Saltando"
