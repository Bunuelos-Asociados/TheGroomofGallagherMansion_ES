﻿# TODO: Translation updated at 2025-10-03 10:41

translate es strings:

# game/extras.rpy:30
    old "{size=70}WARNING{/s}"
    new "{size=70}ADVERTENCIA{/s}"

# game/extras.rpy:31
    old "This game is intended for audiences aged 18 years or older, and incorporates mature themes including:"
    new "Este juego está destinado a audiencias de 18 años o más, e incorpora temas maduros que incluyen:"

# game/extras.rpy:42
    old "Blood\n\nDisability & Ableism\n\nForced Marriage"
    new "Sangre\n\nDiscapacidad y Ableismo\n\nMatrimonio Forzado"

# game/extras.rpy:48
    old "Body Horror\n\nDivorce\n\nMedical Error\n\nTraumatic Flashbacks"
    new "Horror Corporal\n\nDivorcio\n\nError Médico\n\nRecuerdos Traumáticos"

# game/extras.rpy:55
    old "Child Abuse\n\nDissociation\n\nSelf-Harm\n\nViolence"
    new "Abuso Infantil\n\nDisociación\n\nAutolesión\n\nViolencia"

# game/extras.rpy:62
    old "Death\n\nDrug Use\n\nSexual Content"
    new "Muerte\n\nConsumo de Drogas\n\nContenido Sexual"

# game/extras.rpy:68
    old "By clicking Confirm, you affirm that you are an adult of 18 years or older willing to interact with such content."
    new "Al hacer clic en Confirmar, afirmas que eres un adulto de 18 años o más dispuesto a interactuar con este tipo de contenido."

# game/extras.rpy:72
    old "Confirm"
    new "Confirmar"

# game/extras.rpy:104
    old "Accessibility Settings"
    new "Configuración de Accesibilidad"

# game/extras.rpy:105
    old "These options can be adjusted at any time in the menu."
    new "Estas opciones se pueden ajustar en cualquier momento desde el menú."

# game/extras.rpy:342
    old "Achievements"
    new "Logros"

# game/extras.rpy:344
    old "Portraits"
    new "Retratos"

# game/extras.rpy:346
    old "Photos"
    new "Fotos"

# game/extras.rpy:348
    old "Momentos"
    new "Momentos"

# game/extras.rpy:350
    old "Music Box"
    new "Caja de Música"

# game/extras.rpy:354
    old "Honeymoon"
    new "Luna de Miel"

# game/extras.rpy:663
    old "Mission Debriefing"
    new "Informe de Misión"

# game/extras.rpy:663
    old "Went over the details of the field mission"
    new "Se revisaron los detalles de la misión de campo"

# game/extras.rpy:663
    old "Wedding Planner"
    new "Planificador de Bodas"

# game/extras.rpy:663
    old "Planned out your own wedding"
    new "Organizaste tu propia boda"

# game/extras.rpy:663
    old "Trivia Master"
    new "Maestro de Trivia"

# game/extras.rpy:663
    old "Knowledge is power!"
    new "¡El conocimiento es poder!"

# game/extras.rpy:663
    old "Thorough Investigation"
    new "Investigación Exhaustiva"

# game/extras.rpy:663
    old "Looked for hidden passages in the mansion"
    new "Buscaste pasadizos ocultos en la mansión"

# game/extras.rpy:663
    old "Spill The Beans"
    new "Revelar el Secreto"

# game/extras.rpy:663
    old "Revealed who your co-conspirator was"
    new "Revelaste quién era tu co-conspirador"

# game/extras.rpy:663
    old "For The Truth"
    new "Por La Verdad"

# game/extras.rpy:663
    old "Solved the mystery of the Gallagher Mansion"
    new "Resolvió el misterio de la Mansión Gallagher"

# game/extras.rpy:663
    old "For Love"
    new "Por Amor"

# game/extras.rpy:663
    old "Fulfilled a hundred year old wish for happiness"
    new "Cumpliste un deseo centenario de felicidad"

# game/extras.rpy:663
    old "For Science"
    new "Por Ciencia"

# game/extras.rpy:663
    old "Fulfilled your original mission and scored one with the bestie"
    new "Cumpliste tu misión original y conquistaste a tu mejor amigo"

# game/extras.rpy:663
    old "Forever"
    new "Por Siempre"

# game/extras.rpy:663
    old "Death is just a new beginning!"
    new "¡La muerte es solo un nuevo comienzo!"

# game/extras.rpy:663
    old "In Love With Love"
    new "Enamorado del Amor"

# game/extras.rpy:663
    old "Isn't it such a beautiful thing?"
    new "¿No es algo hermoso?"

# game/extras.rpy:926
    old "Skip End Credits"
    new "Saltar Créditos Finales"


