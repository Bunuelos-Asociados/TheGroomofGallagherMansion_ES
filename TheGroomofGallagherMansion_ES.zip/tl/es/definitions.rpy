﻿# TODO: Translation updated at 2025-10-03 10:41

translate es strings:

    # game/definitions.rpy:633
    old "Vice Presidente"
    new "Vice Presidente"

