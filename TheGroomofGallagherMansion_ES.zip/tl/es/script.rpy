﻿# TODO: Translation updated at 2025-10-03 10:41

# game/script.rpy:82
translate es start_9610fbe2:
    
    $your_name = "Vicepresidente"
    $u = Character("Presidente del Sindicato", color="#fff", who_outlines=[(absolute(4), "#000", absolute(1), absolute(1))], ctc="ctc_blink", ctc_position="fixed", voice_tag="Union Chairperson")
    $o = Character("Oficiante", color="#fff", who_outlines=[(absolute(4), "#000", absolute(1), absolute(1))], ctc="ctc_blink", ctc_position="fixed", voice_tag="Officiator")



    # "The stories I've heard about the old Gallagher Mansion..."
    "Las historias que he oído sobre la antigua Mansión Gallagher..."

# game/script.rpy:84
translate es start_d3b35a55:

    # "The tales and whispers and rumors..."
    "Los cuentos, susurros y rumores..."

# game/script.rpy:86
translate es start_a8558554:

    # "Home to decadence and luxury in the days of yore, now abandoned out of fear and left to rot..."
    "Hogar de decadencia y lujo en los días pasados, ahora abandonado por miedo y dejado a pudrirse..."

# game/script.rpy:88
translate es start_1ddf0ac6:

    # "The obfuscated photos, the promise of lost inheritance..."
    "Las fotos borrosas, la promesa de una herencia perdida..."

# game/script.rpy:90
translate es start_fddb45e3:

    # "And a history stained by misfortune and blood, spilt in greed and ambition..."
    "Y una historia manchada de desgracias y sangre, derramada por la codicia y la ambición..."

# game/script.rpy:92
translate es start_8f28d0a7:

    # "None of them have done this place justice. Quite the opposite, in fact. They all made it sound much more exciting."
    "Ninguna de ellas ha hecho justicia a este lugar. De hecho, todo lo contrario. Todas lo hicieron sonar mucho más emocionante."

# game/script.rpy:94
translate es start_bffc7f18:

    # "A quick look at Gallagher Mansion doesn't suggest anything special— it's just one of many other ancient, abandoned, century-plus old estates around here..."
    "Una rápida mirada a la Mansión Gallagher no sugiere nada especial—es solo una de muchas otras antiguas propiedades abandonadas, de más de un siglo, por aquí..."

# game/script.rpy:96
translate es start_a54d01fa:

    # "I never got the hype. These decrepit old places litter this town like fallen leaves no one has bothered to rake up."
    "Nunca entendí el hype. Estos lugares en ruinas llenan esta ciudad como hojas caídas que nadie se ha molestado en recoger."

# game/script.rpy:98
translate es start_4cad1856:

    # "It's a spot for college dorks to drink and hope no one notices."
    "Es un lugar para nerds universitarios que quieren beber y esperar a que nadie los note."

# game/script.rpy:100
translate es start_6c3c42c3:

    # "An occasional haunted house for young adventurers, and home to a few basic ghost stories that some of the older locals take pride in; heritage and horror in one neat package."
    "Una casa embrujada ocasional para jóvenes aventureros, y hogar de algunas historias de fantasmas básicas de las que algunos locales mayores se sienten orgullosos; patrimonio y horror en un paquete ordenado."

# game/script.rpy:102
translate es start_6ec64051:

    # "You'd never notice anything extraordinary just by looking at it. Sure; close to midnight, an eerie old mansion far off the main road will spook you well enough — especially if you're alone."
    "Nunca notarías nada extraordinario solo con mirarlo. Claro; cerca de la medianoche, una vieja mansión tenebrosa alejada de la carretera principal te asustará lo suficiente —especialmente si estás solo."

# game/script.rpy:104
translate es start_b5e2241d:

    # "Luckily I'm neither of those things. Well, technically I am {i}alone{/i} but not {i}by myself{/i}."
    "Afortunadamente, no soy ninguna de esas cosas. Bueno, técnicamente estoy en {i}solitario{/i} pero no {i}por mi cuenta{/i}."

# game/script.rpy:106
translate es start_828096cb:

    # "I fondle the phone in my hands for comfort while trying to avoid the thorns of the rose; no need to prick myself just yet, according to Taylor."
    "Acaricio el teléfono en mis manos para reconfortarme mientras trato de evitar las espinas de la rosa; según Taylor, no necesito pincharme todavía."

# game/script.rpy:108
translate es start_ba6c1286:

    # "Gallagher Mansion is {i}abandoned.{/i} It's been abandoned for most of its existence. "
    "La Mansión Gallagher está {i}abandonada.{/i} Ha estado abandonada la mayor parte de su existencia."

# game/script.rpy:110
translate es start_e16dcd2b:

    # "So why doesn't it look like a pile of splinters? Why are the grounds not overgrown with weeds and vines and poison ivy?"
    "Entonces, ¿por qué no parece un montón de astillas? ¿Por qué los terrenos no están llenos de maleza, enredaderas y hiedra venenosa?"

# game/script.rpy:112
translate es start_9a8c28a4:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0001.ogg"
    # t "Team, do you copy? What's the situation on the field? Over!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0001.ogg"
    t "Equipo, ¿me copian? ¿Cuál es la situación en el campo? ¡Cambio!"

# game/script.rpy:116
translate es start_56872b21:

    # p "Doing fine, Taylor. In fact, I'm a little disappointed... I was hoping for something more than a light breeze, maybe a darker and stormier night to really set the mood."
    p "Todo bien, Taylor. De hecho, me decepciona un poco... esperaba algo más que una ligera brisa, tal vez una noche más oscura y tormentosa para realmente poner el ambiente."

# game/script.rpy:118
translate es start_a20cefa7:

    # "..."
    "..."

# game/script.rpy:120
translate es start_5d05982e:

    # p "... Over."
    p "... Cambio."

# game/script.rpy:122
translate es start_7cc5270c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0002.ogg"
    # t "Heh, don't jinx yourself now, buddy. Optimal weather conditions will make the mission easier for you and me both. Over."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0002.ogg"
    t "Je, no te gafes ahora, amigo. Condiciones climáticas óptimas harán la misión más fácil para los dos. Cambio."

# game/script.rpy:126
translate es start_1df1031d:

    # p "You know, you don't need to say \"over\" when we're on a phone call, right? We can both talk and hear each other at the same time... Over."
    p "Sabes, no necesitas decir \"cambio\" cuando estamos en una llamada, ¿verdad? Podemos hablar y escucharnos al mismo tiempo... Cambio."

# game/script.rpy:128
translate es start_5666d6ea:

    # "A pause. I could almost feel Taylor's pout on the other side of the line."
    "Una pausa. Casi podía sentir el puchero de Taylor al otro lado de la línea."

# game/script.rpy:130
translate es start_8eb1f3d6:

    # p "... I'm serious though. So far this may as well be an evening stroll."
    p "... Hablando en serio. Hasta ahora esto podría considerarse un paseo nocturno."

# game/script.rpy:132
translate es start_cf303cc3:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0003.ogg"
    # t "Keep your guard up. If my sources are accurate, I'm like 90%% confident we'll find something in this place."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0003.ogg"
    t "Mantén tu guardia en alto. Si mis fuentes son correctas, estoy como 90%% seguro de que encontraremos algo en este lugar."

# game/script.rpy:142
translate es start_60f98534:

    # "The voice in my ear is Taylor Potts, my long time dorm bestie at Zephyr University, and the President of the college's Occult History & Sciences Investigation Club — aka the OHSIC."
    "La voz en mi oído es Taylor Potts, mi mejor amigo de dormitorio desde hace mucho en la Universidad Zephyr, y Presidente del Club de Investigación en Historia y Ciencias Ocultas del colegio —aka el OHSIC."

# game/script.rpy:144
translate es start_90dda9e6:

    # "Meanwhile there's me, the Vice President, if only because I'm the only other member who consistently shows up to the meetings. And that's mostly because I feel bad for Taylor putting in all this work for the club."
    "Mientras tanto, estoy yo, Vicepresidente, solo por ser la única otra persona que asiste consistentemente a las reuniones. Y eso es mayormente porque me da pena que Taylor haga todo este trabajo para el club."

# game/script.rpy:146
translate es start_4eca393a:

    # "That's why I'm here tonight, of course... Why I'm at the steps of Gallagher Mansion, dressed to some very uncomfortable nines, with a desperate ghost hunter walking me through a desperate plan."
    "Por eso estoy aquí esta noche, claro... Por eso estoy en los escalones de la Mansión Gallagher, vestiendo algo muy incómodo, con un cazafantasmas desesperado guiándome a través de un plan desesperado."

# game/script.rpy:148
translate es start_0ef7b857:

    # "Long story short, the Student Union is a meeting away from dropping support for the OHSIC."
    "Resumiendo, la Unión Estudiantil está a una reunión de retirar el apoyo al OHSIC."

# game/script.rpy:150
translate es start_cc3481ab:

    # "We've had trouble retaining membership for a while now, and the facility we use for our meetings is \"utterly wasted on the two of us.\""
    "Hemos tenido problemas para mantener membresía por un tiempo, y la instalación que usamos para nuestras reuniones está \"totalmente desperdiciada para los dos que somos.\""

# game/script.rpy:152
translate es start_cbd45912:

    # "... Their words, not mine."
    "... Sus palabras, no las mías."

# game/script.rpy:160
translate es start_e6663c43:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0004.ogg"
    # t "What do you {i}mean{/i} you're done funding the club!? The OHSIC is an incredibly important resource for students to explore their spirituality! Their heritage! Their culture!!!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0004.ogg"
    t "¿Qué {i}quieres decir{/i} con que dejas de financiar el club!? ¡El OHSIC es un recurso increíblemente importante para que los estudiantes exploren su espiritualidad! ¡Su patrimonio! ¡Su cultura!!!"

# game/script.rpy:164
translate es start_7d8d5e9c:

    # voice "audio/voice/" + persistent.lang_voice + "/UnionChairman_0001.ogg"
    # u "Listen Mr. Potts, I've pulled enough strings letting you have the club for so long in the first place, but I can't defend you when we're not seeing results."
    voice "audio/voice/" + persistent.lang_voice + "/UnionChairman_0001.ogg"
    u "Escucha Sr. Potts, ya he movido suficientes hilos para que tengas el club tanto tiempo, pero no puedo defenderte si no vemos resultados."

# game/script.rpy:170
translate es start_1e491251:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0005.ogg"
    # t "You still have a freakin' anime club! All they do is watch movies and spend money on imported snacks! That's got to be violating some kind of rule about appropriating funds or something!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0005.ogg"
    t "¡Aún tienes un maldito club de anime! ¡Todo lo que hacen es ver películas y gastar dinero en snacks importados! ¡Eso debe violar alguna regla sobre apropiación de fondos o algo así!"

# game/script.rpy:174
translate es start_6ad7c385:

    # voice "audio/voice/" + persistent.lang_voice + "/UnionChairman_0002.ogg"
    # u "First of all, it's the Japanese Culture & Heritage Club. Secondly, they actually retain regular members, as do many other clubs."
    voice "audio/voice/" + persistent.lang_voice + "/UnionChairman_0002.ogg"
    u "Primero, es el Club de Cultura y Patrimonio Japonés. Segundo, realmente mantienen miembros regulares, como muchos otros clubes."

# game/script.rpy:180
translate es start_f6999ec1:

    # voice "audio/voice/" + persistent.lang_voice + "/UnionChairman_0003.ogg"
    # u "If you can't engage with the students of this university, you're not really providing anything of value."
    voice "audio/voice/" + persistent.lang_voice + "/UnionChairman_0003.ogg"
    u "Si no puedes involucrar a los estudiantes de esta universidad, realmente no estás ofreciendo nada de valor."

# game/script.rpy:184
translate es start_e612de94:

    # voice "audio/voice/" + persistent.lang_voice + "/UnionChairman_0004.ogg"
    # u "Space is a premium, too. You know that everyone on campus is going gaga for that newly proposed Juggling Club, and they'd appreciate a room that's barely being used as it is—"
    voice "audio/voice/" + persistent.lang_voice + "/UnionChairman_0004.ogg"
    u "El espacio también es un bien escaso. Sabes que todos en el campus están emocionados por el recién propuesto Club de Malabares, y apreciarían una sala que apenas se usa—"

# game/script.rpy:190
translate es start_fbf9c211:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0006.ogg"
    # t "T-the {i}Juggling Club{/i}? The {b}Juggling Club!?{/b} You can't do that to us!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0006.ogg"
    t "¿E-el {i}Club de Malabares{/i}? ¡¿El {b}Club de Malabares!?{/b} ¡No pueden hacernos eso!"

# game/script.rpy:194
translate es start_e933ba59:

    # "I think it's the Juggling Club part that's gotten to him the most. Taylor's logic? Clowns juggle things. Clowns are scary and evil. Therefore, the Juggling Club by default is scary and evil."
    "Creo que es la parte del Club de Malabares lo que más le afecta. ¿La lógica de Taylor? Los payasos hacen malabares. Los payasos son aterradores y malvados. Por lo tanto, el Club de Malabares por defecto es aterrador y malvado."

# game/script.rpy:198
translate es start_a67edee7:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0007.ogg"
    # t "Th-there's gotta be another way, please! What do you need us to do to save the club?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0007.ogg"
    t "H-hay que haber otra manera, ¡por favor! ¿Qué necesitan que hagamos para salvar el club?"

# game/script.rpy:202
translate es start_2b99a7ab:

    # voice "audio/voice/" + persistent.lang_voice + "/UnionChairman_0005.ogg"
    # u "All you need is a few more members. Doesn't matter how you do it as long as you can show us that the OSICO is still relevant to the student body."
    voice "audio/voice/" + persistent.lang_voice + "/UnionChairman_0005.ogg"
    u "Todo lo que necesitan son algunos miembros más. No importa cómo lo logres mientras puedas mostrarnos que el OHSIC sigue siendo relevante para los estudiantes."

# game/script.rpy:208
translate es start_f9ccf6d5:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0008.ogg"
    # t "OHSIC..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0008.ogg"
    t "OHSIC..."

# game/script.rpy:212
translate es start_0c75d96d:

    # voice "audio/voice/" + persistent.lang_voice + "/UnionChairman_0006.ogg"
    # u "Mmhmm. Yes. That."
    voice "audio/voice/" + persistent.lang_voice + "/UnionChairman_0006.ogg"
    u "Mmhmm. Sí. Eso."

# game/script.rpy:220
translate es start_815734dc:

    # "That's how it went down yesterday morning, according to Taylor. Later that afternoon, before I could start going through the motions for our \"meeting\" agenda..."
    "Así fue como sucedió ayer por la mañana, según Taylor. Más tarde esa tarde, antes de que pudiera empezar con los trámites de nuestra agenda de \"reunión\"..."

# game/script.rpy:228
translate es start_33cfac36:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0009.ogg"
    # t "Okay okay, here's the plan. You know that old house way out there on the corner of town... That old Gallagher place where all those deaths and murders happened ages ago?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0009.ogg"
    t "Está bien, está bien, aquí está el plan. Sabes esa vieja casa allá en la esquina del pueblo... Ese antiguo lugar Gallagher donde murieron y asesinaron a mucha gente hace siglos?"

# game/script.rpy:234
translate es start_82de0677:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0010.ogg"
    # t "We've never checked it out. We thought it was too boring, too vanilla... but no! Maybe we made a mistake trying to find new things when we've left the biggest stone in town unturned."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0010.ogg"
    t "Nunca la habíamos revisado. Pensábamos que era demasiado aburrida, demasiado normal... ¡pero no! Quizá cometimos un error buscando cosas nuevas cuando dejamos la piedra más grande del pueblo sin mover."

# game/script.rpy:240
translate es start_b0cfd7fd:

    # p "Okay, but has anything changed about the place since the last time we looked at it—"
    p "Está bien, pero ¿ha cambiado algo en el lugar desde la última vez que lo vimos—"

# game/script.rpy:244
translate es start_391cd9b9:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0011.ogg"
    # t "Tomorrow we're gonna investigate the old dump. I just {i}know{/i} there's something we can find in there. It's our last hope."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0011.ogg"
    t "Mañana vamos a investigar el viejo basurero. Sé {i}seguro{/i} que hay algo que podemos encontrar allí. Es nuestra última esperanza."

# game/script.rpy:250
translate es start_9efc603c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0012.ogg"
    # t "Vice Prez, tonight we're hitting the books! Research like your life depends on it!!!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0012.ogg"
    t "Vice Presi, ¡esta noche vamos a estudiar como si nuestra vida dependiera de ello!!!"

# game/script.rpy:258
translate es start_e3cc1be0:

    # "And by \"we're investigating,\" Taylor meant that {i}I{/i} go there in person by myself while he provides intel via earpiece back at HQ."
    "Y con \"investigar,\" Taylor quiso decir que {i}yo{/i} voy allí en persona mientras él proporciona información a través del auricular desde HQ."

# game/script.rpy:260
translate es start_dd3ad1b2:

    # "HQ is Taylor's car, of course... Maybe we could paint it like Ecto-1 and get a few members that way?"
    "HQ es el auto de Taylor, claro... Tal vez podríamos pintarlo como el Ecto-1 y conseguir algunos miembros así?"

# game/script.rpy:264
translate es start_0bb52586:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0013.ogg"
    # t "Uhhh, status? You've been a little quiet. Over."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0013.ogg"
    t "Uhhh, ¿estado? Has estado un poco en silencio. Cambio."

# game/script.rpy:268
translate es start_a54831ff:

    # "... Back to the \"over\" thing, huh?"
    "... Otra vez con lo de \"cambio,\" ¿eh?"

# game/script.rpy:270
translate es start_c3e2e42b:

    # p "Oh, uh. I'm doing okay, just thinking."
    p "Oh, eh. Estoy bien, solo pensando."

# game/script.rpy:272
translate es start_5b57477c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0014.ogg"
    # t "Don't get cold feet now, buddy. We need you now more than ever!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0014.ogg"
    t "No tengas miedo ahora, amigo. ¡Te necesitamos más que nunca!"

# game/script.rpy:276
translate es start_5c233c58:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0015.ogg"
    # t "You've dealt with the paranormal before, and you've rocked their world! Are you worried about your lines?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0015.ogg"
    t "Has lidiado con lo paranormal antes, ¡y les has hecho temblar el mundo! ¿Estás preocupandote por tus líneas?"

# game/script.rpy:280
translate es start_b8c8e464:

    # p "No, I've got the script down alright. Though..."
    p "No, tengo el guion bien aprendido. Aunque..."

# game/script.rpy:288
translate es start_51e4585c:

    # p "Well, my tuxedo is a little hard to breathe in. Can't I loosen up a few buttons? Take off this cummerbund? Or at least take off the jacket for a moment?"
    p "Bueno, mi esmoquin me dificulta un poco respirar. ¿No puedo aflojar algunos botones? ¿Quitarme este fajín? ¿O al menos quitarme la chaqueta un momento?"

# game/script.rpy:294
translate es start_4235fea0:

    # p "Well, I'm worried about tripping on my gown. Can I at least take my heels off? Or roll the skirt up a few inches? And do I still have to do the veil thing?"
    p "Bueno, me preocupa tropezar con mi vestido. ¿Puedo al menos quitarme los tacones? ¿O subir un poco la falda? ¿Y todavía tengo que hacer lo del velo?"

# game/script.rpy:300
translate es start_bc173bcd:

    # p "My wedding attire is a lot to get used to. Like, the top is a vest and long coat while the bottom is a huge frilly skirt, so it's really new to me? I do like it though."
    p "Mi atuendo de boda es mucho a lo que acostumbrarme. La parte superior es un chaleco y abrigo largo mientras que la inferior es una enorme falda con volantes, así que es realmente nuevo para mí. Pero me gusta."

# game/script.rpy:302
translate es start_5d05982e_1:

    # p "... Over."
    p "... Cambio."

# game/script.rpy:304
translate es start_b48387b6:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0016.ogg"
    # t "Sorry, no can do. You gotta look the part for when you fall into the cold, dead arms of Elias Gallagher. Over."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0016.ogg"
    t "Lo siento, no se puede. Debes lucir el papel cuando caigas en los fríos y muertos brazos de Elias Gallagher. Cambio."

# game/script.rpy:308
translate es start_68a305f0:

    # p "Understood. I'll look as classically ravishing as possible, over."
    p "Entendido. Luciré tan clásicamente deslumbrante como sea posible, cambio."

# game/script.rpy:310
translate es start_971f55b5:

    # "As I say that, I quietly adjust my outfit anyway. Taylor can't see me over the earpiece, anyhow. I may as well be comfortable... And maybe even a little disheveled, as befits someone with my sorrowful tale."
    "Mientras digo eso, ajusto mi atuendo en silencio de todos modos. Taylor no puede verme por el auricular. Al menos puedo estar comodamente... Y quizá incluso un poco con el pelo desordenado, como corresponde a alguien con mi triste historia."

# game/script.rpy:312
translate es start_bd504ae7:

    # p "I'm at the door."
    p "Estoy en la puerta."

# game/script.rpy:314
translate es start_df9c947e:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0017.ogg"
    # t "How's the rose?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0017.ogg"
    t "¿Cómo está la rosa?"

# game/script.rpy:318
translate es start_858ae7ca:

    # p "Immaculate."
    p "Impecable."

# game/script.rpy:320
translate es start_9d875a1e:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0018.ogg"
    # t "Then go for it, buddy. You're about to change our lives."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0018.ogg"
    t "Entonces ve por ello, amigo. Estás a punto de cambiar nuestras vidas."

# game/script.rpy:324
translate es start_05152ae5:

    # p "Can I ask you one more question before I start the mission?"
    p "¿Puedo hacerte una última pregunta antes de comenzar la misión?"

# game/script.rpy:326
translate es start_7fb60540:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0019.ogg"
    # t "Shoot."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0019.ogg"
    t "Dispara."

# game/script.rpy:330
translate es start_996a15ee:

    # p "Did like, court entertainers or whatever still exist in Victorian times?"
    p "¿Existían, como, los artistas de corte o algo así en la época victoriana?"

# game/script.rpy:332
translate es start_70e3ebca:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0020.ogg"
    # t "I... don't really know if they did... or why you're asking me that."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0020.ogg"
    t "Yo... realmente no sé si existían... ni por qué me preguntas eso."

# game/script.rpy:336
translate es start_4fad79e3:

    # p "I'm just saying, what if Elias Gallagher isn't the only ghost left in this mansion? What if I run into his personal clown—"
    p "Solo digo, ¿y si Elias Gallagher no es el único fantasma que queda en esta mansión? ¿Y si me topo con su payaso personal—"

# game/script.rpy:340
translate es start_d05096de:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0021.ogg"
    # t "G-g-g-ghost clown!? No! Why would you even suggest such a thing!? I don't want to think about it!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0021.ogg"
    t "¡P-p-p-payaso fantasma!? ¡No! ¿Por qué sugerirías tal cosa!? ¡No quiero pensarlo!"

# game/script.rpy:344
translate es start_bb4207e3:

    # p "But I could be in danger!\nUnless maybe, it was a nice clown who could cook—"
    p "¡Pero podría estar en peligro!\nA menos que, tal vez, fuera un payaso amable que supiera cocinar—"

# game/script.rpy:346
translate es start_0a88f377:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0022.ogg"
    # t "Quit stalling and start the mission already!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0022.ogg"
    t "¡Deja de retrasarte y comienza la misión ya!"

# game/script.rpy:350
translate es start_32031952:

    # "There goes Taylor hammering in the \"No Fun Allowed\" sign. Ah well."
    "Ahí va Taylor poniendo el letrero de \"Prohibido Diversión.\" Ah, bueno."

# game/script.rpy:354
translate es start_be46ad05:

    # "I turn my attention back to the facade of the mansion; it really does look too well-maintained for an abandoned building..."
    "Vuelvo mi atención a la fachada de la mansión; realmente parece demasiado bien mantenida para ser un edificio abandonado..."

# game/script.rpy:358
translate es start_a7f14e23:

    # "The cool brass handle turns, and the door glides open."
    "La fría manija de bronce gira, y la puerta se desliza abierta."

# game/script.rpy:370
translate es start_2a1fac64:

    # "The first thing I notice is how stale the air tastes inside the manor. The second thing I notice is how cold it is in here, even compared to the light breeze outside."
    "Lo primero que noto es el sabor rancio del aire dentro de la mansión. Lo segundo es lo frío que está aquí, incluso comparado con la ligera brisa afuera."

# game/script.rpy:372
translate es start_beb17293:

    # "The atmosphere is unnaturally frigid, though not enough to make me bail out to grab a jacket, so long as I'm quick."
    "La atmósfera es anormalmente helada, aunque no lo suficiente para que salga corriendo a agarrar una chaqueta, siempre que sea rápido."

# game/script.rpy:374
translate es start_036dd6dd:

    # "This place has certainly seen better days."
    "Este lugar ciertamente ha visto días mejores."

# game/script.rpy:376
translate es start_18f3e2bf:

    # p "Hacker voice. I'm in."
    p "Voz de hacker. Estoy dentro."

# game/script.rpy:378
translate es start_61737b06:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0023.ogg"
    # t "How's it lookin' in there, bud?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0023.ogg"
    t "¿Cómo se ve ahí dentro,  compi"

# game/script.rpy:382
translate es start_622efeee:

    # p "A lot more promising now that I'm inside... Perfectly ripe for a haunting, complete with a creepy portrait upstairs. In fact, you'd probably have an asthma attack with all this dust."
    p "Mucho más prometedor ahora que estoy adentro... Perfecto para un fantasma, completo con un retrato espeluznante arriba. De hecho, probablemente tendrías un ataque de asma con todo este polvo."

# game/script.rpy:384
translate es start_5e084710:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0024.ogg"
    # t "Is your sixth sense tingling?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0024.ogg"
    t "¿Tu sexto sentido está vibrando?"

# game/script.rpy:388
translate es start_4f6ba873:

    # p "I don't know why, but it is super cold in here. As long as I'm in and out of here fast, I don't think I need to worry about it too much."
    p "No sé por qué, pero hace mucho frío aquí. Mientras entre y salga rápido, no creo que deba preocuparme demasiado."

# game/script.rpy:390
translate es start_8cd52249:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0025.ogg"
    # t "That's reasonable. I think it's time to summon a ghost, then."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0025.ogg"
    t "Eso es razonable. Creo que es hora de invocar a un fantasma, entonces."

# game/script.rpy:394
translate es start_5b72cbe4:

    # p "Roger that."
    p "Entendido."

# game/script.rpy:396
translate es start_f5311055:

    # "About time I put that single year of high school theater to good use."
    "Ya era hora de poner ese único año de teatro de secundaria a buen uso."

# game/script.rpy:398
translate es start_5d3fdb26:

    # "Well, here we go... Prick my finger on one of the thorns, scatter a few of the rose petals around, then cue the monologue..."
    "Bueno, allá vamos... Pinchar mi dedo con una de las espinas, esparcir algunos pétalos de rosa, luego empezar el monólogo..."

# game/script.rpy:400
translate es start_0fd8d639:

    # "I suck in a breath as the thorn pricks my index, channeling the pain into a sufficiently hammy performance."
    "Inhalo mientras la espina pincha mi índice, canalizando el dolor en una actuación suficientemente dramática."

# game/script.rpy:402
translate es start_95ad85c1:

    # p "Alas, my poor, aching heart!"
    p "¡Ay, mi pobre y doliente corazón!"

# game/script.rpy:406
translate es start_d693ac74:

    # "I raise my arms towards the ceiling and choke out a few dramatic sobs before falling to my knees and burying my face into my hands. The acoustics in this foyer are pretty impressive, if I do say so myself."
    "Levanto los brazos hacia el techo y suelto unos sollozos dramáticos antes de caer de rodillas y enterrar mi rostro en mis manos. La acústica en este vestíbulo es bastante impresionante, si me permiten decirlo."

# game/script.rpy:410
translate es start_1a4e0a23:

    # "I clutch at my chest with one hand and lay the back of the other against my forehead, crying out into the empty halls before collapsing into a heap. The noise reverberates against the walls in a cacophony of echoes."
    "Me aferro al pecho con una mano y apoyo la otra en la frente, gritando en los pasillos vacíos antes de desplomarme en un montón. El ruido reverbera contra las paredes en una cacofonía de ecos."

# game/script.rpy:414
translate es start_35e239c5:

    # "I clutch at my chest with one hand and raise the other towards the ceiling, choking out a few dramatic sobs before collapsing into a heap. The acoustics in this foyer accentuate the cacophony of echoes."
    "Me aferro al pecho con una mano y levanto la otra hacia el techo, soltando unos sollozos dramáticos antes de desplomarme en un montón. La acústica de este vestíbulo acentúa la cacofonía de ecos."

# game/script.rpy:416
translate es start_6e6b302d:

    # p "Woe is me, to have been abandoned so coldly at the altar! Why did the love of my life forsake me so?"
    p "¡Ay de mí, por que me abandonaron tan fríamente en el altar! ¿Por qué el amor de mi vida me abandonó así?"

# game/script.rpy:418
translate es start_cb198ef5:

    # p "Today was set to be the most joyous day of my mortal existence, and yet, all I feel is the pull of despair into my darkest days thus! Oh, woe upon such an unfortunate soul as mine!"
    p "Hoy debía ser el día más alegre de mi existencia mortal, ¡y aun así, todo lo que siento es la atracción de la desesperación hacia mis días más oscuros! ¡Oh, desdicha sobre un alma tan desafortunada como la mía!"

# game/script.rpy:420
translate es start_ed675315:

    # "I can hear some slow clapping and a stifled guffaw from the earpiece."
    "Puedo escuchar algunos aplausos lentos y una risa contenida desde el auricular."

# game/script.rpy:422
translate es start_196a4a20:

    # p "All I wanted in life was to know the warmth of a lover's touch. Won't anyone take pity on me?"
    p "Todo lo que quería en la vida era conocer la calidez del toque de un amante. ¿Nadie se compadecerá de mí?"

# game/script.rpy:424
translate es start_47dcddb2:

    # "I let loose another pathetic sound of anguish while plucking off more petals, and close my eyes."
    "Suelto otro sonido patético de angustia mientras arranco más pétalos, y cierro los ojos."

# game/script.rpy:426
translate es start_329680c5:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0026.ogg"
    # t "This is my cue to throw tomatoes at the stage, right?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0026.ogg"
    t "¿Es mi turno de lanzar tomates al escenario, verdad?"

# game/script.rpy:430
translate es start_4afee97d:

    # p "{i}Tomatoes mean the performance sucks... I'm doing great, dummy.{/i}"
    p "{i}Los tomates significan que la actuación apesta... Lo estoy haciendo genial, tonto.{/i}"

# game/script.rpy:432
translate es start_24be6113:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0027.ogg"
    # t "Heh, alright, alright. Keep up the good work then, buddy ol' pal."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0027.ogg"
    t "Je, está bien, está bien. Entonces sigue con el buen trabajo, compi."

# game/script.rpy:438
translate es start_18485e6a:

    # "I glance around my surroundings. I almost feel like the painting on the second floor is judging me silently, but it must be my imagination."
    "Miro a mi alrededor. Casi siento que la pintura del segundo piso me está juzgando en silencio, pero debe ser mi imaginación."

# game/script.rpy:442
translate es start_177117b6:

    # p "Why should I continue to live a life unfulfilled? I almost think it better to sleep an eternity, dreaming forevermore, rather than to suffer this cruel reality!"
    p "¿Por qué debería seguir viviendo una vida sin cumplir? Casi pienso que sería mejor dormir una eternidad, soñando por siempre, que sufrir esta cruel realidad."

# game/script.rpy:444
translate es start_d7d5bb9f:

    # "I pluck off the last of the rose petals and cast away the stem. The deep crimson speckles of my blood glimmer starkly in the light of the moon, now dripping through the cobweb-covered windows."
    "Arranco los últimos pétalos de la rosa y tiro el tallo. Las profundas motas carmesí de mi sangre brillan intensamente a la luz de la luna, ahora filtrándose por las ventanas cubiertas de telarañas."

# game/script.rpy:446
translate es start_e9d698d6:

    # p "Perhaps, I shall die as I lived— alone, with naught but my own sorrow! If God or some kind and gentle soul has lent their ears to my pleas, then take me now!"
    p "Quizá, moriré como he vivido— en soledad, sin más que mi propia tristeza. Si Dios o algún alma amable y gentil ha prestado oído a mis súplicas, ¡llévenme ahora!"

# game/script.rpy:448
translate es start_89aea6c5:

    # "I lower my head and let a few more tears flow down my cheeks. The ritual is now complete."
    "Inclino la cabeza y dejo que unas lágrimas más rueden por mis mejillas. El ritual está ahora completo."

# game/script.rpy:450
translate es start_045ebe2e:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0028.ogg"
    # t "Truly, a riveting performance. 10/10, Oscar worthy, or... whatever."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0028.ogg"
    t "Verdaderamente, una actuación fascinante. 10/10, digna de un Oscar, o... lo que sea."

# game/script.rpy:454
translate es start_ca1dfd80:

    # p "{i}Hey, don't kill the atmosphere.{/i}"
    p "{i}Oye, no arruines la atmósfera.{/i}"

# game/script.rpy:458
translate es start_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:460
translate es start_fcccd1d2:

    # "The temperature suddenly drops, to the point where it feels like my blood is freezing in my veins. Something inside my brain screams at my legs to run, but I can't move."
    "La temperatura baja de repente, hasta el punto de sentir que mi sangre se congela en mis venas. Algo dentro de mi cerebro grita a mis piernas que corran, pero no puedo moverme."

# game/script.rpy:468
translate es start_a1ed65da:

    # "I raise my head just in time to see the rose petals scattered across the foyer swirling up into the air, coalescing back onto the stem I threw at the foot of the steps."
    "Levanto la cabeza justo a tiempo para ver los pétalos de rosa esparcidos por el vestíbulo girando en el aire, recomponiéndose sobre el tallo que arrojé al pie de los escalones."

# game/script.rpy:471
translate es start_828abfc9:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0001.ogg"
    # un "Alack, alack, what blood is this, which stains the stony entrance of this sepulcher?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0001.ogg"
    un "¡Ay de mí, qué sangre es esta, que mancha la entrada de piedra de este sepulcro?"

# game/script.rpy:474
translate es start_e8a70531:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0029.ogg"
    # t "W-wait, who was that? ... What's happening over there?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0029.ogg"
    t "E-espera, ¿quién era ese? ... ¿Qué está pasando allá?"

# game/script.rpy:492
translate es start_5c75a7ff:

    # "My jaw drops as the vague shape of a man materializes from the top of the staircase. My mouth is suddenly too dry to form a coherent response."
    "Mi mandíbula cae al materializarse la vaga figura de un hombre desde la cima de la escalera. Mi boca está de repente demasiado seca para formar una respuesta coherente."

# game/script.rpy:503
translate es start_c9983839:

    # "Elias Gallagher, in all his undead and ephemeral glory, is gliding down the steps towards me."
    "Elias Gallagher, en toda su gloria no-muerta y efímera, deslizándose por los escalones hacia mí."

# game/script.rpy:505
translate es start_8016e85a:

    # "... Holy shit. "
    "... Santo cielo."

# game/script.rpy:507
translate es start_14a822c9:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0002.ogg"
    # e "Fresh blood in my esteemed estate, stained on a red rose no less. A tragic sight indeed..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0002.ogg"
    e "Sangre fresca en mi estimada mansión, manchando una rosa roja, nada menos. Una visión trágica, sin duda..."

# game/script.rpy:515
translate es start_30ef384b:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0003.ogg"
    # e "But not quite so tragic as the one who stands before me. Pray tell..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0003.ogg"
    e "Pero no tan trágica como quien se encuentra frente a mí. Por favor, dime..."

# game/script.rpy:523
translate es start_d408d05b:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0004.ogg"
    # e "Who are you, and what is your purpose here?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0004.ogg"
    e "¿Quién eres y cuál es tu propósito aquí?"

# game/script.rpy:527
translate es start_4edae746:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0030.ogg"
    # t "Bud? Hey bud, what's goin' on over there?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0030.ogg"
    t "¿Compi? Oye, compi, ¿qué pasa allá?"

# game/script.rpy:531
translate es start_04600e3c:

    # p "Elias Gallagher, lord of this manor, my name is..."
    p "Elias Gallagher, señor de esta mansión, mi nombre es..."

# game/script.rpy:544
translate es name_input_0b800aa1:

    # "No, I ought to tell him my name. He's got to call me something."
    "No, debo decirle mi nombre. Tiene que llamarme de alguna manera."

# game/script.rpy:548
translate es name_input_0d2b2aa5:

    # p "... and I am but..."
    p "... y yo solo soy..."

# game/script.rpy:557
translate es name_input_cb5d252c:

    # p "I am [your_name], a groom who was abandoned at the altar on the day of my own wedding."
    p "Soy [your_name], un novio que fue abandonado en el altar el día de su propia boda."

# game/script.rpy:564
translate es name_input_a906e6dd:

    # p "I am [your_name], a bride who was abandoned at the altar on the day of my own wedding."
    p "Soy [your_name], una novia que fue abandonada en el altar el día de su propia boda."

# game/script.rpy:571
translate es name_input_aeea55b3:

    # p "I am [your_name], and I was betrothed to one who abandoned me at the altar on the day of our wedding."
    p "Soy [your_name], y estaba comprometide a alguien que me abandonó en el altar el día de nuestra boda."

# game/script.rpy:573
translate es name_input_a8c29f6f:

    # p "With a broken heart in my chest and tears in my eyes, I sought solace in a quiet place away from the ceremony, and found myself here."
    p "Con un corazón roto en el pecho y lágrimas en los ojos, busqué consuelo en un lugar tranquilo lejos de la ceremonia, y me encontré aquí."

# game/script.rpy:599
translate es parent_name_react_61812b7c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0005.ogg"
    # e "[your_name]? That's ah..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0005.ogg"
    e "[your_name]? Eso es eh..."

# game/script.rpy:603
translate es parent_name_react_44255d2b:

    # "Elias cocks his head at me."
    "Elias inclina la cabeza hacia mí."

# game/script.rpy:605
translate es parent_name_react_a50bf7b5:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0006.ogg"
    # e "A peculiar name, but it is yours."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0006.ogg"
    e "Un nombre peculiar, pero es tuyo."

# game/script.rpy:611
translate es parent_name_react_c62b0c77:

    # "Elias seems to mouth the word [your_name] with hesitance, freezing momentarily before shaking his head."
    "Elias parece pronunciar la palabra [your_name] con vacilación, congelándose momentáneamente antes de sacudir la cabeza."

# game/script.rpy:613
translate es parent_name_react_b3f5aa10:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0007.ogg"
    # e "{i}No, [your_name] is not an uncommon name, it wouldn't be the first nor last time someone was...{/i}"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0007.ogg"
    e "{i}No, [your_name] no es un nombre inusual, no sería la primera ni la última vez que alguien fue...{/i}"

# game/script.rpy:617
translate es parent_name_react_250f34ae:

    # "He straightens up and clears his throat."
    "Se endereza y aclara su garganta."

# game/script.rpy:621
translate es parent_name_react_9098a7e2:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0008.ogg"
    # e "[your_name]?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0008.ogg"
    e "[your_name]?"

# game/script.rpy:625
translate es parent_name_react_975f3d14:

    # "Elias stares blankly at me."
    "Elias me mira fijamente."

# game/script.rpy:627
translate es parent_name_react_d81e306d:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0009.ogg"
    # e "{i}[your_name]... such a curious coincidence...{/i}"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0009.ogg"
    e "{i}[your_name]... qué coincidencia tan curiosa...{/i}"

# game/script.rpy:631
translate es parent_name_react_2bc53f91:

    # "He shakes his head and smiles sadly."
    "Sacude la cabeza y sonríe con tristeza."

# game/script.rpy:635
translate es parent_name_react_7d8e369a:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0010.ogg"
    # e "[your_name], you poor dear..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0010.ogg"
    e "[your_name], pobre de ti..."

# game/script.rpy:641
translate es parent_name_react_9964902d:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0011.ogg"
    # e closed_sad oh_sad "You and I are not at all dissimilar indeed. I am well acquainted with tragedy, and know that your wounds need tending to at once."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0011.ogg"
    e closed_sad oh_sad "Tú y yo no somos tan diferentes en absoluto. Estoy bien familiarizado con la tragedia y sé que tus heridas necesitan atención de inmediato."

# game/script.rpy:652
translate es parent_name_react_08a07ca3:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0012.ogg"
    # e "Tell me, [your_name], would you like to forget the cur who broke your heart?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0012.ogg"
    e "Dime, [your_name], ¿te gustaría olvidar al canalla que rompió tu corazón?"

# game/script.rpy:656
translate es parent_name_react_d772d475:

    # "Hook, line, and sinker."
    "Enganche, línea y plomo."

# game/script.rpy:663
translate es parent_name_react_ed49cad0:

    # p "Oh, yes! I would not hesitate if there was such a way to ease my sorrows, but I fear it won't be a simple matter."
    p "¡Oh, sí! No dudaría si hubiera una manera de aliviar mis penas, pero temo que no será un asunto sencillo."

# game/script.rpy:665
translate es parent_name_react_2404f0ca:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0013.ogg"
    # e "Nonsense my dear. I can melt away your anxiety and regrets, for it is within my power as long as you remain inside these four walls. Now, will you accept this rose, darling?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0013.ogg"
    e "Tonterías, Cariño. Puedo derretir tu ansiedad y tus remordimientos, pues está dentro de mi poder mientras permanezcas dentro de estas cuatro paredes. Ahora, ¿aceptarás esta rosa, querida?"

# game/script.rpy:674
translate es parent_name_react_66872eed:

    # "He holds out the rose I shredded up not too long ago, the blood gone from the petals and thorns absent from the stem."
    "Sostiene la rosa que trituré no hace mucho, la sangre ya desaparecida de los pétalos y sin espinas en el tallo."

# game/script.rpy:676
translate es parent_name_react_58a70fdc:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0031.ogg"
    # t "Hey! Hey [your_name]! What's going on there? The line's going haywire over here!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0031.ogg"
    t "¡Oye! ¡Oye [your_name]! ¿Qué pasa allí? ¡La línea está fallando aquí!"

# game/script.rpy:680
translate es parent_name_react_d102e74a:

    # "I reach up towards Elias' to take the rose from his hand and our knuckles brush against one another."
    "Alzo la mano hacia la de Elias para tomar la rosa y nuestros nudillos se rozan."

# game/script.rpy:686
translate es parent_name_react_2a633711:

    # "His touch is deathly cold."
    "Su toque es mortalmente frío."

# game/script.rpy:688
translate es parent_name_react_a13599c9:

    # p "I will."
    p "Lo haré."

# game/script.rpy:690
translate es parent_name_react_2d6a2a47:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0032.ogg"
    # t "I-I'm requesting a report! Do you uh, do you need backup? [your_name], answer me!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0032.ogg"
    t "E-estoy solicitando un informe! ¿Necesitas refuerzos? [your_name], ¡respóndeme!"

# game/script.rpy:694
translate es parent_name_react_5292f818:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0014.ogg"
    # e "Wonderful, darling."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0014.ogg"
    e "Maravilloso, querida."

# game/script.rpy:704
translate es parent_name_react_74870541:

    # "Elias' hand glides up to my cheek, caressing it gently and phasing through my skin."
    "La mano de Elias se desliza hacia mi mejilla, acariciándola suavemente y atravesando mi piel."

# game/script.rpy:710
translate es parent_name_react_0045f099:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0015.ogg"
    # e "... Now even death won't do us part."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0015.ogg"
    e "... Ahora ni la muerte nos separará."

# game/script.rpy:726
translate es parent_name_react_35fdb377:

    # "The distant cry of a carnival mystery..."
    "El lejano llanto de un misterio de carnaval..."

# game/script.rpy:728
translate es parent_name_react_a185b442:

    # "A long wail, a pained moan, looping through the walls and dancing on the flowers..."
    "Un largo lamento, un gemido doloroso, recorriendo las paredes y bailando sobre las flores..."

# game/script.rpy:730
translate es parent_name_react_b1cb8180:

    # "The petals shake, stamens and pistils tremble, and perfume avalanches upon me; a billion scents as strong as a forgotten sun..."
    "Los pétalos tiemblan, estambres y pistilos se estremecen, y el perfume cae sobre mí; mil millones de aromas tan fuertes como un sol olvidado..."

# game/script.rpy:734
translate es parent_name_react_91e9b112:

    # "Strong enough to sting my eyes."
    "Lo suficientemente fuerte como para hacer arder mis ojos."

# game/script.rpy:736
translate es parent_name_react_79e84ebf:

    # p "Agggh...?"
    p "Agggh...?"

# game/script.rpy:740
translate es parent_name_react_a7a2cc4b:

    # "I rub my eyes and open them to a blue ceiling."
    "Me froto los ojos y los abro hacia un techo azul."

# game/script.rpy:742
translate es parent_name_react_43512767:

    # p "What the hell? Where am I...?"
    p "¿Qué demonios? ¿Dónde estoy...?"

# game/script.rpy:744
translate es parent_name_react_758e1091:

    # "As I ask, the wails and moans shaking my bones cease. They were my breath... just my breath."
    "Mientras pregunto, los lamentos y gemidos que sacudían mis huesos cesan. Era mi aliento... solo mi aliento."

# game/script.rpy:746
translate es parent_name_react_e90a21f1:

    # "And that carnival mystery?"
    "¿Y ese misterio del carnaval?"

# game/script.rpy:748
translate es parent_name_react_bd7766f4:

    # "...!!"
    "...!!"

# game/script.rpy:750
translate es parent_name_react_4689f061:

    # "The phone's still ringing, but it's not in any of my pockets! This wedding garb was a huge mistake."
    "¡El teléfono sigue sonando, pero no está en ninguno de mis bolsillos! Este atuendo de boda fue un gran error."

# game/script.rpy:754
translate es parent_name_react_08feba08:

    # "My hands scamper around the sheets of the bed, searching for my phone, trying to answer Tayl—"
    "Mis manos recorren las sábanas de la cama, buscando el teléfono, tratando de contestar a Tayl—"

# game/script.rpy:756
translate es parent_name_react_3a8b150d:

    # "Hang on... Bed?"
    "Espera... ¿Cama?"

# game/script.rpy:758
translate es parent_name_react_d27f8038:

    # "My eyes remember to look at more than the ceiling, and along with the rest of my senses waking up and processing information; sure enough I've found myself in some ancient bedroom."
    "Mis ojos recuerdan mirar más que el techo, y junto con el resto de mis sentidos despertando y procesando información; efectivamente me encuentro en algún dormitorio antiguo."

# game/script.rpy:762
translate es parent_name_react_2aab0005:

    # "I catch a flicker of light amongst the disheveled sheets, and snatch it to me. My phone's screen glows like a comforting little lantern."
    "Atrapé un destello de luz entre las sábanas desordenadas, y lo tomo para mí. La pantalla de mi teléfono brilla como un pequeño farol reconfortante."

# game/script.rpy:764
translate es parent_name_react_f7ea57a8:

    # "I accept Taylor's call, and—"
    "Acepto la llamada de Taylor, y—"

# game/script.rpy:766
translate es parent_name_react_9429b5eb:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0033.ogg"
    # t "Oh god, [your_name]! I've tried you like 50 times already since the call dropped! What the hell happened!?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0033.ogg"
    t "¡Oh dios, [your_name]! ¡Te he llamado como 50 veces desde que se cortó la llamada! ¿Qué demonios pasó!?"

# game/script.rpy:770
translate es parent_name_react_bc586b8a:

    # p "I don't... I don't really know. Where am I?"
    p "No... realmente no sé. ¿Dónde estoy?"

# game/script.rpy:772
translate es parent_name_react_97e76641:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0034.ogg"
    # t "Are you still in the mansion!?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0034.ogg"
    t "¿Todavía estás en la mansión!?"

# game/script.rpy:776
translate es parent_name_react_466cab97:

    # "Somehow, I had forgotten where I was... What had happened. My cheek twinged with the memory of a chill, ethereal touch."
    "De alguna manera, había olvidado dónde estaba... Qué había pasado. Mi mejilla punzó con el recuerdo de un toque etéreo y frío."

# game/script.rpy:778
translate es parent_name_react_aa52d7ee:

    # "Elias... That touch from Elias..."
    "Elias... Ese toque de Elias..."

# game/script.rpy:780
translate es parent_name_react_3f83955b:

    # "A GHOST TOUCHED ME."
    "UN FANTASMA ME TOCÓ."

# game/script.rpy:782
translate es parent_name_react_da30a7fc:

    # "... Right? That actually did happen, and it wasn't just some sleep deprived hallucination I had from all of Taylor's ramblings, right?"
    "... ¿Verdad? Eso realmente pasó, y no fue solo una alucinación por falta de sueño causada por todos los disparates de Taylor, ¿verdad?"

# game/script.rpy:784
translate es parent_name_react_aa6d0783:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0035.ogg"
    # t "Hey, hey [your_name], don't clam up now!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0035.ogg"
    t "¡Oye, oye [your_name], no te quedes en silencio ahora!"

# game/script.rpy:788
translate es parent_name_react_3e48a7dd:

    # p "O-oh. Um. I guess I'm uh, not outside at least."
    p "O-oh. Eh. Supongo que al menos no estoy afuera."

# game/script.rpy:790
translate es parent_name_react_ea39b29e:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0036.ogg"
    # t "Describe your location."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0036.ogg"
    t "Describe tu ubicación."

# game/script.rpy:794
translate es parent_name_react_eb44e8bb:

    # p "Well, everything around me is still dimly lit in a morose shade of blue, so that's a good sign. ... Well, \"good\" might not be the right word..."
    p "Bueno, todo a mi alrededor sigue iluminado tenuemente con un tono moroso de azul, así que es una buena señal. ... Bueno, \"buena\" quizá no sea la palabra correcta..."

# game/script.rpy:796
translate es parent_name_react_cfd175ec:

    # p "And the decor certainly looks the pa— Wait, hang on."
    p "Y la decoración ciertamente se ve como la pa— Espera, un momento."

# game/script.rpy:798
translate es parent_name_react_40712597:

    # "This {i}is{/i} still inside the mansion, right? Lights and decor are one thing, but this room sure doesn't look like it's moments from falling apart."
    "Esto {i}es{/i} todavía dentro de la mansión, ¿verdad? Luces y decoración son una cosa, pero esta habitación ciertamente no parece a punto de derrumbarse."

# game/script.rpy:802
translate es parent_name_react_6ebbea67:

    # "The sheets I'm lying upon are coarse but in perfect condition; as fresh as the day they were woven on some state-of-the-art pedal loom."
    "Las sábanas sobre las que estoy son ásperas pero en perfecto estado; tan frescas como el día en que fueron tejidas en algún telar moderno de pedal."

# game/script.rpy:804
translate es parent_name_react_266fbd39:

    # "The mattress holds my weight with a sense of duty, and the pillows couldn't be fluffier."
    "El colchón sostiene mi peso con un sentido de responsabilidad, y las almohadas no podrían ser más mullidas."

# game/script.rpy:806
translate es parent_name_react_8711062d:

    # "The paint on the walls, which were peeling away in the foyer, holds immaculately tight here with not a chip in sight. No cobwebs or holes or even a speck of dust floating upon the air."
    "La pintura de las paredes, que se estaba desprendiendo en el vestíbulo, se mantiene impecable aquí sin un solo chip a la vista. Sin telarañas ni agujeros ni siquiera una mota de polvo flotando en el aire."

# game/script.rpy:808
translate es parent_name_react_cc9ccbeb:

    # "The portraits and paintings all hang straight and untorn, with gilded golden frames. The pots and vases, without any cracks in their porcelain."
    "Los retratos y pinturas cuelgan rectos y sin rasgaduras, con marcos dorados. Las macetas y jarrones, sin grietas en su porcelana."

# game/script.rpy:810
translate es parent_name_react_e9a6e196:

    # "Even the air is far cry from moss and bird's nests if you ignore the stale taste."
    "Incluso el aire está lejos del musgo y los nidos de pájaros si ignoras el sabor rancio."

# game/script.rpy:812
translate es parent_name_react_9c199d6e:

    # "And now that I'm calmer, I also notice that I'm wearing a pair of soft, silken gloves I don't recall bringing with me when I came in. Were these a gift from Elias?"
    "Y ahora que estoy más en calma, también noto que llevo un par de guantes suaves de seda que no recuerdo haber traído conmigo al entrar. ¿Fueron un regalo de Elias?"

# game/script.rpy:814
translate es parent_name_react_38c28a19:

    # p "Hey, hang on. Look at this bedroom!"
    p "Espera. ¡Mira este dormitorio!"

# game/script.rpy:816
translate es parent_name_react_291c4b7f:

    # "I take a quick set of photos, and upload them to Taylor."
    "Tomo un rápido conjunto de fotos y las subo a Taylor."

# game/script.rpy:818
translate es parent_name_react_2924fda4:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0037.ogg"
    # t "Wait, a bedroom?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0037.ogg"
    t "¿Espera, un dormitorio?"

# game/script.rpy:822
translate es parent_name_react_cfe5d59b:

    # p "I guess. It's a lot nicer than the foyer! Nothing's falling apart, nothing's stained..."
    p "Supongo. ¡Es mucho más agradable que el vestíbulo! Nada se está cayendo, nada está manchado..."

# game/script.rpy:824
translate es parent_name_react_e5571f24:

    # p "It does look like part of the same house though. Same general decor."
    p "Sin embargo, parece parte de la misma casa. Misma decoración general."

# game/script.rpy:826
translate es parent_name_react_f596d723:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0038.ogg"
    # t "Huh... maybe the door was locked and nobody got in? This place is a known party hub, after all... Maybe the coeds and whoever else wrecked everything they could reach, but... They just couldn't get into here."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0038.ogg"
    t "Hmm... tal vez la puerta estaba cerrada y nadie entró? Este lugar es un conocido centro de fiestas, después de todo... Tal vez las estudiantes y quien sea rompieron todo lo que pudieron alcanzar, pero... simplemente no pudieron entrar aquí."

# game/script.rpy:830
translate es parent_name_react_a4599256:

    # "That seems... unlikely."
    "Eso parece... poco probable."

# game/script.rpy:832
translate es parent_name_react_9f7b27a4:

    # "A century of no one visiting would still do damage to a locked room! It's not like it's sealed away from the rest of the world."
    "¡Un siglo sin visitas aún dañaría una habitación cerrada! No es como si estuviera sellada del resto del mundo."

# game/script.rpy:834
translate es parent_name_react_ae0f2bf4:

    # "Unless..."
    "A menos que..."

# game/script.rpy:836
translate es parent_name_react_04b1a555:

    # "Was it just this room? A special place for me?"
    "¿Fue solo esta habitación? ¿Un lugar especial para mí?"

# game/script.rpy:838
translate es parent_name_react_9b8f1aeb:

    # p "Hey Taylor, can I ask you for a favor?"
    p "Oye Taylor, ¿puedo pedirte un favor?"

# game/script.rpy:840
translate es parent_name_react_85c59f06:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0039.ogg"
    # t "Yeah, what's up?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0039.ogg"
    t "Sí, ¿qué pasa?"

# game/script.rpy:844
translate es parent_name_react_7494f679:

    # p "Can you like... brief me on the mission again?"
    p "¿Puedes... ponerme al día sobre la misión otra vez?"

# game/script.rpy:846
translate es parent_name_react_e1f2ff6f:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0040.ogg"
    # t "... You're kidding, right?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0040.ogg"
    t "... Estás bromeando, ¿verdad?"

# game/script.rpy:852
translate es parent_name_react_fc7318dc:

    # p "I just woke up and I'm pretty sure there's a ghost floating around eager to meet me, so... come on."
    p "Acabo de despertar y tengo seguridad de que hay un fantasma flotando por ahí deseando conocerme, así que... vamos."

# game/script.rpy:854
translate es parent_name_react_77cf9985:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0041.ogg"
    # t "Ugh, yeah alright, you're right. Let's play 20 Questions to catch you up to speed here."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0041.ogg"
    t "Ugh, sí, está bien, tienes razón. Juguemos a 20 Preguntas para ponerte al corriente."

# game/script.rpy:870
translate es twentyq_fc3a6351:

    # p "Why am I here?"
    p "¿Por qué estoy aquí?"

# game/script.rpy:872
translate es twentyq_e2fe8ab1:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0042.ogg"
    # t "You're really asking me— ugh, sorry [your_name]."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0042.ogg"
    t "¿De verdad me estás preguntando—ugh, lo siento [your_name]."

# game/script.rpy:876
translate es twentyq_3a214916:

    # "Taylor inhales deeply before continuing."
    "Taylor inhala profundamente antes de continuar."

# game/script.rpy:878
translate es twentyq_7c076dc6:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0043.ogg"
    # t "You're on a field mission to investigate Gallagher Mansion so we can find evidence that ghosts exist, therefore proving that the OHSIC still has value to Zephyr University's Student Union."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0043.ogg"
    t "Estás en una misión de campo para investigar la Mansión Gallagher, para que podamos encontrar evidencia de que los fantasmas existen, probando así que el OHSIC aún tiene valor para la Unión de Estudiantes de la Universidad Zephyr."

# game/script.rpy:882
translate es twentyq_efa138b8:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0044.ogg"
    # t "Besides finding a ghost, we're also looking to see if we can figure out where that old Gallagher fortune might be. Treasure hunting isn't our primary goal, but it's worth keeping an eye out for."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0044.ogg"
    t "Además de encontrar un fantasma, también buscamos ver si podemos descubrir dónde podría estar esa vieja fortuna de los Gallagher. Buscar tesoros no es nuestro objetivo principal, pero vale la pena estar atentos."

# game/script.rpy:886
translate es twentyq_b8048393:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0045.ogg"
    # t "The newspaper clippings we found always said how huge the inheritance was, but some assets were never accounted for in the banks. Rumor has it that the Gallaghers kept part of the fortune somewhere in the estate."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0045.ogg"
    t "Los recortes de periódico que encontramos siempre decían lo enorme que era la herencia, pero algunos activos nunca fueron contabilizados en los bancos. Se rumorea que los Gallagher guardaron parte de la fortuna en algún lugar de la mansión."

# game/script.rpy:890
translate es twentyq_e3124a25:

    # p "That sounds about right, thanks for the recap."
    p "Eso suena correcto, gracias por el resumen."

# game/script.rpy:898
translate es twentyq_1b94d357:

    # p "So who exactly were the Gallaghers in the grand scheme of things?"
    p "Entonces, ¿quiénes eran exactamente los Gallagher en el gran esquema de las cosas?"

# game/script.rpy:900
translate es twentyq_9163b9ad:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0046.ogg"
    # t "The Gallaghers were a well-off military family from Europe who came to America in the mid-1800s. Archibald Gallagher, the patriarch of the family, found success as a cornmeal baron."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0046.ogg"
    t "Los Gallagher eran una familia militar acomodada de Europa que llegó a América a mediados de 1800. Archibald Gallagher, el patriarca de la familia, tuvo éxito como barón del harina de maíz."

# game/script.rpy:904
translate es twentyq_995e10ae:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0047.ogg"
    # t "He married a woman named Mildred and together, they had a total of seven children. All of the Gallaghers were quite exceptional, except for..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0047.ogg"
    t "Se casó con una mujer llamada Mildred y juntos tuvieron un total de siete hijos. Todos los Gallagher eran bastante excepcionales, excepto..."

# game/script.rpy:908
translate es twentyq_a5023010:

    # p "Elias..."
    p "Elias..."

# game/script.rpy:910
translate es twentyq_a3a3b9ff:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0048.ogg"
    # t "Elias was the black sheep of the family. All of his other siblings were born strong and healthy, but Elias' birth came with a lot of complications."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0048.ogg"
    t "Elias era la oveja negra de la familia. Todos sus demás hermanos nacieron fuertes y sanos, pero el nacimiento de Elias tuvo muchas complicaciones."

# game/script.rpy:914
translate es twentyq_81806cfd:

    # p "He was bedridden for most of his life, wasn't he?"
    p "Estuvo postrado en cama la mayor parte de su vida, ¿verdad?"

# game/script.rpy:916
translate es twentyq_88c91a25:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0049.ogg"
    # t "Pretty much the epitome of the sickly Victorian child trope."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0049.ogg"
    t "Prácticamente el epítome del niño enfermizo victoriano estereotípico."

# game/script.rpy:920
translate es twentyq_0f5ad320:

    # p "I don't think you should put it that way..."
    p "No creo que debas decirlo así..."

# game/script.rpy:922
translate es twentyq_cbd2a2ea:

    # "I can almost hear Taylor's shrug from the earpiece."
    "Casi puedo escuchar el encogimiento de hombros de Taylor por el auricular."

# game/script.rpy:930
translate es twentyq_e144218e:

    # p "How did the Gallaghers all die?"
    p "¿Cómo murieron todos los Gallagher?"

# game/script.rpy:932
translate es twentyq_512ff03c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0050.ogg"
    # t "A lot of rumors say it was some kind of curse, but no one can agree on {i}why{/i} they were cursed to begin with."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0050.ogg"
    t "Muchos rumores dicen que fue una especie de maldición, pero nadie se pone de acuerdo en {i}por qué{/i} fueron malditos para empezar."

# game/script.rpy:936
translate es twentyq_37f447c8:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0051.ogg"
    # t "The eldest child died first in a horse accident or something? After that it was a chain of freak accidents in short succession, completely unrelated to the previous deaths."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0051.ogg"
    t "¿El hijo mayor murió primero en un accidente con un caballo o algo así? Después fue una cadena de accidentes extraños en rápida sucesión, completamente sin relación con las muertes anteriores."

# game/script.rpy:940
translate es twentyq_87f8263c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0052.ogg"
    # t "But without fail it would always kill the next eldest child like a line of dominos, hitting the rest of them in some pretty gruesome ways."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0052.ogg"
    t "Pero sin falta, siempre mataba al siguiente hijo mayor como una línea de dominó, afectando al resto de maneras bastante horribles."

# game/script.rpy:944
translate es twentyq_1bb1508a:

    # p "Yikes..."
    p "Vaya..."

# game/script.rpy:946
translate es twentyq_505a863e:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0053.ogg"
    # t "I think Archibald and Mildred Gallagher weren't too happy about having to write Elias down as their sole heir once the others were gone, but somehow he'd managed to dodge the curse..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0053.ogg"
    t "Creo que Archibald y Mildred Gallagher no estaban muy contentos de tener que dejar a Elias como su único heredero una vez que los demás se habían ido, pero de alguna manera él logró esquivar la maldición..."

# game/script.rpy:950
translate es twentyq_86e25dc8:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0054.ogg"
    # t "Then not long after amending the will, the parents drowned in a bridge collapse on what was supposed to be a leisurely carriage ride. Same energy as scented candles setting fire to your apartment."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0054.ogg"
    t "Luego, no mucho después de enmendar el testamento, los padres se ahogaron en un colapso de un puente durante lo que se suponía sería un paseo en carruaje relajado. La misma energía que unas velas aromáticas incendiando tu apartamento."

# game/script.rpy:954
translate es twentyq_cbcf5112:

    # p "Talk about depressing."
    p "Eso sí es deprimente."

# game/script.rpy:956
translate es twentyq_e7e627e3:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0055-1.ogg"
    # t "There was — still is — plenty of speculation about Elias spinning elaborate murder schemes to take down his family."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0055-1.ogg"
    t "Hubo — y todavía hay — mucha especulación sobre Elias creando elaborados planes de asesinato para acabar con su familia."

# game/script.rpy:960
translate es twentyq_94fb6116:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0055-2.ogg"
    # t "But the thing is, Elias had few people to write letters to, and even fewer people who'd write back."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0055-2.ogg"
    t "Pero el hecho es que Elias tenía pocas personas a quienes escribir cartas, y aún menos que respondieran."

# game/script.rpy:964
translate es twentyq_cac32758:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0056.ogg"
    # t "Elias became a permanent shut-in after becoming the head of the Gallagher estate. Eh, I'd probably do that too if it happened to me."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0056.ogg"
    t "Elias se volvió un ermitaño permanente tras convertirse en jefe de la mansión Gallagher. Eh, probablemente yo haría lo mismo si me pasara."

# game/script.rpy:968
translate es twentyq_405cd2bc:

    # p "Sheesh, no kidding."
    p "Vaya, sin bromas."

# game/script.rpy:976
translate es twentyq_cc29c8fd:

    # p "Elias himself was murdered, long after the Gallagher curse had axed off the rest of his family. But who killed him?"
    p "Elias mismo fue asesinado, mucho después de que la maldición Gallagher eliminara al resto de su familia. Pero, ¿quién lo mató?"

# game/script.rpy:978
translate es twentyq_145edf4b:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0057.ogg"
    # t "That would be Violet and Gerard Dupont."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0057.ogg"
    t "Eso sería Violet y Gerard Dupont."

# game/script.rpy:982
translate es twentyq_92116884:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0058.ogg"
    # t "Gerard was the Gallagher groundskeeper, and after the rest of the family died, he decided to get a little... ambitious. Don't think that guy was gay though? Otherwise, I imagine he would have gone after Elias himself."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0058.ogg"
    t "Gerard era el jardinero de los Gallagher, y después de que muriera el resto de la familia, decidió volverse un poco... ambicioso. No creo que ese tipo fuera gay, ¿verdad? De lo contrario, me imagino que habría ido tras Elias él mismo."

# game/script.rpy:986
translate es twentyq_1f3f7948:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0059.ogg"
    # t "So he introduced his sister, Violet, to Elias as a fellow heiress without a partner. You can guess what happened next, right?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0059.ogg"
    t "Entonces presentó a su hermana, Violet, a Elias como otra heredera sin pareja. Puedes imaginar lo que pasó después, ¿verdad?"

# game/script.rpy:990
translate es twentyq_994fe9e5:

    # p "The whole courtship dance, a romantic proposal, and a wedding to write home about?"
    p "¿Todo el baile de cortejo, una propuesta romántica y una boda digna de contarse?"

# game/script.rpy:992
translate es twentyq_6284fc3d:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0060.ogg"
    # t "Everything but the wedding, yes."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0060.ogg"
    t "Todo menos la boda, sí."

# game/script.rpy:996
translate es twentyq_aadbc8ca:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0061.ogg"
    # t "According to the newspapers we dug up, Elias died the night before his wedding ceremony while the Duponts were caught red-handed tearing the place apart, looking for the Gallagher fortune."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0061.ogg"
    t "Según los periódicos que encontramos, Elias murió la noche antes de su ceremonia de boda mientras los Dupont eran atrapados in fraganti destrozando el lugar, buscando la fortuna Gallagher."

# game/script.rpy:1000
translate es twentyq_cdd3181e:

    # p "... And then the rest is history..."
    p "... Y luego el resto es historia..."

# game/script.rpy:1008
translate es twentyq_8f69f432:

    # p "You know, this mission feels different compared to the last time I had an encounter with the paranormal."
    p "Sabes, esta misión se siente diferente comparada con la última vez que tuve un encuentro con lo paranormal."

# game/script.rpy:1010
translate es twentyq_db8bb098:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0062.ogg"
    # t "Ah... haha, uh..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0062.ogg"
    t "Ah... jaja, eh..."

# game/script.rpy:1014
translate es twentyq_caa10a2d:

    # p "... Taylor?"
    p "... Taylor?"

# game/script.rpy:1016
translate es twentyq_716fa3a6:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0063.ogg"
    # t "I uh, that's because the last mission I sent you on wasn't a real thing. That was a {i}fake{/i} paranormal incident."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0063.ogg"
    t "Eh, eso es porque la última misión en la que te envié no fue real. Ese fue un incidente paranormal {i}falso{/i}."

# game/script.rpy:1020
translate es twentyq_c8ea8a4a:

    # p "..."
    p "..."

# game/script.rpy:1022
translate es twentyq_aeca8026:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0064.ogg"
    # t "Hey, after we posted your reactions on the internet we did get some new members!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0064.ogg"
    t "Oye, después de que publicamos tus reacciones en internet, ¡sí conseguimos nuevos miembros!"

# game/script.rpy:1026
translate es twentyq_2f5a0773:

    # p "... For a little bit. Then they left, and it was just you and me again."
    p "... Por un tiempo. Luego se fueron, y otra vez éramos solo tú y yo."

# game/script.rpy:1028
translate es twentyq_e6f99276:

    # "Taylor lets out a deep sigh on the other end, and that's the end of that."
    "Taylor deja escapar un profundo suspiro al otro lado, y eso es todo."

# game/script.rpy:1043
translate es twentyq_a8f5659f:

    # p "Thanks for catching me up, Taylor."
    p "Gracias por ponerme al día, Taylor."

# game/script.rpy:1045
translate es twentyq_93dd97d8:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0065.ogg"
    # t "Of course, [your_name]."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0065.ogg"
    t "Por supuesto, [your_name]."

# game/script.rpy:1049
translate es twentyq_ff7a5e04:

    # "I glance around my surroundings again."
    "Miro a mi alrededor otra vez."

# game/script.rpy:1051
translate es twentyq_dfe80d2d:

    # "The door leading out of this room, out to somewhere only Elias could know, beckoned me forward. I had to know what lay beyond."
    "La puerta que conduce fuera de esta habitación, hacia algún lugar que solo Elias podría conocer, me llamaba hacia adelante. Tenía que saber qué había más allá."

# game/script.rpy:1053
translate es twentyq_125bedc0:

    # p "... I think I'm going to explore more."
    p "... Creo que voy a explorar más."

# game/script.rpy:1055
translate es twentyq_30b9b73a:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0066.ogg"
    # t "Whoa whoa whoa, hold your horses. Aren't you feeling lightheaded or dizzy or anything?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0066.ogg"
    t "Whoa, whoa, whoa, calma. ¿No te sientes con mareo o algo así?"

# game/script.rpy:1059
translate es twentyq_e498b09a:

    # p "Just a little groggy... Why?"
    p "Solo un poco con aturdimiento... ¿Por qué?"

# game/script.rpy:1061
translate es twentyq_2de63bda:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0067.ogg"
    # t "[your_name], I've been trying to reach you for {b}two hours!{/b} Were you even aware you've been gone that long? Maybe you had, like, a concussion or something!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0067.ogg"
    t "[your_name], ¡he estado intentando comunicarme contigo durante {b}dos horas!{/b} ¿Sabías que habías estado fuera tanto tiempo? ¡Quizá tuviste, como, una conmoción cerebral o algo así!"

# game/script.rpy:1065
translate es twentyq_7fcefdfd:

    # p "... I have no idea, but I don't think I had a concussion."
    p "... No tengo idea, pero no creo que haya tenido una conmoción cerebral."

# game/script.rpy:1067
translate es twentyq_8befc683:

    # "That touch... That really {i}did{/i} knock me out, huh? I can barely remember. Elias didn't seem to think it was a threatening act."
    "Ese toque... Eso realmente {i}me{/i} dejó inconsciente, ¿eh? Apenas puedo recordar. A Elias no le pareció un acto amenazante."

# game/script.rpy:1069
translate es twentyq_cfd04893:

    # "Did he {i}want{/i} to put me to sleep, or does he not know his own strength?"
    "¿Quiso {i}dormirme{/i}, o no conoce su propia fuerza?"

# game/script.rpy:1071
translate es twentyq_81495852:

    # p "When I collapsed, what did you hear?"
    p "Cuando me desplomé, ¿qué escuchaste?"

# game/script.rpy:1073
translate es twentyq_7b648777:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0068.ogg"
    # t "I kept hearing that guy's voice, and a rush of air."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0068.ogg"
    t "Seguí escuchando la voz de ese tipo y un soplo de aire."

# game/script.rpy:1077
translate es twentyq_947fda48:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0069.ogg"
    # t "So [your_name]... Was it really Elias?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0069.ogg"
    t "Entonces [your_name]... ¿Era realmente Elias?"

# game/script.rpy:1081
translate es twentyq_1f2a9794:

    # p "... This isn't another one of your fake incidents, is it?"
    p "... Esto no es otro de tus incidentes falsos, ¿verdad?"

# game/script.rpy:1083
translate es twentyq_900a409e:

    # "I know I shouldn't have asked that. Taylor wouldn't pull that on me twice..."
    "Sé que no debería haber preguntado eso. Taylor no me haría eso dos veces..."

# game/script.rpy:1085
translate es twentyq_356cd43a:

    # "But after everything I've been through tonight, it jumped off my tongue in desperate skepticism."
    "Pero después de todo lo que he pasado esta noche, salió de mi boca en un escepticismo desesperado."

# game/script.rpy:1087
translate es twentyq_4a7141cc:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0070.ogg"
    # t "No! Of course not!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0070.ogg"
    t "¡No! ¡Por supuesto que no!"

# game/script.rpy:1091
translate es twentyq_d9410844:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0071.ogg"
    # t "So you really did see {i}the{/i} Elias Gallagher?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0071.ogg"
    t "Entonces realmente viste a {i}el{/i} Elias Gallagher?"

# game/script.rpy:1095
translate es twentyq_675b4d1b:

    # p "I think I touched him, too."
    p "Creo que también lo toqué."

# game/script.rpy:1097
translate es twentyq_482c1cdb:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0072.ogg"
    # t "Okay, I'm coming in. We have to get you out of there—"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0072.ogg"
    t "Está bien, voy entrando. Tenemos que sacarte de allí—"

# game/script.rpy:1101
translate es twentyq_5d8d8367:

    # p "Wait, hang on, why? This is what we came for, though! And we don't know what's going on now that Elias is active."
    p "Espera, ¿por qué? ¡Si esto es por lo que vinimos! Y no sabemos qué está pasando ahora que Elias está activo."

# game/script.rpy:1103
translate es twentyq_70be66d7:

    # p "Listen Taylor, you're the one who's the {i}actual{/i} ghost fanatic. I only hang out with you at the OSHA because—"
    p "Mira Taylor, tú eres el fanático {i}real{/i} de los fantasmas. Yo solo salgo contigo en el OHSIC porque—"

# game/script.rpy:1105
translate es twentyq_3216d612:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0073.ogg"
    # t "OHSIC."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0073.ogg"
    t "OHSIC."

# game/script.rpy:1109
translate es twentyq_44c69897:

    # p "Oh, Whatever! Look, you finally have your proof that ghosts really do exist, and now you're calling a retreat?"
    p "¡Oh, lo que sea! Mira, finalmente tienes tu prueba de que los fantasmas realmente existen, y ahora llamas a la retirada?"

# game/script.rpy:1111
translate es twentyq_cfd28c11:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0074.ogg"
    # t "I-it's a tactical retreat! I was kinda prepared to find a {b}ghost{/b} but not for you to go MIA for {b}TWO WHOLE HOURS!{/b}"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0074.ogg"
    t "¡E-es una retirada táctica! Estaba algo preparado para encontrar un {b}fantasma{/b} pero no para que desaparecieras durante {b}DOS HORAS ENTERAS!{/b}"

# game/script.rpy:1115
translate es twentyq_e11304b7:

    # "... Okay, he's got a fair point there. I almost feel a little guilty at how hard he's hyperventilating."
    "... Está bien, tiene un punto justo ahí. Casi me siento culpable por lo mucho que está hiperventilando."

# game/script.rpy:1123
translate es twentyq_b3e0d5dd:

    # p "Taylor, please calm down. I'm still here, I'm okay. Take a few deep breaths."
    p "Taylor, por favor cálmate. Todavía estoy aquí, estoy bien. Respira profundo un par de veces."

# game/script.rpy:1125
translate es twentyq_2e7abd11:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0075.ogg"
    # t "Ha... ha... fine... yeah... Deep breaths..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0075.ogg"
    t "Ha... ha... está bien... sí... respiraciones profundas..."

# game/script.rpy:1129
translate es twentyq_a3ab5789:

    # "Taylor's labored breaths slowly even out as I imagine him wiping some non-existent sweat off his brow."
    "La respiración laboriosa de Taylor se nivela lentamente mientras me imagino que se seca un sudor inexistente de la frente."

# game/script.rpy:1135
translate es twentyq_c44c6aee:

    # p "Sorry for worrying you, Taylor. If I'd known that I was gonna conk out for two hours, I would have tried to avoid it."
    p "Perdón por preocuparte, Taylor. Si hubiera sabido que me iba a desmayar durante dos horas, habría intentado evitarlo."

# game/script.rpy:1137
translate es twentyq_533ace54:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0076.ogg"
    # t "I'm just really glad you're still here, [your_name]. I don't know what would happen to the OHSIC if I lost you."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0076.ogg"
    t "Solo estoy realmente feliz de que sigas aquí, [your_name]. No sé qué le pasaría al OHSIC si te perdiera."

# game/script.rpy:1141
translate es twentyq_04dc6c32:

    # "I'm a little irked that his first priority seems to be the club rather than my personal well-being, but I don't have the energy to die on that hill."
    "Me irrita un poco que su primera prioridad parezca ser el club en lugar de mi bienestar personal, pero no tengo energía para pelear por eso ahora."

# game/script.rpy:1143
translate es twentyq_e908fd22:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0077.ogg"
    # t "So, if that ghost had the power to put you to sleep, he must be a lot stronger than we anticipated."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0077.ogg"
    t "Así que, si ese fantasma tenía el poder de dormirte, debe ser mucho más fuerte de lo que anticipamos."

# game/script.rpy:1147
translate es twentyq_5d30779c:

    # p "I don't think he's gonna hurt me though. After all, he wants to court me."
    p "No creo que vaya a hacerme daño. Después de todo, quiere cortejarme."

# game/script.rpy:1149
translate es twentyq_ea4fb28d:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0078.ogg"
    # t "You two just {i}met!{/i}\nThat's— that's rushing into things!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0078.ogg"
    t "¡Ustedes dos acaban de {i}conocerse!{/i}\n¡Eso— eso es precipitado.!"

# game/script.rpy:1153
translate es twentyq_1a4802db:

    # "So much for catching his breath."
    "Olvídate de tomar un respiro."

# game/script.rpy:1155
translate es twentyq_b15307e0:

    # p "That was our plan, wasn't it? To trick him into thinking that I was also supposed to get married? And well, we succeeded!"
    p "¿Ese no era nuestro plan? ¿Engañarlo haciéndole pensar que yo también iba a casarme? Bueno, ¡lo logramos!"

# game/script.rpy:1157
translate es twentyq_d3559ae2:

    # "I can just barely hear the faint gnashing of teeth on the other end."
    "Apenas puedo oír el leve rechinar de dientes al otro lado."

# game/script.rpy:1159
translate es twentyq_d75559bd:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0079.ogg"
    # t "Right, yeah... Okay."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0079.ogg"
    t "Sí, sí... está bien."

# game/script.rpy:1163
translate es twentyq_ef29c9b3:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0080.ogg"
    # t "[your_name], I'm still coming in to give you a hand. I trust that guy about as far as I can throw him. Which isn't very far, well, considering... You know... He's a ghost."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0080.ogg"
    t "[your_name], aún voy a entrar para darte una mano. Confío en ese tipo tanto como puedo lanzarlo. Lo que no es muy lejos, considerando... ya sabes... es un fantasma."

# game/script.rpy:1167
translate es twentyq_d4b6f84d:

    # p "Well if you're coming in, I'm heading out. Don't know what I'll find, but I'm bored of this bedroom."
    p "Bueno, si vas a entrar, yo salgo. No sé lo que encontraré, pero me estoy aburriendo de este dormitorio."

# game/script.rpy:1169
translate es twentyq_1e5479a8:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0081.ogg"
    # t "No no no, you stay right there, we have no idea what that dude's up to!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0081.ogg"
    t "No no no, quédate ahí, ¡no tenemos idea de lo que ese tipo está tramando!"

# game/script.rpy:1173
translate es twentyq_192883b7:

    # p "Well according to you, I was sent on this field mission because I have \"the stronger body and no dust allergies.\""
    p "Bueno, según tú, me enviaron a esta misión de campo porque tengo \"el cuerpo más fuerte y sin alergias al polvo\"."

# game/script.rpy:1178
translate es twentyq_d042d521:

    # p "... Just, stay on the line, alright? Let's see what happens."
    p "... Solo, quédate en línea, ¿de acuerdo? Veamos qué pasa."

# game/script.rpy:1185
translate es twentyq_8448941e:

    # "The door opens to a house alive!"
    "¡La puerta se abre a una casa viva!"

# game/script.rpy:1187
translate es twentyq_6cb28de8:

    # "The chill is gone, and the dim light from the windows flows through the halls like a river undammed."
    "El frío se ha ido, y la luz tenue de las ventanas fluye por los pasillos como un río sin represa."

# game/script.rpy:1189
translate es twentyq_96e85501:

    # "I {i}think{/i} this is the same house, after all. The walls are chipped, the floorboards creak, and a hundred ornate doors beckon to be opened; a mystery behind each and every one.."
    "Yo {i}creo{/i} que es la misma casa, después de todo. Las paredes están desconchadas, las tablas del suelo crujen, y cien puertas ornamentadas llaman a ser abiertas; un misterio tras cada una..."

# game/script.rpy:1191
translate es twentyq_5f80fdc1:

    # "I'm just as lost now as I was before I fell asleep."
    "Me perdi tanto ahora como lo estaba antes de dormir."

# game/script.rpy:1193
translate es twentyq_5fff5722:

    # p "I'm out of the bedroom. No signs of Elias, or any other ghosts for that matter. I {i}think{/i} I'm still in the mansion."
    p "He salido del dormitorio. Sin señales de Elias, ni de otros fantasmas por ahora. Yo {i}creo{/i} que todavía estoy en la mansión."

# game/script.rpy:1195
translate es twentyq_62b55da6:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0082.ogg"
    # t "Ugh, okay then, I'll stay put for now. But if we're going to do this, [your_name], then you need to give me a status report."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0082.ogg"
    t "Ugh, está bien entonces, me quedaré aquí por ahora. Pero si vamos a hacer esto, [your_name], necesitas darme un informe de situación."

# game/script.rpy:1199
translate es twentyq_a58a1755:

    # p "Okay so. You know how cold I was when I first entered? That's not a problem anymore. The whole manor is..."
    p "Está bien. ¿Recuerdas lo frío que estaba cuando entré por primera vez? Eso ya no es un problema. Toda la mansión está..."

# game/script.rpy:1201
translate es twentyq_ec8ed898:

    # p "... What's one step down from \"cozy?\""
    p "... ¿Cuál es un paso por debajo de \"acogedora\"?"

# game/script.rpy:1203
translate es twentyq_287f9115:

    # "No response except what might be Taylor biting his lip."
    "Ninguna respuesta, excepto lo que podría ser Taylor mordiéndose el labio."

# game/script.rpy:1205
translate es twentyq_05e1d8fe:

    # "As he contemplates the situation,\nI hear another voice. It sounds... happy?"
    "Mientras contempla la situación,\nEscucho otra voz. Suena... ¿feliz?"

# game/script.rpy:1207
translate es twentyq_34e9a41a:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0016.ogg"
    # "It's humming a melody unfamiliar to me; all at once wistful and joyous and despondent."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0016.ogg"
    "Está tarareando una melodía desconocida para mí; al mismo tiempo melancólica, alegre y desalentadora."

# game/script.rpy:1211
translate es twentyq_eb4ea2ea:

    # "The harmony of dissonances fill the house, even though they barely outdo a whisper."
    "La armonía de disonancias llena la casa, aunque apenas supera un susurro."

# game/script.rpy:1213
translate es twentyq_3b0f63f3:

    # "And despite the echoes crawling like slugs along the walls, I know exactly where the sound originates."
    "Y a pesar de los ecos que se arrastran como babosas por las paredes, sé exactamente de dónde proviene el sonido."

# game/script.rpy:1215
translate es twentyq_ee6957b2:

    # p "I think I know where Elias is. I'm going to try to find my way back to him."
    p "Creo que sé dónde está Elias. Voy a intentar encontrar mi camino de regreso hacia él."

# game/script.rpy:1217
translate es twentyq_e8b0c6db:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0083.ogg"
    # t "If the house really has returned to its full glory, is it because of Elias? If it's not freezing in there anymore, that has to mean something."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0083.ogg"
    t "Si la casa realmente ha vuelto a su gloria total, ¿es por Elias? Si ya no hace frío allí, eso debe significar algo."

# game/script.rpy:1221
translate es twentyq_326ab21b:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0084.ogg"
    # t "[your_name], I think you've really awakened him."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0084.ogg"
    t "[your_name], creo que realmente lo has despertado."

# game/script.rpy:1225
translate es twentyq_7d3e0c80:

    # p "Care to elaborate?"
    p "¿Podrías elaborarlo?"

# game/script.rpy:1227
translate es twentyq_98417717:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0085.ogg"
    # t "Your presence has given him something he hasn't had in forever. I think this house conforms to his spectral energy. You've made him {i}happy.{/i}"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0085.ogg"
    t "Tu presencia le ha dado algo que no había tenido en mucho tiempo. Creo que esta casa se ajusta a su energía espectral. Lo has hecho {i}feliz{/i}."

# game/script.rpy:1231
translate es twentyq_2b42375e:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0086.ogg"
    # t "You've satisfied part of his wish for romance. But I... I want you to be very careful about how that wish gets entirely fulfilled, okay?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0086.ogg"
    t "Has satisfecho parte de su deseo de romance. Pero yo... quiero que tengas mucho cuidado con cómo se cumple completamente ese deseo, ¿de acuerdo?"

# game/script.rpy:1235
translate es twentyq_d3a3f278:

    # p "Okay."
    p "Está bien."

# game/script.rpy:1237
translate es twentyq_d9de6f9c:

    # "I haven't been paying much attention to where I'm going, but my feet have walked on without a second thought; through twisting halls to another dimly lit room."
    "No he estado prestando mucha atención a dónde voy, pero mis pies han avanzado sin pensarlo; por pasillos retorcidos hacia otra habitación tenuemente iluminada."

# game/script.rpy:1243
translate es twentyq_ec486592:

    # "... And to Elias Gallagher."
    "... Y hacia Elias Gallagher."

# game/script.rpy:1252
translate es twentyq_9747e7df:

    # "I peek into the study as quietly as I can – sans the creaky door hinges – so as not to disturb Elias."
    "Eché un vistazo al estudio tan silenciosamente como pude – sin los chirridos de las bisagras – para no molestar a Elias."

# game/script.rpy:1256
translate es twentyq_f8c99904:

    # "I spy him holding a few volumes of some old book collection in his arms as he peruses a crowded shelf."
    "Lo veo sosteniendo algunos volúmenes de una colección de libros antiguos en sus brazos mientras revisa una estantería abarrotada."

# game/script.rpy:1260
translate es twentyq_af2740db:

    # "I can't help but notice the content smile resting on his lips."
    "No puedo evitar notar la sonrisa de satisfacción en sus labios."

# game/script.rpy:1265
translate es twentyq_d97423de:

    # "Once satisfied with his haul, Elias floats over to an armchair and sets the books on a nearby accent table, making sure they're in his preferred order."
    "Una vez satisfecho con su botín, Elias se desliza hasta un sillón y coloca los libros en una mesa auxiliar cercana, asegurándose de que estén en el orden que prefiere."

# game/script.rpy:1269
translate es twentyq_817078b4:

    # "A pot of tea and some snacks wait for him to sit down."
    "Una tetera y algunos bocadillos esperan a que se siente."

# game/script.rpy:1271
translate es twentyq_8f51b6df:

    # p "... Wait, can a ghost even eat or drink?"
    p "... Espera, ¿un fantasma puede siquiera comer o beber?"

# game/script.rpy:1275
translate es twentyq_295b10f5:

    # "Contemplating the question I lean forward to get a better look, the door creaking as it's unintentionally pushed further open."
    "Contemplando la pregunta, me inclino para mirar mejor, y la puerta cruje al abrirse más de manera involuntaria."

# game/script.rpy:1279
translate es twentyq_8e371117:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0017.ogg"
    # e frown_open comical_cry concerned "Aaahh!!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0017.ogg"
    e frown_open comical_cry concerned "¡Aaahh!!"

# game/script.rpy:1283
translate es twentyq_715d7ce4:

    # "Oops, I've ruined his reading time. He's spotted me!"
    "¡Ups, arruiné su tiempo de lectura! ¡Me ha visto!"

# game/script.rpy:1289
translate es twentyq_0d6b3348:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0018.ogg"
    # e "Oh, dearest [your_name]! Wait there!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0018.ogg"
    e "¡Oh, mi dulce [your_name]! ¡Espera ahí!"

# game/script.rpy:1302
translate es twentyq_482f5772:

    # "He hurries over, ghostly tail slicing through the carpet. In a quiet instant Elias floats before me, chest puffed dramatically."
    "Se apresura, su cola fantasmagórica cortando la alfombra. En un instante silencioso, Elias flota frente a mí, pecho inflado dramáticamente."

# game/script.rpy:1304
translate es twentyq_46edfc45:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0019.ogg"
    # e sweat down_right neutral ah_sad "Please, my dear... You mustn't wander around! Things remain out of sorts!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0019.ogg"
    e sweat down_right neutral ah_sad "Por favor, cariño... ¡No debes deambular! ¡Las cosas siguen desordenadas!"

# game/script.rpy:1311
translate es twentyq_ec491ab7:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0087.ogg"
    # t "Ughhhh..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0087.ogg"
    t "Ughhhh..."

# game/script.rpy:1317
translate es twentyq_089f5255:

    # "I do my best to ignore Taylor's annoyed groan."
    "Hago mi mejor esfuerzo por ignorar el gemido molesto de Taylor."

# game/script.rpy:1321
translate es twentyq_f7a6dd04:

    # p "But when I heard you humming, my feet began to move of their own accord. Why, you must have summoned me here to grant you company!"
    p "Pero cuando te escuché tararear, mis pies comenzaron a moverse por sí mismos. ¡Claro, me debes haber convocado aquí para hacerme compañía!"

# game/script.rpy:1323
translate es twentyq_cb5ab84d:

    # "Sure, the line was cheesy, but it wasn't wholly inaccurate. I was drawn to Elias somehow... by something."
    "Sí, la línea fue cursi, pero no era del todo inexacta. De alguna manera, algo me atraía hacia Elias."

# game/script.rpy:1325
translate es twentyq_7c0e02d0:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0020.ogg"
    # e closed_sad -sweat disapprove oh_annoyed "And here I thought I had been quiet so as to not disturb your slumber. Sincerest apologies for rousing you from your rest!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0020.ogg"
    e closed_sad -sweat disapprove oh_annoyed "Y yo que pensaba que había sido silencioso para no interrumpir tu sueño. ¡Sinceras disculpas por despertarte!"

# game/script.rpy:1329
translate es twentyq_aa519aa1:

    # p "No need for apologies, my dear, for I had already awoken."
    p "No hay necesidad de disculpas, cariño, pues ya me había despertado."

# game/script.rpy:1333
translate es twentyq_8f9d86d6:

    # "Elias cocks his head."
    "Elias inclina la cabeza."

# game/script.rpy:1335
translate es twentyq_a576082c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0021.ogg"
    # e sad pout "And yet, that changes little about the unreadiness of this manor."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0021.ogg"
    e sad pout "Y aun así, eso cambia poco sobre la falta de preparación de esta mansión."

# game/script.rpy:1339
translate es twentyq_1947d144:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0022.ogg"
    # e pucker forward_lidded_regular nervous "After all, I have to do all this cleaning myself! Simply look at the state of this study... It's so far gone from its glory days."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0022.ogg"
    e pucker forward_lidded_regular nervous "¡Después de todo, debo hacer toda esta limpieza yo solo! Mira simplemente el estado de este estudio... Está muy lejos de sus días de gloria."

# game/script.rpy:1343
translate es twentyq_0ad27245:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0088.ogg"
    # t "Didn't you say it was pristine?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0088.ogg"
    t "¿No dijiste que estaba impecable?"

# game/script.rpy:1349
translate es twentyq_b33ff146:

    # "I did, and I stand by that. Virology labs {i}wish{/i} they were this clean."
    "Lo dije, y me mantengo firme. Los laboratorios de virología {i}desearían{/i} estar así de limpios."

# game/script.rpy:1351
translate es twentyq_f7163af6:

    # "Either Elias is a perfectionist beyond compare, or he and I are seeing two different versions of the manor."
    "O Elias es un perfeccionista incomparable, o él y yo estamos viendo dos versiones diferentes de la mansión."

# game/script.rpy:1355
translate es twentyq_20e0b871:

    # p "And yet, I find these rooms quite beautiful."
    p "Y aun así, encuentro estas habitaciones bastante hermosas."

# game/script.rpy:1357
translate es twentyq_d0c9ddd0:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0023.ogg"
    # e normal happy "Just wait, and be amazed!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0023.ogg"
    e normal happy "¡Espera y asómbrate!"

# game/script.rpy:1361
translate es twentyq_aa7d6b74:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0024.ogg"
    # e frown_disapprove disapprove right_lidded "I will have to find new staff quite soon. Sadly, they did not stay with me as I left my body behind. Ooohhh, if only they had!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0024.ogg"
    e frown_disapprove disapprove right_lidded "Tendré que encontrar nuevo personal muy pronto. Tristemente, no se quedaron conmigo cuando dejé mi cuerpo atrás. ¡Ooohhh, si tan solo lo hubieran hecho!"

# game/script.rpy:1367
translate es twentyq_3123676c:

    # p "Now, now. Don't get too preoccupied with the staff. You have all the time in the world to replace them!"
    p "Ahora, ahora. No te preocupes demasiado por el personal. ¡Tienes todo el tiempo del mundo para reemplazarlos!"

# game/script.rpy:1371
translate es twentyq_378fe9e5:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0025.ogg"
    # e comical_surprised concerned tch "On the contrary! Arrangements must be made with all haste!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0025.ogg"
    e comical_surprised concerned tch "¡Al contrario! ¡Los preparativos deben hacerse con toda prisa!"

# game/script.rpy:1375
translate es twentyq_ff4d4dfe:

    # p "Uh, arrangements for what?"
    p "Uh, ¿preparativos para qué?"

# game/script.rpy:1377
translate es twentyq_c14ac3ed:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0026.ogg"
    # e goofgrin_up happy closed_happy blush "Our wedding, of course!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0026.ogg"
    e goofgrin_up happy closed_happy blush "¡Nuestra boda, por supuesto!"

# game/script.rpy:1381
translate es twentyq_69395abd:

    # "Taylor chokes on his spit through the earpiece while I stand there and replay that last sentence in my head."
    "Taylor se atraganta con su saliva a través del auricular mientras me quedo allí y repito mentalmente esa última frase."

# game/script.rpy:1385
translate es twentyq_4dd4b071:

    # "... I can't blame Elias for wanting to rush after decades of waiting, but..."
    "... No puedo culpar a Elias por querer apresurarse tras décadas de espera, pero..."

# game/script.rpy:1387
translate es twentyq_e50c886a:

    # "Taylor mutters something indiscernible under his breath. I feel the same though... I might be in more trouble than I expected."
    "Taylor murmura algo indiscernible entre dientes. Yo siento lo mismo... Podría estar en más problemas de los que esperaba."

# game/script.rpy:1389
translate es twentyq_791f7ff2:

    # p "But... I've only just been left at the altar, my dear! A long time for you has only been a sunset for me."
    p "Pero... ¡Acaban dejarme en el altar, cariño! Mucho tiempo para ti ha sido solo un atardecer para mí."

# game/script.rpy:1393
translate es twentyq_e45ae116:

    # p "I ask you graciously to let us seek a compromise."
    p "Te pido con gracia que busquemos un compromiso."

# game/script.rpy:1397
translate es twentyq_9b7e5106:

    # "Elias tilts his head once more, eyes locked with mine."
    "Elias inclina la cabeza una vez más, ojos fijos en los míos."

# game/script.rpy:1399
translate es twentyq_a6aa1578:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0027.ogg"
    # e frown_open closed_sad sad "But your heart..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0027.ogg"
    e frown_open closed_sad sad "Pero tu corazón..."

# game/script.rpy:1403
translate es twentyq_7e853e35:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0028.ogg"
    # e forward_lidded_small oh_disapprove "I can hear its soft, gentle tears fall upon your soul!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0028.ogg"
    e forward_lidded_small oh_disapprove "¡Puedo oír sus suaves y delicadas lágrimas caer sobre tu alma!"

# game/script.rpy:1407
translate es twentyq_7f1cef8f:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0029.ogg"
    # e closed_sad angry upset_open "I promise you, my dearest, that a heart does not heal easily. No matter how many tales of tragedy and hardship one may read, reality is much more painful."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0029.ogg"
    e closed_sad angry upset_open "Te prometo, cariño, que un corazón no sana fácilmente. No importa cuántos cuentos de tragedia y dificultades se lean, la realidad es mucho más dolorosa."

# game/script.rpy:1411
translate es twentyq_90837c4a:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0030.ogg"
    # e oh_sad sad "Why, mine own heart has been broken more than a dozen times over the course of my life... And alas, it has never once healed; only turned to an aching scar."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0030.ogg"
    e oh_sad sad "Mi propio corazón ha sido roto más de una docena de veces a lo largo de mi vida... Y, lamentablemente, nunca se ha sanado; solo se convirtió en una cicatriz dolorosa."

# game/script.rpy:1415
translate es twentyq_de8aff0e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0031.ogg"
    # e oh_disapprove concerned sweat "And I have tried my damndest to ignore those wounds... To let them bleed out and coagulate into some semblance of strength, but it left me sickly instead. If a heart is to be mended, surgery must be immediate!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0031.ogg"
    e oh_disapprove concerned sweat "Y he intentado con todas mis fuerzas ignorar esas heridas... Dejar que sangren y coagulen hasta adquirir alguna apariencia de fortaleza, pero me dejó enfermo en su lugar. ¡Si un corazón debe ser reparado, la cirugía debe ser inmediata!"

# game/script.rpy:1421
translate es twentyq_a81ba0e2:

    # "Elias takes my hands into his cold, ethereal grasp."
    "Elias toma mis manos con su frío y etéreo agarre."

# game/script.rpy:1423
translate es twentyq_e75043c8:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0032.ogg"
    # e forward_heart smug happy -sweat "And here before you is someone who can mend your broken heart. Someone who can cherish you, stay with you, create happiness for you."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0032.ogg"
    e forward_heart smug happy -sweat "Y aquí delante de ti está alguien que puede reparar tu corazón roto. Alguien que puede cuidarte, quedarse contigo, crear felicidad para ti."

# game/script.rpy:1427
translate es twentyq_c75510bb:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0033.ogg"
    # e blush normal sad "I never had that chance in my own mortal life, and after so long... My dearest, I want you to choose happiness, not sorrow."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0033.ogg"
    e blush normal sad "Nunca tuve esa oportunidad en mi propia vida mortal, y después de tanto tiempo... Cariño, quiero que elijas la felicidad, no la tristeza."

# game/script.rpy:1431
translate es twentyq_de42d5cd:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0034.ogg"
    # e grin_teeth neutral "... And I want to be the one to give you that happiness."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0034.ogg"
    e grin_teeth neutral "... Y quiero ser quien te dé esa felicidad."

# game/script.rpy:1435
translate es twentyq_a20cefa7:

    # "..."
    "..."

# game/script.rpy:1439
translate es twentyq_05125f01:

    # "I'm... flattered."
    "Me... complace."

# game/script.rpy:1443
translate es twentyq_b2aab29b:

    # "Something in his words rings truer to my heart than I could have expected. All I'm doing is playing along; acting my part. But if I had actually been left at the altar, would I..."
    "Algo en sus palabras resuena más profundamente en mi corazón de lo que esperaba. Todo lo que hago es seguir el juego; actuar mi parte. Pero si realmente me hubieran dejado en el altar, ¿lo haría...?"

# game/script.rpy:1445
translate es twentyq_a533a7b4:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0089.ogg"
    # t "... Whatever you do [your_name], do not trust him. {i}At all{/i}."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0089.ogg"
    t "... Hagas lo que hagas [your_name], no confíes en él. {i}Para nada{/i}."

# game/script.rpy:1451
translate es twentyq_ae00caaa:

    # p "Ah!"
    p "¡Ah!"

# game/script.rpy:1453
translate es twentyq_3dcd5cdd:

    # "Taylor's voice snaps me from my thought."
    "La voz de Taylor me saca de mi pensamiento."

# game/script.rpy:1457
translate es twentyq_fa77dcec:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0090.ogg"
    # t "But also, don't do anything to upset him. Play it as cool as possible."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0090.ogg"
    t "Pero también, no hagas nada para enojarlo. Juega lo más tranquilo posible."

# game/script.rpy:1461
translate es twentyq_342e1a67:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0091.ogg"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0091.ogg"

# game/script.rpy:1465
translate es twentyq_c46e15c1:

    # t "Elias gave you a very thin rope to walk. Don't fall down! Do you understand?"
    t ""

# game/script.rpy:1469
translate es twentyq_020bf5cf:

    # "Okay, okay. I got this. I can walk a tightrope. Or at least fake it."
    "Está bien, está bien. Lo tengo. Puedo caminar por la cuerda floja. O al menos fingirlo."

# game/script.rpy:1471
translate es twentyq_2e95de56:

    # p "Why not show me what else there is to Elias Gallagher? Let me indulge in my groom before I marry my husband."
    p "¿Por qué no me muestras qué más hay de Elias Gallagher? Permíteme disfrutar de mi prometido antes de casarme con mi esposo."

# game/script.rpy:1473
translate es twentyq_46ddc34c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0035.ogg"
    # e grin_straight closed_happy "... Yes. Yes! We shall do that. But I cannot wait forever, either. The taste of eternity I've already supped upon is nigh unbearable."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0035.ogg"
    e grin_straight closed_happy "... Sí. ¡Sí! Haremos eso. Pero tampoco puedo esperar para siempre. El sabor de la eternidad que ya he probado es casi insoportable."

# game/script.rpy:1477
translate es twentyq_963e162d:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0036.ogg"
    # e forward_heart lipbite_big happy "Join your groom in helping him plan our wedding!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0036.ogg"
    e forward_heart lipbite_big happy "¡Únete a tu prometido para ayudarle a planear nuestra boda!"

# game/script.rpy:1481
translate es twentyq_a0be1381:

    # "Taylor once more grumbles something inaudible."
    "Taylor vuelve a murmurar algo inaudible."

# game/script.rpy:1483
translate es twentyq_71fca3d3:

    # p "And what does my dear groom need help with?"
    p "¿Y con qué necesita ayuda mi querido prometido?"

# game/script.rpy:1487
translate es twentyq_2ae39c11:

    # "Elias gives a thoughtful pause."
    "Elias hace una pausa pensativa."

# game/script.rpy:1489
translate es twentyq_3741fd88:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0037.ogg"
    # e closed_happy grin_teeth happy blush "Now let me think... ah! I'd love your assistance with the floral arrangements. I have all the flowers of New England in my hands... it shall be difficult to select only a few!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0037.ogg"
    e closed_happy grin_teeth happy blush "Ahora déjame pensar... ¡ah! Me encantaría tu ayuda con los arreglos florales. ¡Tengo todas las flores de Nueva Inglaterra en mis manos... será difícil seleccionar solo unas pocas!"

# game/script.rpy:1495
translate es twentyq_f19a6c92:

    # "To prove his claim, he presents his open palms to me, and a smorgasbord of tiny sample flowers sprout and bloom for my perusal."
    "Para demostrar su afirmación, presenta sus palmas abiertas, y un despliegue de pequeñas flores de muestra brota y florece para mi inspección."

# game/script.rpy:1497
translate es twentyq_6a11ce78:

    # p "That's... so many! You'll have to narrow it down for me, else I could never choose. And surely you'd want me to be selective."
    p "¡Eso es... muchísimas! Tendrás que reducirlo por mí, de lo contrario nunca podría elegir. Y seguro quieres que yo elija."

# game/script.rpy:1499
translate es twentyq_97a78025:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0038.ogg"
    # e smug closed_happy "Of course! And after that, a cake. I know my grandmother's recipes are still in this house, and I should set off on finding them."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0038.ogg"
    e smug closed_happy "¡Por supuesto! Y después de eso, un pastel. Sé que las recetas de mi abuela todavía están en esta casa, y debo salir a buscarlas."

# game/script.rpy:1503
translate es twentyq_0b50515c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0039.ogg"
    # e -closed_happy goofgrin_drool "I've tasted them all when I was still in the flesh, and they're delightful! As such, I leave the choice of cake to you."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0039.ogg"
    e -closed_happy goofgrin_drool "¡Las he probado todas cuando aún estaba en carne y hueso, y son deliciosas! Así que dejo la elección del pastel a ti."

# game/script.rpy:1507
translate es twentyq_b57b7682:

    # p "I can certainly do that."
    p "Ciertamente puedo hacer eso."

# game/script.rpy:1509
translate es twentyq_930fd2b3:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0040.ogg"
    # e forward_heart normal "And finally, since you'll be marrying into my distinguished family, I'm eager to bestow upon you a gift suitable of that prestige."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0040.ogg"
    e forward_heart normal "Y finalmente, dado que te casarás con mi distinguida familia, estoy ansioso por otorgarte un regalo digno de esa distinción."

# game/script.rpy:1513
translate es twentyq_f08fe1e2:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0041.ogg"
    # e grin_straight neutral "I shall lead you to my treasury, and introduce you to the family jewels."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0041.ogg"
    e grin_straight neutral "Te llevaré a mi tesorería y te presentaré las joyas de la familia."

# game/script.rpy:1517
translate es twentyq_28b1b491:

    # "Taylor sniggers. I can't help it, I laugh too, but try to mask it tastefully."
    "Taylor se ríe entre dientes. No puedo evitarlo, yo también me río, pero intento disimularlo con elegancia."

# game/script.rpy:1519
translate es twentyq_9cd75f83:

    # p "Haha, delightful! So I shall pick the jewelry I wear for you?"
    p "¡Jaja, encantador! ¿Así que escogeré las joyas que usaré para ti?"

# game/script.rpy:1521
translate es twentyq_7a419237:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0042.ogg"
    # e closed_happy happy goofgrin_up "Precisely!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0042.ogg"
    e closed_happy happy goofgrin_up "¡Exactamente!"

# game/script.rpy:1525
translate es twentyq_8873f5d4:

    # p "Very well. And with that, I believe we have reached an agreeable compromise."
    p "Muy bien. Y con eso, creo que hemos llegado a un compromiso aceptable."

# game/script.rpy:1527
translate es twentyq_35d7ddc0:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0043.ogg"
    # e forward_heart "Then let us begin! Take my hand, and I'll lead you to the greenhouse."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0043.ogg"
    e forward_heart "¡Entonces comencemos! Toma mi mano, y te guiaré hasta el invernadero."

# game/script.rpy:1537
translate es twentyq_9fe76112:

    # "Elias' hand isn't nearly as cold as earlier, but my fingers phase through his just slightly all the same. It's enough to simulate the gesture of holding hands at least."
    "La mano de Elias no está tan fría como antes, pero mis dedos atraviesan los suyos solo un poco. Es suficiente para simular el gesto de tomarnos de la mano al menos."

# game/script.rpy:1541
translate es twentyq_a21d0c04:

    # "Satisfied with the arrangement, he leads me out of the study and back through the halls. "
    "Satisfecho con el arreglo, me guía fuera del estudio y de vuelta por los pasillos."

# game/script.rpy:1554
translate es twentyq_534323af:

    # "As we walk, I reexamine my surroundings. It really is hard to believe just how much of a glow up this place got."
    "Mientras caminamos, vuelvo a examinar mi entorno. Realmente es difícil creer cuánto ha mejorado este lugar."

# game/script.rpy:1558
translate es twentyq_d29b6504:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0092.ogg"
    # t "Hey [your_name], how are we holding up?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0092.ogg"
    t "Hola [your_name], ¿cómo nos estamos llevando?"

# game/script.rpy:1562
translate es twentyq_1dcbc25a:

    # p "{i}Splendid{/i}, I've always wanted to hold hands with the man I love."
    p "{i}¡Magnífico{/i}!, siempre he querido tomar la mano del hombre que amo."

# game/script.rpy:1566
translate es twentyq_c0500e96:

    # "Elias casts me a sideways glance and blushes. I don't have the heart to tell him that I don't really mean it."
    "Elias me lanza una mirada de reojo y se sonroja. No tengo corazón para decirle que no lo digo en serio."

# game/script.rpy:1572
translate es twentyq_6e8b854c:

    # "We pass through the foyer on our way to the other end of the manor. Two hours I was knocked out for, huh?"
    "Pasamos por el vestíbulo camino al otro extremo de la mansión. Dos horas estuve inconsciente, ¿eh?"

# game/script.rpy:1574
translate es twentyq_d256402e:

    # "Elias is practically dragging me at this point."
    "Elias prácticamente me arrastra en este punto."

# game/script.rpy:1580
translate es twentyq_3378a362:

    # "This set of hallways is almost identical to the other end, sans the glass double doors around the corner. Elias phases through so he can unlock and hold them open for me."
    "Este conjunto de pasillos es casi idéntico al otro extremo, sin las puertas dobles de vidrio alrededor de la esquina. Elias atraviesa para poder desbloquearlas y mantenerlas abiertas para mí."

# game/script.rpy:1582
translate es twentyq_fa188e0b:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0044.ogg"
    # e closed_happy happy "After you!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0044.ogg"
    e closed_happy happy "¡Después de ti!"

# game/script.rpy:1590
translate es twentyq_9f559730:

    # "I take a step through the doorway, entering a world of flora. Seems the greenhouse still works as intended."
    "Doy un paso a través del umbral, entrando en un mundo de flora. Parece que el invernadero todavía funciona como debe."

# game/script.rpy:1592
translate es twentyq_2ed58437:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0045.ogg"
    # e down_right oh_annoyed sweat "You shuddered a little. Is there a chill, my dear?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0045.ogg"
    e down_right oh_annoyed sweat "Te estremeciste un poco. ¿Hace frío, cariño?"

# game/script.rpy:1596
translate es twentyq_94cdee65:

    # p "No, quite the opposite! Why, I'm surprised at how lovely the greenhouse looks already."
    p "¡No, todo lo contrario! ¡Me sorprende lo hermoso que se ve el invernadero ya!"

# game/script.rpy:1600
translate es twentyq_0de69e5c:

    # "... Perhaps I'm exaggerating a bit. I can't even tell what plants used to grow in these planters."
    "... Quizás estoy exagerando un poco. Ni siquiera puedo decir qué plantas solían crecer en estas macetas."

# game/script.rpy:1602
translate es twentyq_2f0ecf7b:

    # "But my bouquet would be here. Elias could likely turn this from depressing to delightful before I could blink."
    "Pero mi ramo estaría aquí. Elias probablemente podría convertir esto de deprimente a encantador antes de que pudiera parpadear."

# game/script.rpy:1604
translate es twentyq_36bb8a01:

    # p "Do you need any help restoring this greenhouse to its former glory?"
    p "¿Necesitas ayuda para restaurar este invernadero a su antigua gloria?"

# game/script.rpy:1606
translate es twentyq_2de4d806:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0046.ogg"
    # e closed_happy smug "I did, but no longer."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0046.ogg"
    e closed_happy smug "Lo hice, pero ya no."

# game/script.rpy:1610
translate es twentyq_88b61109:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0047.ogg"
    # e -closed_happy grin_tilted happy "Behold!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0047.ogg"
    e -closed_happy grin_tilted happy "¡He aquí!"

# game/script.rpy:1614
translate es twentyq_2b085a1e:

    # "I watch Elias' eager hands dance upon the trellises... And without any more than a simple flourish, dozens of flowers, this time in full size and bloom, await my perusal."
    "Observo las ansiosas manos de Elias bailar sobre los enrejados... Y sin más que un simple gesto, docenas de flores, esta vez en tamaño completo y en plena floración, esperan mi inspección."

# game/script.rpy:1616
translate es twentyq_f6b27fc6:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0048.ogg"
    # e smug blush "Voila! My dear, your flowers."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0048.ogg"
    e smug blush "¡Voilà! Cariño, tus flores."

# game/script.rpy:1622
translate es twentyq_e0335e08:

    # "My eyes and nose are drawn to three flowers in particular... None of which should be growing on a trellis. An act of defiance, paranormal willpower, or simply Elias forgetting his botany?"
    "Mis ojos y nariz se sienten atraídos por tres flores en particular... Ninguna de las cuales debería crecer en un enrejado. ¿Un acto de desafío, voluntad paranormal, o simplemente Elias olvidando su botánica?"

# game/script.rpy:1625
translate es twentyq_0da79d14:

    # "A classic red rose... it seems to be a different variant than the one I brought with me inside the manor, though not a climbing rose."
    "Una clásica rosa roja... parece ser una variante diferente a la que traje conmigo dentro de la mansión, aunque no es una rosa trepadora."

# game/script.rpy:1627
translate es twentyq_6669f6b4:

    # "A dazzling orange zinnia. The color reminds me of the soda I bring to the club room, though that's probably the least poetic thing to think about right now."
    "Una deslumbrante zinnia naranja. El color me recuerda a la soda que llevo al salón del club, aunque probablemente eso sea lo menos poético en lo que pensar ahora."

# game/script.rpy:1629
translate es twentyq_5572c3ca:

    # "And finally a cute bunch of lyreflowers, vibrant and pink amongst the other blooms. I've always enjoyed their cheerful presence whenever I pass them by."
    "Y finalmente un lindo ramo de flores lira, vibrantes y rosadas entre los demás brotes. Siempre he disfrutado de su alegre presencia cada vez que paso cerca de ellas."

# game/script.rpy:1631
translate es twentyq_e58e29fd:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0049.ogg"
    # e closed_happy grin_straight "And there's more, much more if these don't delight you."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0049.ogg"
    e closed_happy grin_straight "Y hay más, mucho más si estas no te deleitan."

# game/script.rpy:1635
translate es twentyq_ce7a1734:

    # p "No, no, I think... I think one of these shall delight us both."
    p "No, no, creo... creo que una de estas nos deleitará a ambos."

# game/script.rpy:1639
translate es twentyq_9669ff5f:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0050.ogg"
    # e forward_heart grin_tilted "And which will that be, my dear?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0050.ogg"
    e forward_heart grin_tilted "¿Y cuál será, cariño?"

# game/script.rpy:1653
translate es twentyq_6f031ed0:

    # p "The rose is always a classic choice. Red means love, yes?"
    p "La rosa siempre es una elección clásica. Rojo significa amor, ¿verdad?"

# game/script.rpy:1655
translate es twentyq_a713d2fb:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0051.ogg"
    # e happy closed_happy smug "Red on a rose means {i}true{/i} love. Undying love. Eternal love."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0051.ogg"
    e happy closed_happy smug "El rojo en una rosa significa {i}amor verdadero{/i}. Amor eterno. Amor inquebrantable."

# game/script.rpy:1659
translate es twentyq_a3efaaf7:

    # "Sounds about right. Taylor's had me flick through a few books on flower language over the years hoping we could lure out some ghosts with the right blooms... But I could never keep the meanings straight in my head."
    "Suena acertado. Taylor me hizo hojear algunos libros sobre el lenguaje de las flores a lo largo de los años con la esperanza de atraer fantasmas con las flores correctas... Pero nunca pude mantener los significados en mi cabeza."

# game/script.rpy:1663
translate es twentyq_07345335:

    # "Maybe Elias was the type? Red roses were easy, would he know more?"
    "¿Quizás Elias era de ese tipo? Las rosas rojas eran fáciles, ¿sabría él más?"

# game/script.rpy:1665
translate es twentyq_8f2c3049:

    # p "Yes, I think it's a perfect choice for us then."
    p "Sí, creo que es la elección perfecta para nosotros entonces."

# game/script.rpy:1667
translate es twentyq_592b20a9:

    # p "Do we have a vase?"
    p "¿Tenemos un jarrón?"

# game/script.rpy:1669
translate es twentyq_3682adb8:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0052.ogg"
    # e -forward_heart grin_straight "Of course."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0052.ogg"
    e -forward_heart grin_straight "Por supuesto."

# game/script.rpy:1673
translate es twentyq_34d3bd1e:

    # "With a flick of his wrist, a pile of dust on the other side of the room collapses, and in his grasp he holds a perfectly clean, nearly translucent glass vase."
    "Con un giro de muñeca, un montón de polvo al otro lado de la habitación se derrumba, y en su mano sostiene un jarrón de vidrio perfectamente limpio y casi translúcido."

# game/script.rpy:1675
translate es twentyq_b729bab1:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0053.ogg"
    # e grin_teeth "Acceptable?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0053.ogg"
    e grin_teeth "¿Aceptable?"

# game/script.rpy:1679
translate es twentyq_a282caef:

    # p "Oh, much more than acceptable. And something to cut the flowers? Oh, and gloves to handle the thorns?"
    p "Oh, mucho más que aceptable. ¿Y algo para cortar las flores? Oh, y guantes para manejar las espinas?"

# game/script.rpy:1681
translate es twentyq_52307834:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0054.ogg"
    # e closed_happy @ lipbite_small "Of course."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0054.ogg"
    e closed_happy @ lipbite_small "Por supuesto."

# game/script.rpy:1685
translate es twentyq_476018cf:

    # "He provides me with the tools and I set to work. Do I need to trim the stems before putting them in the vase? I think there was a trick to removing the thorns, but if I knew it, it's long gone—"
    "Me proporciona las herramientas y me pongo a trabajar. ¿Debo recortar los tallos antes de ponerlos en el jarrón? Creo que había un truco para quitar las espinas, pero si lo sabía, hace mucho que lo olvidé—"

# game/script.rpy:1687
translate es twentyq_4599cabf:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0055.ogg"
    # e neutral forward_lidded_regular normal "Careful. Simply go slowly, and the rose will happily let its guard drop."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0055.ogg"
    e neutral forward_lidded_regular normal "Cuidado. Simplemente ve despacio, y la rosa felizmente bajará la guardia."

# game/script.rpy:1691
translate es twentyq_1a8a683c:

    # "I guide the knife he provided slowly up the stem, as parallel as possible, and when the blade hits a thorn, it cuts through like butter."
    "Guío lentamente el cuchillo que me dio por el tallo, lo más paralelo posible, y cuando la hoja golpea una espina, corta como mantequilla."

# game/script.rpy:1693
translate es twentyq_a5b0f0f9:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0056.ogg"
    # e happy down_right grin_tilted "There you are. See? Not a thing to be afraid of, not a moment that needs to be rushed."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0056.ogg"
    e happy down_right grin_tilted "Ahí lo tienes. ¿Ves? Nada que temer, ningún momento que deba apresurarse."

# game/script.rpy:1697
translate es twentyq_b73892c6:

    # "This whole day has been a rush, hasn't it? Sure, in the sense of \"I've literally met a ghost after years of trying,\" but also, all the pressure."
    "Todo este día ha sido un apuro, ¿verdad? Claro, en el sentido de \"Literalmente conocí a un fantasma después de años de intentarlo\", pero también toda la presión."

# game/script.rpy:1699
translate es twentyq_501fc8bb:

    # "I had less than 48 hours to prepare for my own wedding, even if it was fake! All the sudden research, all the desperate planning, and not a breath in between."
    "Tenía menos de 48 horas para prepararme para mi propia boda, ¡aunque fuera falsa! Toda la investigación de repente, toda la planificación desesperada, y ni un respiro entre medias."

# game/script.rpy:1703
translate es twentyq_d2b260ee:

    # "My hand slows to a crawl, and I savor the moment, pruning each thorn one by one. They fall to the greenhouse floor, decorating the tile in reddish green points."
    "Mi mano ralentiza su movimiento a un arrastre, y saboreo el momento, podando cada espina una por una. Caen al suelo del invernadero, decorando el azulejo con puntos rojiverdes."

# game/script.rpy:1705
translate es twentyq_91cb0342:

    # "Eventually, there are no more thorns to prune. I add another rose to the vase, hoping it looks okay, then another."
    "Eventualmente, no quedan más espinas por podar. Agrego otra rosa al jarrón, esperando que se vea bien, luego otra."

# game/script.rpy:1707
translate es twentyq_cfd8cd8e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0057.ogg"
    # e closed_happy grin_teeth "Splendid! Now, did you have thoughts on accouterments? Accent flowers, that is!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0057.ogg"
    e closed_happy grin_teeth "¡Magnífico! Ahora, ¿tenías pensamientos sobre los adornos? ¡Flores de acento, es decir!"

# game/script.rpy:1711
translate es twentyq_ebc657e5:

    # "Oh right, this is just a half-dozen roses, not a full bouquet."
    "Oh, cierto, esto es solo media docena de rosas, no un ramo completo."

# game/script.rpy:1713
translate es twentyq_a50e1a28:

    # p "I... hadn't thought about it."
    p "Yo... no lo había pensado."

# game/script.rpy:1715
translate es twentyq_d0e72e2c:

    # "If Elias is that into flowers..."
    "Si a Elias le gustan tanto las flores..."

# game/script.rpy:1717
translate es twentyq_aa7f28dc:

    # p "Would you suggest some for us?"
    p "¿Sugerirías algunas para nosotros?"

# game/script.rpy:1719
translate es twentyq_5457a282:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0058.ogg"
    # e forward_heart smug "My pleasure and my honor."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0058.ogg"
    e forward_heart smug "Mi placer y mi honor."

# game/script.rpy:1723
translate es twentyq_72765839:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0059.ogg"
    # e forward_regular normal "First, some baby's breath."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0059.ogg"
    e forward_regular normal "Primero, algo de gypsophila."

# game/script.rpy:1727
translate es twentyq_ff6075bd:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0093.ogg"
    # t "Fake the flower language... If you get it right he'll be happy, if you get it wrong he'll have the joy of correcting you."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0093.ogg"
    t "Finge el lenguaje de las flores... Si aciertas, él estará feliz; si te equivocas, tendrá la alegría de corregirte."

# game/script.rpy:1731
translate es twentyq_b909f58c:

    # "Taylor's voice hisses in my ear."
    "La voz de Taylor sisea en mi oído."

# game/script.rpy:1733
translate es twentyq_f04fe6a1:

    # p "Baby's breath... That's something about youth, correct?"
    p "Gypsophila... Eso tiene algo que ver con la juventud, ¿correcto?"

# game/script.rpy:1735
translate es twentyq_38638856:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0060.ogg"
    # e forward_lidded_regular @ oh_disapprove "In this bouquet, more a symbol of innocence and purity."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0060.ogg"
    e forward_lidded_regular @ oh_disapprove "En este ramo, más un símbolo de inocencia y pureza."

# game/script.rpy:1739
translate es twentyq_d3190703:

    # "Oh, I hope he doesn't get weird about purity because I definitely cannot meet Victorian standards..."
    "Oh, espero que no se ponga raro con lo de la pureza porque definitivamente no puedo cumplir los estándares victorianos..."

# game/script.rpy:1741
translate es twentyq_7d73a3c8:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0061.ogg"
    # e @ left_regular smug "They work stunningly when used sparingly. One may expect that their small size must be bolstered by great numbers, but that's simply not true."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0061.ogg"
    e @ left_regular smug "Funcionan de manera deslumbrante cuando se usan con moderación. Se podría esperar que su pequeño tamaño deba ser reforzado por gran cantidad, pero eso simplemente no es cierto."

# game/script.rpy:1745
translate es twentyq_908a622b:

    # "I try to take his advice. The little white flowers slip between the roses, resting like snowflakes suspended mid fall."
    "Intento seguir su consejo. Las pequeñas flores blancas se deslizan entre las rosas, descansando como copos de nieve suspendidos en el aire."

# game/script.rpy:1747
translate es twentyq_6ea8febb:

    # "Elias could make roses bloom in winter, couldn't he? I think about what an odd wedding that would be, but his hands continue to guide mine, raising the baby's breath up a smidge."
    "Elias podría hacer que las rosas florecieran en invierno, ¿no? Pienso en lo extraña que sería esa boda, pero sus manos continúan guiando las mías, elevando un poco la gypsophila."

# game/script.rpy:1749
translate es twentyq_7d929759:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0062.ogg"
    # e forward_regular grin_teeth "Do you see how that little bit of elevation gives the whole bouquet a sense of dynamism? Personality?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0062.ogg"
    e forward_regular grin_teeth "¿Ves cómo esa pequeña elevación da al ramo entero una sensación de dinamismo? ¿Personalidad?"

# game/script.rpy:1753
translate es twentyq_ffe0064c:

    # p "How much is a smidge? Here?"
    p "¿Cuánto es un poquito? ¿Aquí?"

# game/script.rpy:1755
translate es twentyq_15e7d566:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0063.ogg"
    # e happy closed_happy normal "Here."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0063.ogg"
    e happy closed_happy normal "Aquí."

# game/script.rpy:1759
translate es twentyq_d9efe5d4:

    # "He reaches out and his hand flows through the stems, through the petals, and through my fingers; lifting my hand — along with the flowers — ever so gently..."
    "Extiende su mano y fluye a través de los tallos, los pétalos y mis dedos; levantando mi mano —junto con las flores— con suavidad..."

# game/script.rpy:1761
translate es twentyq_ae00caaa_1:

    # p "Ah!"
    p "¡Ah!"

# game/script.rpy:1763
translate es twentyq_5e482f9f:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0064.ogg"
    # e smug forward_lidded_regular neutral "Just like that."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0064.ogg"
    e smug forward_lidded_regular neutral "Justo así."

# game/script.rpy:1767
translate es twentyq_c8459de7:

    # p "And would we like more flowers in this bouquet?"
    p "¿Y queremos más flores en este ramo?"

# game/script.rpy:1769
translate es twentyq_5160b8ab:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0065.ogg"
    # e @ up_regular pout "Yes, I think so. What would you say to lemon balm?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0065.ogg"
    e @ up_regular pout "Sí, creo que sí. ¿Qué dirías de melisa?"

# game/script.rpy:1773
translate es twentyq_97cc0d48:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0094.ogg"
    # t "I'd ask how closely related they are to lemons."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0094.ogg"
    t "Preguntaría qué tan emparentada está con los limones."

# game/script.rpy:1777
translate es twentyq_df1e20a8:

    # "There's Taylor with the snark, again. Of course."
    "Ahí está Taylor con su sarcasmo, otra vez. Claro."

# game/script.rpy:1779
translate es twentyq_774e625a:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0066.ogg"
    # e forward_regular smug "Only some leaves, green and small. Perfect for filling in the gaps and adding a rich aroma."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0066.ogg"
    e forward_regular smug "Solo unas hojas, verdes y pequeñas. Perfectas para llenar los huecos y añadir un aroma rico."

# game/script.rpy:1783
translate es twentyq_1fdf753b:

    # p "Do they mean something about sweetness?"
    p "¿Significan algo sobre dulzura?"

# game/script.rpy:1785
translate es twentyq_92b64676:

    # "Probably best not to ask about sourness."
    "Probablemente mejor no preguntar sobre acidez."

# game/script.rpy:1787
translate es twentyq_7b9dc192:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0067.ogg"
    # e closed_sad @ sad oh_disapprove "Sympathy and compassion. Though speaking of sweetness, these leaves do make a nice tea."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0067.ogg"
    e closed_sad @ sad oh_disapprove "Simpatía y compasión. Aunque hablando de dulzura, estas hojas hacen un buen té."

# game/script.rpy:1791
translate es twentyq_e30f265b:

    # p "Ah! Perhaps you could brew us a few cups when we're done here?"
    p "¡Ah! ¿Quizás podrías prepararnos unas tazas cuando terminemos aquí?"

# game/script.rpy:1793
translate es twentyq_7919a71e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0068.ogg"
    # e forward_heart lipbite_big neutral "... Oh! What an excellent idea! Yes, I think we shall have that lemon balm tea."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0068.ogg"
    e forward_heart lipbite_big neutral "... ¡Oh! ¡Qué excelente idea! Sí, creo que tendremos ese té de melisa."

# game/script.rpy:1797
translate es twentyq_881c9cbc:

    # p "Alright, let's save some of this for the kettle."
    p "Bien, guardemos un poco para la tetera."

# game/script.rpy:1799
translate es twentyq_1c08fbca:

    # "I tuck some of the leaves around the edge of the vase,\nand following Elias' suggestions with the baby's breath, I make sure to raise some up, too."
    "Coloco algunas de las hojas alrededor del borde del jarrón,\ny siguiendo las sugerencias de Elias con la gypsophila, me aseguro de elevar algunas también."

# game/script.rpy:1803
translate es twentyq_f753de62:

    # "I try to keep it beneath the more exciting flowers, but every now and then I make sure a few of the little buds of baby's breath barely peek out from the bottoms of the lemon balm."
    "Intento mantenerlas debajo de las flores más llamativas, pero de vez en cuando me aseguro de que algunos de los pequeños brotes de gypsophila apenas asomen desde abajo de la melisa."

# game/script.rpy:1805
translate es twentyq_c7c8c3ec:

    # "Elias watches me with a polite smile, the same one I've seen so many times now. But his eyes are brighter, giving him away again: this time he's trying to downplay his joy."
    "Elias me observa con una sonrisa educada, la misma que he visto tantas veces ahora. Pero sus ojos son más brillantes, delatándolo nuevamente: esta vez intenta disimular su alegría."

# game/script.rpy:1807
translate es twentyq_789aa006:

    # p "Would you like to help arrange?"
    p "¿Quieres ayudar a arreglarlas?"

# game/script.rpy:1809
translate es twentyq_2a1b043a:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0069.ogg"
    # e forward_heart grin_teeth happy "I would love to."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0069.ogg"
    e forward_heart grin_teeth happy "Me encantaría."

# game/script.rpy:1813
translate es twentyq_73a5dc34:

    # "And Elias returns his hands to the vase, carefully making sure that what he adds complements what I've composed."
    "Y Elias vuelve sus manos al jarrón, asegurándose cuidadosamente de que lo que agrega complemente lo que yo he compuesto."

# game/script.rpy:1815
translate es twentyq_3e5c295d:

    # "Even though I've never done this before, even though I've never looked so closely at a bouquet, I can tell what I've touched and what he's touched."
    "Aunque nunca lo he hecho antes, aunque nunca he mirado tan de cerca un ramo, puedo notar qué he tocado yo y qué ha tocado él."

# game/script.rpy:1817
translate es twentyq_6c18d7ff:

    # "And honestly? All together it looks pretty good."
    "¿Y honestamente? Todo junto se ve bastante bien."

# game/script.rpy:1819
translate es twentyq_6c2853b0:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0070.ogg"
    # e closed_happy normal neutral "Lovely."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0070.ogg"
    e closed_happy normal neutral "Encantador."

# game/script.rpy:1823
translate es twentyq_dd5bdf78:

    # p "Thank you."
    p "Gracias."

# game/script.rpy:1825
translate es twentyq_a0199a29:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0071.ogg"
    # e forward_lidded_regular smug "I think, one last flower. And you should choose, my dear."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0071.ogg"
    e forward_lidded_regular smug "Creo, una última flor. Y tú deberías elegir, cariño"

# game/script.rpy:1829
translate es twentyq_1d34b397:

    # "He shows me two different flowers, one of flat, delicate yellow petals and another of thin wispy strands of purple. I don't recognize either."
    "Me muestra dos flores diferentes, una de pétalos amarillos planos y delicados y otra de finos hilos morados. No reconozco ninguna."

# game/script.rpy:1833
translate es twentyq_c3bc7233:

    # "If it's my choice again..."
    "Si es mi elección otra vez..."

# game/script.rpy:1835
translate es twentyq_49e6bbdb:

    # "I choose to savor it, to roll the flowers around in my head, and let them delight me. Why not? I don't have to understand their meanings to find them beautiful."
    "Elijo saborearla, rodar las flores en mi cabeza y dejar que me deleiten. ¿Por qué no? No necesito entender sus significados para encontrarlas hermosas."

# game/script.rpy:1837
translate es twentyq_ffcf9d63:

    # p "Hmm... The yellow ones."
    p "Hmm... Las amarillas."

# game/script.rpy:1839
translate es twentyq_1ebaf4e9:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0072.ogg"
    # e forward_lidded_regular grin_teeth "The yarrow? Excellent!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0072.ogg"
    e forward_lidded_regular grin_teeth "¿La milenrama? ¡Excelente!"

# game/script.rpy:1843
translate es twentyq_f6153ca0:

    # p "I admit that I'm unfamiliar with these."
    p "Admito que no conosco con estas."

# game/script.rpy:1845
translate es twentyq_625a077e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0073.ogg"
    # e forward_heart grin_straight happy "A symbol of everlasting love."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0073.ogg"
    e forward_heart grin_straight happy "Un símbolo de amor eterno."

# game/script.rpy:1849
translate es twentyq_d65b7d00:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0095.ogg"
    # t "... Again?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0095.ogg"
    t "... ¿Otra vez?"

# game/script.rpy:1853
translate es twentyq_21bd510a:

    # "I... chose everlasting love twice."
    "Yo... elegí amor eterno dos veces."

# game/script.rpy:1857
translate es twentyq_1b222c54:

    # "Double eternity..."
    "Doble eternidad..."

# game/script.rpy:1859
translate es twentyq_e4b7ab2c:

    # "I try not to think about it. They're only flowers, after all."
    "Intento no pensar en eso. Son solo flores, después de todo."

# game/script.rpy:1861
translate es twentyq_a91a444f:

    # "Elias and I return our hands to the bouquet, adding the final touches..."
    "Elias y yo volvemos nuestras manos al ramo, agregando los toques finales..."

# game/script.rpy:1863
translate es twentyq_addcdda3:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0074.ogg"
    # e forward_regular happy lipbite_big "The flowers look absolutely gorgeous my dear, but still nowhere near as lovely as you."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0074.ogg"
    e forward_regular happy lipbite_big "Las flores se ven absolutamente hermosas, cariño, pero aún no tan hermosas como tú."

# game/script.rpy:1867
translate es twentyq_a9c403e8:

    # p "Thank you, Elias."
    p "Gracias, Elias."

# game/script.rpy:1869
translate es twentyq_7e968f60:

    # "I can feel my heart hammering in my chest. They're just plants... Innocent little flowers."
    "Puedo sentir mi corazón latiendo con fuerza en mi pecho. Son solo plantas... Pequeñas flores inocentes."

# game/script.rpy:1871
translate es twentyq_daf18708:

    # "Flowers with too many meanings. Too many promises."
    "Flores con demasiados significados. Demasiadas promesas."

# game/script.rpy:1873
translate es twentyq_64b3a894:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0074-5.ogg"
    # e forward_lidded_regular unsure sad "Is something the matter, [your_name]? You look a bit pale."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0074-5.ogg"
    e forward_lidded_regular unsure sad "¿Pasa algo, [your_name]? Estas palideciendo un poco."

# game/script.rpy:1877
translate es twentyq_75209bd1:

    # p "I-I um, I must admit that I am a bit tired... Would it be alright for me to rest a little before we continue preparing for the ceremony?"
    p "Y-Y um, debo admitir que siento cansancio... ¿Estaría bien que descansara un poco antes de continuar con los preparativos para la ceremonia?"

# game/script.rpy:1879
translate es twentyq_861ff7d5:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0075.ogg"
    # e closed_sad frown_small "Of course, you mustn't exert yourself too much. Please feel free to choose any room on the ground floor, though you'll have to excuse the state of disarray it may be in."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0075.ogg"
    e closed_sad frown_small "Por supuesto, no debes esforzarte demasiado. Por favor, siéntete libre de elegir cualquier habitación en la planta baja, aunque tendrás que disculpar el estado de desorden en que pueda estar."

# game/script.rpy:1883
translate es twentyq_81922db4:

    # p "Thank you, my love."
    p "Gracias, mi amor."

# game/script.rpy:1885
translate es twentyq_6a847f29:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0076.ogg"
    # e forward_regular unsure neutral "And do not worry about the mess here. I shall clean up and rejoin you after I check something in the study."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0076.ogg"
    e forward_regular unsure neutral "Y no te preocupes por el desorden aquí. Limpiaré y me reuniré contigo después de revisar algo en el estudio."

# game/script.rpy:1891
translate es twentyq_f2797eae:

    # "Elias bows as I turn to leave the greenhouse."
    "Elias se inclina mientras me doy la vuelta para salir del invernadero."

# game/script.rpy:1899
translate es twentyq_5465eab5:

    # p "I would like the orange flowers, they're so striking..."
    p "Me gustaría las flores naranjas, son tan llamativas..."

# game/script.rpy:1901
translate es twentyq_53aa4a4d:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0077.ogg"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0077.ogg"

# game/script.rpy:1905
translate es twentyq_28ba9c6e:

    # e closed_happy smug happy "Hmm, yes, they are!"
    e closed_happy smug happy ""

# game/script.rpy:1907
translate es twentyq_df56a36c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0096.ogg"
    # t "[your_name], are you actually any good at flower arrangement? I wanna see this bouquet!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0096.ogg"
    t "[your_name], ¿realmente se te da el arreglo de flores? ¡Quiero ver este ramo!"

# game/script.rpy:1913
translate es twentyq_69f7450d:

    # "Honestly I have no idea what I'm doing, but I need to play it as coy as possible."
    "Honestamente, no tengo idea de lo que estoy haciendo, pero necesito actuar lo posible con timidez."

# game/script.rpy:1915
translate es twentyq_3172b2fd:

    # p "Do you think they'll make a good centerpiece?"
    p "¿Crees que serán un buen centro de mesa?"

# game/script.rpy:1917
translate es twentyq_50299e6a:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0097.ogg"
    # t "Heck yeah! Orange is a great color {i}and{/i} flavor."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0097.ogg"
    t "¡Claro que sí! El naranja es un gran color {i}y{/i} sabor."

# game/script.rpy:1921
translate es twentyq_9305d77d:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0078.ogg"
    # e forward_heart normal neutral "They're quite sentimental flowers. And I suppose that neither of us can simply drop sentimentality so easily."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0078.ogg"
    e forward_heart normal neutral "Son flores bastante sentimentales. Y supongo que ninguno de los dos puede simplemente dejar de lado la sentimentalidad tan fácilmente."

# game/script.rpy:1925
translate es twentyq_991c33dd:

    # p "True, you'd likely have moved on from this mansion, otherwise."
    p "Cierto, probablemente ya te habrías mudado de esta mansión, de no ser así."

# game/script.rpy:1927
translate es twentyq_4c92209c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0079.ogg"
    # e forward_regular grin_teeth "And you wouldn't be here either!\nI trust you understand the significance."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0079.ogg"
    e forward_regular grin_teeth "¡Y tú tampoco estarías aquí!\nConfío en que entiendes la importancia."

# game/script.rpy:1931
translate es twentyq_6b58bb3f:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0080.ogg"
    # e forward_lidded_regular normal happy "Now, what accouterments would you like to add to this? There are so many, and I want to see what you pick."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0080.ogg"
    e forward_lidded_regular normal happy "Ahora, ¿qué accesorios te gustaría agregar a esto? Hay tantos, y quiero ver cuáles eliges."

# game/script.rpy:1935
translate es twentyq_376105db:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0098.ogg"
    # t "Ooh, pick something he won't expect! Something really bold."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0098.ogg"
    t "¡Oh, elige algo que no espere! Algo realmente audaz."

# game/script.rpy:1941
translate es twentyq_1e18aec4:

    # "What could possibly stand out as bold against these bright orange flowers..."
    "¿Qué podría destacar como audaz frente a estas brillantes flores naranjas..."

# game/script.rpy:1943
translate es twentyq_55566bbb:

    # p "... Here, these lilies. The ruddy pink is striking, and these stripes are so eye-catching!"
    p "... Aquí, estos lirios. El rosa rojizo es llamativo, ¡y estas rayas son tan llamativas!"

# game/script.rpy:1945
translate es twentyq_5ec3a779:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0081.ogg"
    # e down_right grin_straight "The Peruvian lilies are certainly eye-catching. You seem to be quite a maximalist."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0081.ogg"
    e down_right grin_straight "Los lirios peruanos ciertamente llaman la atención. Pareces bastante maximalista."

# game/script.rpy:1951
translate es twentyq_a7b3ea1b:

    # "Elias blushes."
    "Elias se sonroja."

# game/script.rpy:1953
translate es twentyq_abd1b78e:

    # p "I'm quite used to exuberance in my life."
    p "Estoy tengo bastante exuberancia en mi vida."

# game/script.rpy:1955
translate es twentyq_de383a88:

    # p "Now, how about these white-tipped ones with the pink interiors?"
    p "Ahora, ¿qué tal estos con puntas blancas y interiores rosados?"

# game/script.rpy:1957
translate es twentyq_78afb395:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0082.ogg"
    # e forward_regular happy -blush @ grin_teeth "So much pink! But the pear blossoms and their white tips do add a particular gentleness."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0082.ogg"
    e forward_regular happy -blush @ grin_teeth "¡Tanto rosa! Pero las flores de pera y sus puntas blancas sí añaden una cierta delicadeza."

# game/script.rpy:1961
translate es twentyq_61fbf40a:

    # "Is it that gentle? Honestly, these three flowers together, added piece by piece into the glass vase, are blaring at me."
    "¿Es tan delicada? Honestamente, estas tres flores juntas, añadidas pieza por pieza al jarrón de vidrio, me gritan."

# game/script.rpy:1963
translate es twentyq_386a2509:

    # "I didn't think they'd be so... forceful when combined."
    "No pensé que fueran tan... impactantes cuando se combinan."

# game/script.rpy:1965
translate es twentyq_7c2d2932:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0099.ogg"
    # t "So how's it looking? Is he impressed?\nIf you get a chance, take a picture."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0099.ogg"
    t "¿Y cómo se ve? ¿Está impresionado?\nSi puedes, toma una foto."

# game/script.rpy:1969
translate es twentyq_b1e3b80a:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0100.ogg"
    # t "... Wait, a-are they ghost flowers? Can you even take pictures of ghost flowers?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0100.ogg"
    t "... Espera, ¿s-son flores fantasma? ¿Se pueden incluso tomar fotos de flores fantasma?"

# game/script.rpy:1973
translate es twentyq_6b3cbaaf:

    # p "Elias, seeing as how these aren't exactly... normal flowers, how long will this bouquet last?"
    p "Elias, considerando que estas no son exactamente... flores normales, ¿cuánto durará este ramo?"

# game/script.rpy:1975
translate es twentyq_ef927975:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0083.ogg"
    # e forward_heart smug "As long as we both desire it, and tend to it."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0083.ogg"
    e forward_heart smug "Mientras ambos lo deseemos y lo cuidemos."

# game/script.rpy:1979
translate es twentyq_2f5b14f1:

    # p "I've not tended to spirit-flowers before."
    p "Nunca he cuidado flores espirituales antes."

# game/script.rpy:1981
translate es twentyq_56d68354:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0084.ogg"
    # e closed_sad normal neutral "It's easier than you may imagine, but you have to listen to them first. They say much more than you expect."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0084.ogg"
    e closed_sad normal neutral "Es más fácil de lo que imaginas, pero primero tienes que escucharlas. Dicen mucho más de lo que esperas."

# game/script.rpy:1985
translate es twentyq_82f036eb:

    # p "What is this bouquet saying now?"
    p "¿Qué está diciendo ahora este ramo?"

# game/script.rpy:1987
translate es twentyq_95821430:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0085.ogg"
    # e forward_lidded_regular ah_sad sad "Collectively, that your loneliness leads you to needing..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0085.ogg"
    e forward_lidded_regular ah_sad sad "Colectivamente, que tu soledad te lleva a necesitar..."

# game/script.rpy:1991
translate es twentyq_acef3240:

    # e closed_sad oh_sad "..."
    e closed_sad oh_sad "..."

# game/script.rpy:1993
translate es twentyq_bf509658:

    # "{i}Needing what?{/i}"
    "{i}¿Necesitar qué?{/i}"

# game/script.rpy:1995
translate es twentyq_c307d257:

    # p "Yes, dear Elias?"
    p "Sí, querido Elias?"

# game/script.rpy:1997
translate es twentyq_f6ba2fab:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0086.ogg"
    # e unsure forward_lidded_small "A friend."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0086.ogg"
    e unsure forward_lidded_small "Un amigo."

# game/script.rpy:2003
translate es twentyq_fd5f55ba:

    # p "Oh."
    p "Oh."

# game/script.rpy:2005
translate es twentyq_c58fd86a:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0101.ogg"
    # t "Uh, quick! Pick something a bit more dramatic!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0101.ogg"
    t "¡Rápido! ¡Elige algo un poco más dramático!"

# game/script.rpy:2009
translate es twentyq_264e40ca:

    # "Taylor's right, but I have to be more careful. More thoughtful."
    "Taylor tiene razón, pero debo tener cuidado. Mas reflexion."

# game/script.rpy:2013
translate es twentyq_eb550b91:

    # "If the flowers are trying to speak to me..."
    "Si las flores están tratando de hablarme..."

# game/script.rpy:2015
translate es twentyq_66530e5a:

    # "Okay, just breathe and try to pick something that isn't so striking. An accouterment, like Elias suggested."
    "Está bien, solo respira y trata de elegir algo que no sea tan llamativo. Un accesorio, como sugirió Elias."

# game/script.rpy:2017
translate es twentyq_e38f067f:

    # "Doesn't have to be big, doesn't have to be fancy..."
    "No tiene que ser grande, no tiene que ser elegante..."

# game/script.rpy:2019
translate es twentyq_e89e0f60:

    # p "May I add these smaller flowers to the bouquet?"
    p "¿Puedo agregar estas flores más pequeñas al ramo?"

# game/script.rpy:2021
translate es twentyq_f682dd99:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0087.ogg"
    # e forward_lidded_regular neutral @ oh_disapprove "The Queen Anne's lace? Yes, that is a very interesting choice."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0087.ogg"
    e forward_lidded_regular neutral @ oh_disapprove "¿La Encaje de la Reina Ana? Sí, es una elección muy interesante."

# game/script.rpy:2025
translate es twentyq_3bc00d4c:

    # p "Explain it to me, please. I listened with my heart, but I'm not yet sure how to decipher what it means in my mind."
    p "Explícamelo, por favor. Escuché con mi corazón, pero aún no tengo seguridad de cómo descifrar lo que significa en mi mente."

# game/script.rpy:2027
translate es twentyq_774febc3:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0088.ogg"
    # e left_lidded oh_annoyed sad "There is a desire for sanctuary hidden within you."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0088.ogg"
    e left_lidded oh_annoyed sad "Hay un deseo de refugio escondido dentro de ti."

# game/script.rpy:2031
translate es twentyq_7195b1a4:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0089.ogg"
    # e tch "That pain you feel... it runs deeper than one sad day, doesn't it?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0089.ogg"
    e tch "Ese dolor que sientes... corre más profundo que un día triste, ¿no es así?"

# game/script.rpy:2035
translate es twentyq_300701d2:

    # p "I..."
    p "Yo..."

# game/script.rpy:2037
translate es twentyq_d8208a81:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0102.ogg"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0102.ogg"

# game/script.rpy:2041
translate es twentyq_7da6185a:

    # t "Bud? You doing okay over there?"
    t ""

# game/script.rpy:2043
translate es twentyq_ba545467:

    # p "I suppose it must."
    p "Supongo que debe ser."

# game/script.rpy:2045
translate es twentyq_35e7801a:

    # "Make it work, make him believe it..."
    "Haz que funcione, haz que él lo crea..."

# game/script.rpy:2047
translate es twentyq_39a96ad4:

    # p "Maybe... Maybe I was too hasty with my vows. Yes, that was most certainly it. Could I blame them for leaving me?"
    p "Quizás... Quizás fui demasiado rapido con mis votos. Sí, eso fue sin duda. ¿Podría culparlos por dejarme?"

# game/script.rpy:2051
translate es twentyq_27bb34e0:

    # p "It was my fault, wasn't it? Trying to please them without truly understanding them. Trying to please myself without even understanding my own needs..."
    p "Fue mi culpa, ¿no? Intentar complacerlos sin realmente entenderlos. Intentar complacerme a mí sin siquiera entender mis propias necesidades..."

# game/script.rpy:2053
translate es twentyq_44d743e1:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0090.ogg"
    # e forward_lidded_small frown_open "I doubt it was your fault. That it could be so simple."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0090.ogg"
    e forward_lidded_small frown_open "Dudo que haya sido tu culpa. Que pudiera ser tan simple."

# game/script.rpy:2059
translate es twentyq_8abe7511:

    # "Elias sighs, once more cupping my hands in his own."
    "Elias suspira, volviendo a tomar mis manos entre las suyas."

# game/script.rpy:2061
translate es twentyq_32681bfc:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0091.ogg"
    # e forward_lidded_regular oh_sad "Dearest, you've created a beautiful bouquet, one that comes from the deepest of hearts."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0091.ogg"
    e forward_lidded_regular oh_sad "Cariño, has creado un ramo hermoso, uno que viene del corazón más profundo."

# game/script.rpy:2065
translate es twentyq_c685beab:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0092.ogg"
    # e forward_regular neutral normal "I'll treasure the zinnias and their friends forever."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0092.ogg"
    e forward_regular neutral normal "Atesoraré siempre las zinnias y sus compañeras."

# game/script.rpy:2069
translate es twentyq_0727f575:

    # p "Elias... Thank you for understanding."
    p "Elias... Gracias por entender."

# game/script.rpy:2071
translate es twentyq_321f0ef8:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0093.ogg"
    # e sad left_lidded frown_small "Do you need a space to rest?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0093.ogg"
    e sad left_lidded frown_small "¿Necesitas un espacio para descansar?"

# game/script.rpy:2075
translate es twentyq_824a867d:

    # p "Um. In a sense. May I be alone for a moment?"
    p "Um. En cierto sentido. ¿Puedo quedarme aqui un momento?"

# game/script.rpy:2077
translate es twentyq_5f6b8931:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0094.ogg"
    # e forward_lidded_regular oh_disapprove "Yes, of course. Come find me in the study when you're ready, my love."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0094.ogg"
    e forward_lidded_regular oh_disapprove "Sí, por supuesto. Ven a buscarme en el estudio cuando tengas certeza, mi amor."

# game/script.rpy:2085
translate es twentyq_22e7816a:

    # "He floats out of the greenhouse phasing through a wall, and my breath returns to me."
    "Él flota fuera del invernadero atravesando una pared, y mi respiración vuelve a mí."

# game/script.rpy:2087
translate es twentyq_21b1d92b:

    # "My heart is pounding in my chest like a cannon!"
    "¡Mi corazón late en mi pecho como un cañón!"

# game/script.rpy:2091
translate es twentyq_b6c011a7:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0103.ogg"
    # t "Alright, did he buy it?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0103.ogg"
    t "Muy bien, ¿se lo creyó?"

# game/script.rpy:2095
translate es twentyq_0830d82c:

    # p "Taylor, do you think what he said..."
    p "Taylor, ¿crees que lo que dijo..."

# game/script.rpy:2097
translate es twentyq_1bb01731:

    # t "..."
    t "..."

# game/script.rpy:2099
translate es twentyq_c8ea8a4a_1:

    # p "..."
    p "..."

# game/script.rpy:2101
translate es twentyq_50efb65a:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0104.ogg"
    # t "... [your_name]? What he said about what? You trailed off."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0104.ogg"
    t "... [your_name]? ¿Lo que dijo sobre qué? Te quedaste en silencio."

# game/script.rpy:2105
translate es twentyq_6036d777:

    # p "Is that bouquet what I really want? Friendship and security and safety?"
    p "¿Es ese ramo lo que realmente quiero? ¿Amistad, seguridad y protección?"

# game/script.rpy:2107
translate es twentyq_c8952893:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0105.ogg"
    # t "... I mean, is it? I don't really... I don't know what to tell you."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0105.ogg"
    t "... Quiero decir, ¿lo es? Realmente... no sé qué decirte."

# game/script.rpy:2111
translate es twentyq_d6a105e3:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0106.ogg"
    # t "I guess they're not bad things to want. Especially when you're not interested in marrying a ghost."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0106.ogg"
    t "Supongo que no son cosas malas para desear. Especialmente cuando no te interesa casarte con un fantasma."

# game/script.rpy:2115
translate es twentyq_16e22ab4:

    # p "Yeah. I guess I don't know when flowers mean \"now\" and when they mean \"forever.\""
    p "Sí. Supongo que no sé cuándo las flores significan \"ahora\" y cuándo significan \"para siempre\"."

# game/script.rpy:2117
translate es twentyq_f69f9071:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0107.ogg"
    # t "They probably don't mean anything at all..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0107.ogg"
    t "Probablemente no signifiquen nada en absoluto..."

# game/script.rpy:2121
translate es twentyq_31141125:

    # p "It {i}is{/i} still a bouquet I like."
    p "Aun así, {i}es{/i} un ramo que me gusta."

# game/script.rpy:2123
translate es twentyq_4809cff3:

    # p "Uh, here."
    p "Uh, aquí."

# game/script.rpy:2125
translate es twentyq_e90a3e7f:

    # "I pull out my phone, snap a picture..."
    "Saco mi teléfono, tomo una foto..."

# game/script.rpy:2127
translate es twentyq_ca74df00:

    # "And the flowers are there on my screen just as they are in front of me."
    "Y las flores están allí en mi pantalla tal como están frente a mí."

# game/script.rpy:2129
translate es twentyq_a0d7f3aa:

    # p "Have some ghost flowers, Taylor."
    p "Toma unas flores fantasma, Taylor."

# game/script.rpy:2131
translate es twentyq_d35d652b:

    # "I shoot the picture to him via text."
    "Le envío la foto por mensaje de texto."

# game/script.rpy:2133
translate es twentyq_8f7eb0db:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0108.ogg"
    # t "... Holy crap! Man, I bet you'll never get them out of the mansion, unfortunately. I should've tried inventing a containment unit for ectobotany!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0108.ogg"
    t "... ¡Santo cielo! Hombre, apuesto a que nunca las sacarás de la mansión, desafortunadamente. ¡Debería haber intentado inventar una unidad de contención para la ectobotánica!"

# game/script.rpy:2137
translate es twentyq_93cbd3b4:

    # p "You'd never figure that out without spectral plants to test on, you goof!"
    p "¡Nunca lo habrías descubierto sin plantas espectrales para probar, tonto!"

# game/script.rpy:2139
translate es twentyq_4f29dda4:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0109.ogg"
    # t "Hey, never say never. If anyone could do it, I bet it'd be us!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0109.ogg"
    t "Oye, nunca digas nunca. Si alguien pudiera hacerlo, apuesto a que seríamos nosotros."

# game/script.rpy:2148
translate es twentyq_d197aadb:

    # p "The lyreflowers, they're so delicate-looking compared to the others. I think they'll make a perfect, understated centerpiece."
    p "Las flores lira, se ven tan delicadas comparadas con las demás. Creo que serán un centro de mesa perfecto y discreto."

# game/script.rpy:2150
translate es twentyq_622a0b3e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0095.ogg"
    # e forward_regular happy lipbite_big blush "I see, I see. They may be delicate, but they're passionate!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0095.ogg"
    e forward_regular happy lipbite_big blush "Ya veo, ya veo. Pueden ser delicadas, ¡pero son apasionadas!"

# game/script.rpy:2156
translate es twentyq_43d72467:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0096.ogg"
    # e smug "Lyreflowers, also known as \"bleeding hearts,\" \"lady in a bath,\" or even \"Venus' car,\" are flowers representative of a kind soul."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0096.ogg"
    e smug "Las flores lira, también conocidas como \"corazones sangrantes\", \"dama en baño\" o incluso \"coche de Venus\", son flores representativas de un alma bondadosa."

# game/script.rpy:2160
translate es twentyq_fc54d29b:

    # p "They're perfect!"
    p "¡Son perfectas!"

# game/script.rpy:2162
translate es twentyq_f44755b2:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0097.ogg"
    # e closed_happy lipbite_small "And what other perfect petals may we pick for this bouquet? There are many accouterments to select from... I trust you to choose well."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0097.ogg"
    e closed_happy lipbite_small "¿Y qué otros pétalos perfectos podemos elegir para este ramo? Hay muchos accesorios de donde seleccionar... Confío en que elijas bien."

# game/script.rpy:2168
translate es twentyq_5bc932db:

    # p "Let me see..."
    p "Veamos..."

# game/script.rpy:2170
translate es twentyq_741b3e71:

    # "My hand gravitates towards a bunch of simple white\nflowers to go with the lyreflowers, while I ignore Taylor's childish whining over the earpiece."
    "Mi mano se dirige hacia un manojo de flores blancas \nsimples para combinar con las flores lira, mientras ignoro los berrinches infantiles de Taylor por el auricular."

# game/script.rpy:2172
translate es twentyq_d18d47d5:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0098.ogg"
    # e forward_heart grin_teeth -blush happy "Ah, white poppies. They live in the realm of dreams, and kindness, and consolation..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0098.ogg"
    e forward_heart grin_teeth -blush happy "Ah, amapolas blancas. Viven en el reino de los sueños, la bondad y la consolación..."

# game/script.rpy:2176
translate es twentyq_6ac614a9:

    # "More white. White roses, something simple and basic."
    "Más blanco. Rosas blancas, algo simple y básico."

# game/script.rpy:2178
translate es twentyq_62024690:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0099.ogg"
    # e forward_lidded_regular smug -happy "Flowers of purity, reverence, secrecy..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0099.ogg"
    e forward_lidded_regular smug -happy "Flores de pureza, reverencia, secreto..."

# game/script.rpy:2182
translate es twentyq_1286da66:

    # "My instincts lead me to a handful of tiny little purple pinpoints of petals; for an accent, I suppose."
    "Mis instintos me llevan a un puñado de diminutos pétalos púrpura; para un acento, supongo."

# game/script.rpy:2184
translate es twentyq_dbf810f9:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0100.ogg"
    # e sad ah_sad "The stonecrops are tranquil, serene, a cure for a broken heart..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0100.ogg"
    e sad ah_sad "Las crasuláceas son tranquilas, serenas, un remedio para un corazón roto..."

# game/script.rpy:2190
translate es twentyq_6487d232:

    # p "Good choices so far?"
    p "¿Buenas elecciones hasta ahora?"

# game/script.rpy:2192
translate es twentyq_038c49fa:

    # "A frown tinges Elias' lips."
    "Un ceño tiñe los labios de Elias."

# game/script.rpy:2194
translate es twentyq_7aed41fe:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0101.ogg"
    # e frown_small forward_lidded_regular concerned "... Y-yes."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0101.ogg"
    e frown_small forward_lidded_regular concerned "... S-sí."

# game/script.rpy:2198
translate es twentyq_6ce8e692:

    # p "You sound unsure."
    p "Pareces inseguro."

# game/script.rpy:2204
translate es twentyq_30e4bf81:

    # "Not just unsure, but almost on the verge of a panic attack... though that probably isn't a good thing to say to him. "
    "No solo inseguro, sino casi al borde de un ataque de pánico... aunque probablemente no sea bueno decírselo."

# game/script.rpy:2206
translate es twentyq_f32f5184:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0102.ogg"
    # e closed_sad sweat frown_open "They're very familiar choices to me. And perhaps familiar to you."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0102.ogg"
    e closed_sad sweat frown_open "Son elecciones muy familiares para mí. Y quizás familiares para ti."

# game/script.rpy:2210
translate es twentyq_83121c5f:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0103.ogg"
    # e forward_lidded_small squiggle "What bouquet did you carry to the altar before?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0103.ogg"
    e forward_lidded_small squiggle "¿Qué ramo llevaste al altar antes?"

# game/script.rpy:2216
translate es twentyq_e51d98e0:

    # "He looks at me sternly, brows furrowed in concern."
    "Me mira severamente, cejas fruncidas por la preocupación."

# game/script.rpy:2218
translate es twentyq_300701d2_1:

    # p "I..."
    p "Yo..."

# game/script.rpy:2222
translate es twentyq_10201d40:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0110.ogg"
    # t "Crap, didn't think he'd actually ask that. Uhhh, make something up!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0110.ogg"
    t "Mierda, no pensé que realmente preguntaría eso. Uh, ¡invéntate algo!"

# game/script.rpy:2226
translate es twentyq_d3244d22:

    # p "... Truthfully? I can barely recall. They weren't picked by me. I can only remember a haze of blues and pinks through the tears..."
    p "... ¿La verdad? Apenas lo recuerdo. No fueron escogidas por mí. Solo puedo recordar una neblina de azules y rosas entre las lágrimas..."

# game/script.rpy:2228
translate es twentyq_cf399ef0:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0104.ogg"
    # e closed_sad oh_sad sad -sweat "I'm so sorry. Perhaps that was too much for you at this moment."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0104.ogg"
    e closed_sad oh_sad sad -sweat "Lo siento mucho. Tal vez eso fue demasiado para ti en este momento."

# game/script.rpy:2232
translate es twentyq_ad2edf46:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0105.ogg"
    # e down_right squiggle disapprove "But I do think you are being hasty. The flowers are lovely together, but the lyreflowers are so dominant... A little too passionate."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0105.ogg"
    e down_right squiggle disapprove "Pero sí creo que te estas precipitando. Las flores se ven encantadoras juntas, pero las lyreflowers son tan dominantes... Un poco demasiado apasionadas."

# game/script.rpy:2236
translate es twentyq_91d286da:

    # p "Let me choose one more, as a proper complement."
    p "Déjame escoger una más, como un complemento apropiado."

# game/script.rpy:2238
translate es twentyq_5906ebfd:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0106.ogg"
    # e forward_lidded_regular frown_disapprove concerned "Please do, and take your time. Nothing will hurt you here. I will make sure of that."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0106.ogg"
    e forward_lidded_regular frown_disapprove concerned "Por favor, hazlo, y tómate tu tiempo. Nada te hará daño aquí. Me aseguraré de eso."

# game/script.rpy:2242
translate es twentyq_438e44f8:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0111.ogg"
    # t "Uh-huh, sure you will."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0111.ogg"
    t "Uh-huh, claro que sí."

# game/script.rpy:2248
translate es twentyq_889547fa:

    # "I look over the flowers as slowly as I can, hoping that I can find one that Elias won't freak out over."
    "Miro las flores lo más lentamente posible, esperando poder encontrar una que a Elias no le haga perder la cabeza."

# game/script.rpy:2250
translate es twentyq_f1382217:

    # "God, who thought picking flowers would be so stressful? I'm honestly just choosing what looks aesthetically pleasing...\nPerhaps something with heavy contrast."
    "Dios, ¿quién pensó que escoger flores sería tan estresante? Honestamente solo estoy eligiendo lo que se ve estéticamente agradable...\nQuizá algo con alto contraste."

# game/script.rpy:2252
translate es twentyq_1a555cf4:

    # "Here's something, deep blue and sharp. I think this will have to do."
    "Aquí hay algo, azul profundo y afilado. Creo que esto servirá."

# game/script.rpy:2254
translate es twentyq_b8e42144:

    # p "This flower, if you don't mind?"
    p "¿Esta flor, si no te importa?"

# game/script.rpy:2256
translate es twentyq_7216434f:

    # e forward_lidded_small sad @ oh_disapprove "..."
    e forward_lidded_small sad @ oh_disapprove "..."

# game/script.rpy:2260
translate es twentyq_3a42e3b5:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0112.ogg"
    # t "H-hey uh, what's going on [your_name]?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0112.ogg"
    t "H-hola eh, ¿qué está pasando [your_name]?"

# game/script.rpy:2264
translate es twentyq_708c0d9c:

    # e forward_lidded_small frown_small "..."
    e forward_lidded_small frown_small "..."

# game/script.rpy:2266
translate es twentyq_50fa6a01:

    # p "... Maybe not, dear?"
    p "... ¿Quizá no, cariño?"

# game/script.rpy:2268
translate es twentyq_95ca48a6:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0107.ogg"
    # e forward_lidded_small frown_disapprove "... Vi..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0107.ogg"
    e forward_lidded_small frown_disapprove "... Vi..."

# game/script.rpy:2272
translate es twentyq_31f4a273:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0113.ogg"
    # t "Euugh, I'm getting static again, the hell—?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0113.ogg"
    t "Euugh, estoy recibiendo estática otra vez, ¿qué demonios—?"

# game/script.rpy:2276
translate es twentyq_3c78c720:

    # p "You can say no..."
    p "Puedes decir que no..."

# game/script.rpy:2278
translate es twentyq_56f1c8c3:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0108.ogg"
    # e frown_open forward_small neutral "Vi... Violet..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0108.ogg"
    e frown_open forward_small neutral "Vi... Violet..."

# game/script.rpy:2282
translate es twentyq_2ccd087f:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0114.ogg"
    # t "[your_name], s-status report! You're cutting out again—"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0114.ogg"
    t "[your_name], ¡informe de estado! Estás cortando la señal otra vez—"

# game/script.rpy:2292
translate es twentyq_90548d00:

    # "Something crashes to the ground and shatters like a meteor striking the mansion, and a spotlight shines on my regretful face."
    "Algo cae al suelo y se rompe como un meteorito golpeando la mansión, y un foco ilumina mi rostro lleno de arrepentimiento."

# game/script.rpy:2296
translate es twentyq_b4b403fe:

    # "And... the sun is out...? The sharp rays of light beam through the greenhouse glass, and all I can see is haze."
    "Y... ¿el sol está afuera...? Los rayos agudos de luz atraviesan el vidrio del invernadero, y todo lo que puedo ver es neblina."

# game/script.rpy:2300
translate es twentyq_7d85f9d8:

    # "Something is very wrong."
    "Algo está muy mal."

# game/script.rpy:2302
translate es twentyq_735c9c16:

    # "Movement — shadows — outside a window.\nDare I to look? I have to look."
    "Movimiento — sombras — fuera de una ventana.\n¿Me atrevo a mirar? Tengo que mirar."

# game/script.rpy:2308
translate es twentyq_12c674e5:

    # "An archway, a gazebo, baking in the blazing sun. A lush garden with the promise of life; sickeningly sweet scents hanging in the air."
    "Un arco, un gazebo, horneándose bajo el sol abrasador. Un jardín exuberante con la promesa de vida; aromas dulces nauseabundos flotando en el aire."

# game/script.rpy:2322
translate es twentyq_71f60730:

    # "She brushes past me like I'm not there."
    "Ella pasa rozándome como si yo no estuviera allí."

# game/script.rpy:2324
translate es twentyq_2955028f:

    # "Who is she?"
    "¿Quién es ella?"

# game/script.rpy:2326
translate es twentyq_60fec714:

    # "{i}Who is she?{/i}"
    "{i}¿Quién es ella?{/i}"

# game/script.rpy:2328
translate es twentyq_becacf93:

    # "Elias knows.\nElias {i}must{/i} know."
    "Elias sabe.\nElias {i}debe{/i} saber."

# game/script.rpy:2330
translate es twentyq_c35b8d29:

    # "Violet?"
    "¿Violet?"

# game/script.rpy:2336
translate es twentyq_4a9fe9a3:

    # "She walks between the shadows cast by the trees. Through the arch. Under the gazebo."
    "Camina entre las sombras proyectadas por los árboles. A través del arco. Bajo el gazebo."

# game/script.rpy:2338
translate es twentyq_c1e490db:

    # "And still she's here beside me. Even so far away, she's still here."
    "Y aún así está aquí a mi lado. Incluso tan lejos, sigue aquí."

# game/script.rpy:2359
translate es twentyq_637d96eb:

    # "The wind catches her sunhat while the sun hits a single point on her bosom, reflecting right into my eyes."
    "El viento atrapa su sombrero mientras el sol golpea un solo punto en su pecho, reflejándose directamente en mis ojos."

# game/script.rpy:2361
translate es twentyq_0b3b8464:

    # "Violet's gown, Violet's trail, they stretch into a past that refuses to be forgotten."
    "El vestido de Violet, el rastro de Violet, se extienden hacia un pasado que se niega a ser olvidado."

# game/script.rpy:2363
translate es twentyq_7a66985e:

    # "I look for Elias, wonder why I cannot see him, and call his name to the sea of green shrubbery."
    "Busco a Elias, me pregunto por qué no puedo verlo, y llamo su nombre al mar de arbustos verdes."

# game/script.rpy:2367
translate es twentyq_1ae48285:

    # "The garden cannot be asked to care."
    "No se le puede pedir al jardín que se preocupe."

# game/script.rpy:2373
translate es twentyq_e26e242d:

    # "Violet turns her head towards the interruptor."
    "Violet gira la cabeza hacia quien interrumpe."

# game/script.rpy:2375
translate es twentyq_f041452e:

    # "I see—"
    "Veo—"

# game/script.rpy:2383
translate es twentyq_32e15369:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0109.ogg"
    # e "A-aaugghh!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0109.ogg"
    e "¡A-aaugghh!"

# game/script.rpy:2397
translate es twentyq_c69b61be:

    # "Elias crumbles towards the ground!"
    "¡Elias se desploma hacia el suelo!"

# game/script.rpy:2401
translate es twentyq_6f81e12d:

    # "Without thinking, I try to catch him in my arms\nto keep him from collapsing. Well, as much as one can keep a ghost from collapsing, at least."
    "Sin pensarlo, intento atraparlo en mis brazos\npara evitar que colapse. Bueno, tanto como uno puede evitar que un fantasma colapse, al menos."

# game/script.rpy:2406
translate es twentyq_261051a5:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0110.ogg"
    # e forward_lidded_small sad frown_disapprove "Ahhh, [your_name]..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0110.ogg"
    e forward_lidded_small sad frown_disapprove "Ahhh, [your_name]..."

# game/script.rpy:2410
translate es twentyq_495e7d8e:

    # p "I didn't know I could catch you like that."
    p "No sabía que podía atraparte así."

# game/script.rpy:2412
translate es twentyq_7f7abeaa:

    # "Nothing remains besides myself, Elias, and the greenhouse.\nThe day is gone, the garden outside is gone, and Violet too is gone."
    "Nada queda más que yo, Elias y el invernadero.\nEl día se ha ido, el jardín afuera se ha ido, y Violet también se ha ido."

# game/script.rpy:2417
translate es twentyq_5f422e0b:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0115.ogg"
    # t "Hey! Hey! Are you there?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0115.ogg"
    t "¡Hey! ¡Hey! ¿Estás ahí?"

# game/script.rpy:2423
translate es twentyq_63ed1c96:

    # "Taylor's worried voice buzzes in my ear."
    "La preocupada voz de Taylor vibra en mi oído."

# game/script.rpy:2425
translate es twentyq_a4a0165d:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0116.ogg"
    # t "Everything went static for a minute!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0116.ogg"
    t "¡Todo se volvió estático por un minuto!"

# game/script.rpy:2429
translate es twentyq_db44632d:

    # p "Elias, I didn't mean to do anything that would hurt you..."
    p "Elias, no quise hacer nada que te lastimara..."

# game/script.rpy:2431
translate es twentyq_78e6ab49:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0111.ogg"
    # e right_lidded ah_sad sweat "No, you didn't... I left those flowers there, after all. You chose fairly, and you made a beautiful bouquet."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0111.ogg"
    e right_lidded ah_sad sweat "No, no lo hiciste... Después de todo, dejé esas flores ahí. Escogiste justamente y hiciste un hermoso ramo."

# game/script.rpy:2435
translate es twentyq_5c2b109a:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0112.ogg"
    # e closed_sad @ disapprove oh_disapprove "I apologize for worrying you!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0112.ogg"
    e closed_sad @ disapprove oh_disapprove "¡Perdón por preocuparte!"

# game/script.rpy:2439
translate es twentyq_7947e919:

    # p "Elias, go lay down, please. I'll redo the bouquet."
    p "Elias, ve a acostarte, por favor. Yo rehago el ramo."

# game/script.rpy:2441
translate es twentyq_f6f80f48:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0113.ogg"
    # e forward_lidded_smaller oh_annoyed "I assure you that won't be necessary, but thank you. I should clean this up..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0113.ogg"
    e forward_lidded_smaller oh_annoyed "Te aseguro que no será necesario, pero gracias. Debo limpiar esto..."

# game/script.rpy:2447
translate es twentyq_5018986b:

    # p "We'll clean up together."
    p "Limpiemos juntos."

# game/script.rpy:2452
translate es twentyq_a9b85371:

    # "We work in a tense silence to tidy the greenhouse. I'm worried about Elias, though I wonder what sort of exhaustion ghosts can feel."
    "Trabajamos en un silencio tenso para ordenar el invernadero. Me preocupa Elias, aunque me pregunto qué tipo de agotamiento pueden sentir los fantasmas."

# game/script.rpy:2464
translate es twentyq_b3105789:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0114.ogg"
    # e "My gratitude to you, [your_name]. I'm afraid I must take a moment to gather my wits before I look for my grandmother's recipes."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0114.ogg"
    e "Mi gratitud para ti, [your_name]. Me temo que debo tomar un momento para recomponerme antes de buscar las recetas de mi abuela."

# game/script.rpy:2468
translate es twentyq_0bd37268:

    # p "Do you want me to accompany you?"
    p "¿Quieres que te acompañe?"

# game/script.rpy:2470
translate es twentyq_247b3136:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0115.ogg"
    # e forward_lidded_smaller oh_annoyed sad "I'm flattered... but a bit of privacy would be appreciated."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0115.ogg"
    e forward_lidded_smaller oh_annoyed sad "Me halagas... pero un poco de privacidad sería apreciada."

# game/script.rpy:2474
translate es twentyq_061ded54:

    # p "I understand. May I look around the manor while I wait?"
    p "Entiendo. ¿Puedo mirar alrededor de la mansión mientras espero?"

# game/script.rpy:2478
translate es twentyq_774943c2:

    # "Elias stares past me, not answering for a moment."
    "Elias mira más allá de mí, sin responder por un momento."

# game/script.rpy:2480
translate es twentyq_f91e93c6:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0116.ogg"
    # e closed_sad ah_sad neutral "You may, so long as you stay on the ground floor, and please excuse the state of disarray the rooms may be in."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0116.ogg"
    e closed_sad ah_sad neutral "Puedes, siempre que te quedes en la planta baja, y por favor disculpa el estado de desorden que puedan tener las habitaciones."

# game/script.rpy:2486
translate es twentyq_29920635:

    # "He bows, and I return the gesture. Not long after, he phases through a wall, leaving me alone in the greenhouse."
    "Se inclina, y yo devuelvo el gesto. No mucho después, atraviesa una pared, dejándome sola en el invernadero."

# game/script.rpy:2488
translate es twentyq_c8ea8a4a_2:

    # p "..."
    p "..."

# game/script.rpy:2490
translate es twentyq_d9eee4f8:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0117.ogg"
    # t "Okay [your_name], you alone?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0117.ogg"
    t "Okay [your_name], ¿no hay nadie?"

# game/script.rpy:2494
translate es twentyq_e0d8740f:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0118.ogg"
    # t "Who... was that woman?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0118.ogg"
    t "¿Quién... era esa mujer?"

# game/script.rpy:2498
translate es twentyq_c3a80394:

    # p "... You heard something?"
    p "... ¿Oíste algo?"

# game/script.rpy:2500
translate es twentyq_6e97d3a6:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0119.ogg"
    # t "I heard someone whispering through all the static. A woman, I think. Didn't sound like anyone I recognize!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0119.ogg"
    t "Oí a alguien susurrando entre toda la estática. Una mujer, creo. ¡No sonaba como nadie que reconozca!"

# game/script.rpy:2504
translate es twentyq_7e317769:

    # p "I... I think I met Violet Dupont."
    p "Yo... creo que conocí a Violet Dupont."

# game/script.rpy:2506
translate es twentyq_0befef4e:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0120.ogg"
    # t "Is her spirit there too?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0120.ogg"
    t "¿Su espíritu también estaba ahí?"

# game/script.rpy:2510
translate es twentyq_fcacbc3e:

    # p "It was like... a vision I think.\nI don't know. Just... let me catch my breath."
    p "Fue como... una visión, creo.\nNo sé. Solo... déjame recuperar el aliento."

# game/script.rpy:2512
translate es twentyq_5d5fe328:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0121.ogg"
    # t "Yeah, take your time."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0121.ogg"
    t "Sí, tómate tu tiempo."

# game/script.rpy:2522
translate es twentyq_961703dd:

    # "My steps feel heavy as I return to the hallway. I wasn't expecting floral arrangements to be that intense."
    "Mis pasos se sienten pesados al regresar al pasillo. No esperaba que los arreglos florales fueran tan intensos."

# game/script.rpy:2524
translate es twentyq_5766e99d:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0122.ogg"
    # t "Hey, are you doin' alright now?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0122.ogg"
    t "Hey, ¿estás bien ahora?"

# game/script.rpy:2528
translate es twentyq_7c3719f8:

    # p "I'll live."
    p "Sobreviviré."

# game/script.rpy:2530
translate es twentyq_08207ed8:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0123.ogg"
    # t "Might be time to see what you can get up to before your rendezvous with Elias..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0123.ogg"
    t "Quizá sea hora de ver qué puedes hacer antes de tu encuentro con Elias..."

# game/script.rpy:2534
translate es twentyq_b48b8652:

    # "I nod my head, as if Taylor\ncan somehow see me through the earpiece."
    "Asiento con la cabeza, como si Taylor\npudiera verme de alguna manera a través del auricular."

# game/script.rpy:2540
translate es twentyq_f7c268af:

    # "Back to where it all began. The dust isn't so thick now, and while it doesn't look all too fabulous compared to the rest of the place, it looks a little less uninviting."
    "De vuelta a donde todo comenzó. El polvo ya no es tan espeso, y aunque no se ve tan fabuloso comparado con el resto del lugar, se ve un poco menos poco acogedor."

# game/script.rpy:2542
translate es twentyq_536fa8b0:

    # p "Hey, you remember that painting I mentioned before? In the foyer?"
    p "Hey, ¿recuerdas la pintura que mencioné antes? ¿En el vestíbulo?"

# game/script.rpy:2544
translate es twentyq_1f278124:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0124.ogg"
    # t "On the second floor, yup. What about it?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0124.ogg"
    t "En el segundo piso, sí. ¿Qué pasa con ella?"

# game/script.rpy:2550
translate es twentyq_02d3e0bd:

    # p "I think I can make out a few of the details better now, maybe even get a pic of it."
    p "Creo que ahora puedo distinguir algunos detalles mejor, quizá incluso sacar una foto."

# game/script.rpy:2552
translate es twentyq_3295cbc7:

    # "I test my foot on the first step and angle my camera up to snap a photo of the frame. When the deed is done, I text it to Taylor."
    "Pruebo mi pie en el primer escalón y apunto mi cámara hacia el marco para tomar la foto. Cuando termino, se la envío a Taylor."

# game/script.rpy:2554
translate es twentyq_7ffb5615:

    # p "Here you go, if I had to hazard a guess then this style of painting would be Impressionism."
    p "Aquí tienes, si tuviera que arriesgarme a adivinar, entonces este estilo de pintura sería Impresionismo."

# game/script.rpy:2556
translate es twentyq_12afe443:

    # p "It was all the rage in the late 19th century so it'd fit the timeline. Know anything about the subject?"
    p "Estuvo de moda a finales del siglo XIX, así que encajaría en la línea de tiempo. ¿Sabes algo del tema?"

# game/script.rpy:2558
translate es twentyq_9d0d4a15:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0125.ogg"
    # t "It's probably a portrait of one of the Gallagher ladies. What better way to flaunt wealth and status than by paying someone to preserve your likeness with expensive materials?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0125.ogg"
    t "Probablemente sea un retrato de una de las damas Gallagher. ¿Qué mejor manera de presumir riqueza y estatus que pagando a alguien para preservar tu imagen con materiales caros?"

# game/script.rpy:2562
translate es twentyq_f796db8b:

    # "I zoom in on the photo I took and study the details. I assume Taylor's doing the same."
    "Hago zoom en la foto que tomé y estudio los detalles. Supongo que Taylor hace lo mismo."

# game/script.rpy:2564
translate es twentyq_47c690cc:

    # p "Those earrings and necklace... and the size of that ring too, damn. That's too rich for my blood."
    p "Esos pendientes y el collar... y el tamaño de ese anillo también, maldita sea. Eso es demasiado lujoso para mi gusto."

# game/script.rpy:2566
translate es twentyq_edf0bbe0:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0126.ogg"
    # t "Probably the precious \"family jewels\" Elias was telling you about."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0126.ogg"
    t "Probablemente las \"joyas familiares\" preciosas de las que Elias te hablaba."

# game/script.rpy:2570
translate es twentyq_77591aff:

    # "Taylor snickers. I roll my eyes with a groan."
    "Taylor se ríe. Yo pongo los ojos en blanco con un gemido."

# game/script.rpy:2572
translate es twentyq_d32c185a:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0127.ogg"
    # t "Anyways, I'll look into this and see if I can get an exact match for who it might be. Keep hunting around?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0127.ogg"
    t "De todos modos, investigaré esto para ver si puedo encontrar una coincidencia exacta de quién podría ser. ¿Sigues buscando por ahí?"

# game/script.rpy:2578
translate es twentyq_5b72cbe4:

    # p "Roger that."
    p "Entendido."

# game/script.rpy:2582
translate es twentyq_0f0e7744:

    # "I pick one of the many doors in the foyer and swing it open, wincing a little at how badly it needs to be oiled."
    "Escojo una de las muchas puertas del vestíbulo y la abro de golpe, haciendo una mueca por lo mal que necesita aceite."

# game/script.rpy:2586
translate es twentyq_89c7e8af:

    # "Huh, Elias wasn't kidding when he said that some of the rooms would be in disarray. It definitely doesn't look as nice as the study."
    "Huh, Elias no bromeaba cuando dijo que algunas habitaciones estarían desordenadas. Definitivamente no se ve tan bien como el estudio."

# game/script.rpy:2588
translate es twentyq_2169ce0f:

    # p "I think this is a living room. Or a lounge. There's couches, at least."
    p "Creo que esto es una sala de estar. O un salón. Al menos hay sofás."

# game/script.rpy:2590
translate es twentyq_88548d98:

    # "The patterns have worn off them, and the material is torn open in a few places. I run my hand over the back of the loveseat. "
    "Los patrones se han desgastado y el material está rasgado en algunos lugares. Paso mi mano por el respaldo del loveseat."

# game/script.rpy:2592
translate es twentyq_1f73c82b:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0128.ogg"
    # t "Anything interesting there?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0128.ogg"
    t "¿Algo interesante allí?"

# game/script.rpy:2596
translate es twentyq_a7c12c8c:

    # p "Aside from the couches, there's a rocking chair, a mounted deer head, a painting of a building, a grandfather clock, and a bookshelf."
    p "Aparte de los sofás, hay una mecedora, una cabeza de ciervo montada, una pintura de un edificio, un reloj de pie y una estantería."

# game/script.rpy:2598
translate es twentyq_b4dbb706:

    # p "Elias hasn't worked his magic here so it's a bit decrepit."
    p "Elias no ha hecho su magia aquí, así que está un poco deteriorado."

# game/script.rpy:2600
translate es twentyq_691378fc:

    # p "I'll investigate everything else before I take a look at the books. I wouldn't even know where to begin with that, anyways."
    p "Investigaré todo lo demás antes de mirar los libros. De todas formas, ni siquiera sabría por dónde empezar con eso."

# game/script.rpy:2612
translate es investigation_1_92d0083d:

    # "I walk over to the mounted deer head and peer into its soulless, long-dead eyes. Taxidermy always freaked me out as a kid, and that never changed as I got older."
    "Me acerco a la cabeza de ciervo montada y miro sus ojos sin alma, muertos hace mucho. La taxidermia siempre me asustó de peque, y eso nunca cambió al crecer."

# game/script.rpy:2614
translate es investigation_1_8a12b8d1:

    # p "The Gallagher men liked to hunt for sport, didn't they?"
    p "A los hombres Gallagher les gustaba cazar por deporte, ¿no?"

# game/script.rpy:2616
translate es investigation_1_82bc9c8b:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0129.ogg"
    # t "All of them but Elias."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0129.ogg"
    t "Todos menos Elias."

# game/script.rpy:2620
translate es investigation_1_6ad0d4af:

    # "From my interactions with him he probably couldn't even hurt a fly."
    "Por mis interacciones con él, probablemente ni siquiera podría hacerle daño a una mosca."

# game/script.rpy:2622
translate es investigation_1_4c4f05fc:

    # p "I don't really see the point of killing animals for fun. Like at least eat the venison, you know?"
    p "Realmente no veo el sentido de matar animales por diversión. Al menos come la carne de venado, ¿sabes?"

# game/script.rpy:2624
translate es investigation_1_bfc907bc:

    # p "I'm actually surprised I don't see any rifles mounted on the walls for decoration."
    p "De hecho me sorprende no ver ningún rifle montado en las paredes como decoración."

# game/script.rpy:2626
translate es investigation_1_612a77d1:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0130.ogg"
    # t "How big are the antlers on that deer anyway?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0130.ogg"
    t "¿Qué tan grandes son las astas de ese ciervo, de todos modos?"

# game/script.rpy:2630
translate es investigation_1_ad1d88cf:

    # p "Really small, nothing to write home about."
    p "Realmente pequeñas, nada del otro mundo."

# game/script.rpy:2632
translate es investigation_1_b3e086e2:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0131.ogg"
    # t "Did you know that in the winter, deer, moose, and other mammals who grow antlers will just shake them clean off? Maybe they shot that deer in the spring when it was regrowing them."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0131.ogg"
    t "¿Sabías que en invierno, los ciervos, alces y otros mamíferos que crecen astas simplemente las sacuden para limpiarlas? Quizá dispararon a ese ciervo en primavera cuando estaba regenerándolas."

# game/script.rpy:2636
translate es investigation_1_fca9089e:

    # p "Huh, thanks for the fun trivia."
    p "Huh, gracias por la curiosidad divertida."

# game/script.rpy:2644
translate es investigation_1_25cbd69f:

    # "I peer at the face of the grandfather clock, frowning when I notice that the hands are {i}missing{/i}."
    "Miro el rostro del reloj de pie, frunciendo el ceño cuando noto que las manecillas están {i}ausentes{/i}."

# game/script.rpy:2646
translate es investigation_1_399929ff:

    # p "I know analog clocks are a thing of the past,\nbut I really like the aesthetics of a ticking clock. There's just something about them that's so cool."
    p "Sé que los relojes analógicos son cosa del pasado,\npero realmente me gusta la estética de un reloj que hace tictac. Hay algo en ellos que es tan genial."

# game/script.rpy:2648
translate es investigation_1_47c73138:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0132.ogg"
    # t "You think so? I feel like they're too inaccurate. If a gear stops turning or the battery dies out, then you have to manually set it again. Digital clocks hook up to the internet so they don't have that problem."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0132.ogg"
    t "¿Tú crees? Siento que son demasiado inexactos. Si un engranaje deja de girar o la batería se agota, tienes que ajustarlo manualmente. Los relojes digitales se conectan a internet, así que no tienen ese problema."

# game/script.rpy:2652
translate es investigation_1_cddaa2e3:

    # p "Taylor, you're missing the point. It's about the {i}aesthetics{/i}."
    p "Taylor, no entiendes el punto. Se trata de la {i}estética{/i}."

# game/script.rpy:2654
translate es investigation_1_92f55c0a:

    # "Taylor lets out a loud grumble instead of bothering to argue with me."
    "Taylor deja escapar un gruñido fuerte en lugar de molestarse en discutir conmigo."

# game/script.rpy:2664
translate es investigation_1_e2a5a698:

    # "Another impressionist painting, this time of a building's facade. It doesn't seem to be the manor though, so I wonder if this painting has any significance."
    "Otra pintura impresionista, esta vez de la fachada de un edificio. No parece ser la mansión, así que me pregunto si esta pintura tiene algún significado."

# game/script.rpy:2666
translate es investigation_1_197854e8:

    # p "Do you know if there are any secret passages in the mansion?"
    p "¿Sabes si hay pasadizos secretos en la mansión?"

# game/script.rpy:2668
translate es investigation_1_002c0213:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0133.ogg"
    # t "I wouldn't doubt it since the Gallaghers had this place built just for them, but I wouldn't know where they are. They're secret for a reason."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0133.ogg"
    t "No lo dudaría, ya que los Gallagher hicieron construir este lugar solo para ellos, pero no sabría dónde están. Son secretos por una razón."

# game/script.rpy:2672
translate es investigation_1_39a19dee:

    # p "Gee, thanks."
    p "Vaya, gracias."

# game/script.rpy:2676
translate es investigation_1_fd060089:

    # "I try to lift up the painting just enough to see if there's anything behind it. There isn't."
    "Intento levantar la pintura lo suficiente para ver si hay algo detrás. No lo hay."

# game/script.rpy:2684
translate es investigation_1_5e0e6efa:

    # p "Hey Taylor, I've looked at everything else aside from the shelf, so I'm gonna check out the books. Any ideas on where to start?"
    p "Hey Taylor, he revisado todo lo demás aparte de la estantería, así que voy a revisar los libros. ¿Alguna idea de por dónde empezar?"

# game/script.rpy:2686
translate es investigation_1_1799679e:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0134.ogg"
    # t "Tell me what you're lookin' at."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0134.ogg"
    t "Dime qué estás mirando."

# game/script.rpy:2690
translate es investigation_1_afa2cd90:

    # "I scan the spines for titles."
    "Escaneo los lomos en busca de títulos."

# game/script.rpy:2692
translate es investigation_1_c2f86b57:

    # p "There's an encyclopedia series, a dictionary, a thesaurus, a bible, bible hymns... an assortment of Shakespearan plays..."
    p "Hay una serie de enciclopedias, un diccionario, un tesauro, una biblia, himnos bíblicos... una mezcla de obras de Shakespeare..."

# game/script.rpy:2694
translate es investigation_1_207add7e:

    # "I pull out the old tome of Romeo & Juliet and flip through the yellowed pages... or at least try to. The corners of the pages disintegrate in my fingers."
    "Saco el viejo tomo de Romeo & Juliet y hojeo las páginas amarillentas... o al menos intento. Las esquinas de las páginas se deshacen entre mis dedos."

# game/script.rpy:2698
translate es investigation_1_11b77de2:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0135.ogg"
    # t "... Haha, bingo! I finally got a match on the painting from earlier."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0135.ogg"
    t "... ¡Ja, bingo! Finalmente encontré una coincidencia con la pintura de antes."

# game/script.rpy:2702
translate es investigation_1_150ceb20:

    # p "Oh yeah? Who is it?"
    p "¿Ah sí? ¿Quién es?"

# game/script.rpy:2704
translate es investigation_1_993e8b58:

    # "I slide the book in my hand back onto the shelf before hazarding a seat on one of the couches."
    "Deslizo el libro de vuelta a la estantería antes de aventurarme a sentarme en uno de los sofás."

# game/script.rpy:2706
translate es investigation_1_9cee3dba:

    # "Moments later, Taylor texts me an old black and white photo."
    "Momentos después, Taylor me envía un viejo foto en blanco y negro."

# game/script.rpy:2708
translate es investigation_1_bba4c2b5:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0136.ogg"
    # t "Check it out, that's Mama Gallagher herself. Mildred loved to host tea parties and dances at the manor; always made a grand show of the family bling while she was at it."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0136.ogg"
    t "Mira, esa es la mismísima mamá Gallagher. A Mildred le encantaba organizar fiestas de té y bailes en la mansión; siempre hacía un gran despliegue de las joyas de la familia mientras estaba en ello."

# game/script.rpy:2714
translate es investigation_1_069851ec:

    # p "I don't blame her, she's very beautiful."
    p "No la culpo, es muy hermosa."

# game/script.rpy:2716
translate es investigation_1_00763a69:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0137.ogg"
    # t "She was the envy of the land until that Gallagher curse killed her."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0137.ogg"
    t "Fue la envidia de la región hasta que la maldición Gallagher la mató."

# game/script.rpy:2720
translate es investigation_1_190cd814:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0138.ogg"
    # t "Anyways, that's one mystery solved.\nThink there's anything else in here?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0138.ogg"
    t "De todos modos, un misterio resuelto.\n¿Crees que haya algo más aquí?"

# game/script.rpy:2724
translate es investigation_1_219672fc:

    # "I stand up and check the shelf again."
    "Me pongo de pie y reviso la estantería otra vez."

# game/script.rpy:2728
translate es investigation_1_91b963c0:

    # p "Oh, there's a children's picture book here about clowns?"
    p "Oh, ¿hay un libro de imágenes para niños aquí sobre payasos?"

# game/script.rpy:2730
translate es investigation_1_e4bf1cb4:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0139.ogg"
    # t "D-don't open that!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0139.ogg"
    t "¡N-no abras eso!"

# game/script.rpy:2734
translate es investigation_1_d56db28c:

    # p "Pft, okay nerd. Well nothing else really calls out to me, so I'm going to the next room over."
    p "Pft, está bien nerd. Bueno, nada más realmente me llama la atención, así que voy a la habitación contigua."

# game/script.rpy:2736
translate es investigation_1_6e71f23d:

    # "I pause momentarily."
    "Hago una pausa momentánea."

# game/script.rpy:2738
translate es investigation_1_e87878f4:

    # p "... Uh, over?"
    p "... Uh, ¿a la contigua?"

# game/script.rpy:2740
translate es investigation_1_4e919930:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0140.ogg"
    # t "Heh, roger that."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0140.ogg"
    t "Heh, entendido."

# game/script.rpy:2748
translate es investigation_1_ca5c7066:

    # "I slip back out into the foyer and stare down the other doors. A map of this place would really help right now."
    "Me deslizo de vuelta al vestíbulo y miro las otras puertas. Un mapa de este lugar realmente ayudaría ahora mismo."

# game/script.rpy:2750
translate es investigation_1_5368e01c:

    # p "Well, here we go."
    p "Bueno, aquí vamos."

# game/script.rpy:2758
translate es investigation_1_4e185bb0:

    # "I push past another door at random and peek my head inside before walking in."
    "Empujo otra puerta al azar y asomo la cabeza antes de entrar."

# game/script.rpy:2760
translate es investigation_1_b3d75145:

    # "It's a modestly-sized room with a rectangular wooden table surrounded by chairs, along with a small chandelier on the ceiling."
    "Es una habitación de tamaño moderado con una mesa rectangular de madera rodeada de sillas, junto con una pequeña araña en el techo."

# game/script.rpy:2762
translate es investigation_1_522d0da9:

    # p "I think this is the dining room. Seems suited for eating meals here with a large family or guests, at least. And it's in much better condition than the living room."
    p "Creo que esto es el comedor. Parece adecuado para comer aquí con una familia grande o invitados, al menos. Y está en mucho mejor estado que la sala de estar."

# game/script.rpy:2764
translate es investigation_1_23a1f79c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0141.ogg"
    # t "What else is in there?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0141.ogg"
    t "¿Qué más hay allí?"

# game/script.rpy:2768
translate es investigation_1_13c89327:

    # p "Fireplace, table, chairs, lamps, and a fancy-looking cabinet. More books in there, looks like."
    p "Chimenea, mesa, sillas, lámparas y un gabinete elegante. Más libros allí, parece."

# game/script.rpy:2770
translate es investigation_1_1abdf17d:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0142.ogg"
    # t "Take a look around and tell me if there's anything interesting before you indulge in literature again."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0142.ogg"
    t "Echa un vistazo alrededor y dime si hay algo interesante antes de volver a sumergirte en la literatura."

# game/script.rpy:2774
translate es investigation_1_5b72cbe4:

    # p "Roger that."
    p "Entendido."

# game/script.rpy:2790
translate es investigation_2_38175948:

    # "I head over to the fireplace and start knocking on the walls."
    "Me dirijo a la chimenea y empiezo a golpear las paredes."

# game/script.rpy:2792
translate es investigation_2_2b204827:

    # p "I hope there's a secret passage here..."
    p "Espero que haya un pasadizo secreto aquí..."

# game/script.rpy:2796
translate es investigation_2_00715595:

    # "No matter where I knock, I don't find any sections that feel or sound different. "
    "No importa dónde golpee, no encuentro secciones que se sientan o suenen diferentes."

# game/script.rpy:2798
translate es investigation_2_19bbdbcf:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0143.ogg"
    # t "No dice?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0143.ogg"
    t "¿Nada?"

# game/script.rpy:2802
translate es investigation_2_446814a9:

    # p "No dice."
    p "Nada."

# game/script.rpy:2804
translate es investigation_2_2494286c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0144.ogg"
    # t "Keep at it, bud. Your dream will come true one day."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0144.ogg"
    t "Sigue intentándolo, compi. Tu sueño se hará realidad algún día."

# game/script.rpy:2814
translate es investigation_2_cf732b46:

    # p "This is such a nice table,\nit's got a lacquered wood finish and everything."
    p "Esta mesa es tan bonita,\ntiene un acabado de madera lacada y todo."

# game/script.rpy:2816
translate es investigation_2_44c26af9:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0145.ogg"
    # t "Can you stick to the mission, please?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0145.ogg"
    t "¿Puedes concentrarte en la misión, por favor?"

# game/script.rpy:2820
translate es investigation_2_47d01ac6:

    # p "Hey, I'm doing a lot of walking here... Let me sit down for a moment."
    p "Hey, estoy caminando mucho aquí... Déjame sentarme un momento."

# game/script.rpy:2824
translate es investigation_2_03bf3645:

    # "Taylor huffs in my ear while I plop down on one of the chairs, which happen to be surprisingly cushy."
    "Taylor resopla en mi oído mientras me dejo caer en una de las sillas, que resulta ser sorprendentemente cómoda."

# game/script.rpy:2826
translate es investigation_2_a6a0af0a:

    # p "You know, you never really answered my question from before."
    p "Sabes, nunca respondiste mi pregunta anterior."

# game/script.rpy:2828
translate es investigation_2_c2087b2e:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0146.ogg"
    # t "Which one?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0146.ogg"
    t "¿Cuál?"

# game/script.rpy:2834
translate es investigation_2_3b7ceee2:

    # p "About the hypothetical ghost clown servant."
    p "Sobre el hipotético sirviente payaso fantasma."

# game/script.rpy:2836
translate es investigation_2_629d1ae3:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0147.ogg"
    # t "No no no, we are not talking about clowns—"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0147.ogg"
    t "No no no, no estamos hablando de payasos—"

# game/script.rpy:2840
translate es investigation_2_e8d59bfd:

    # p "What if a ghost clown man made you blueberry pancakes in a bid to gain your friendship and trust?"
    p "¿Qué pasaría si un payaso fantasma te hiciera pancakes de arándanos en un intento de ganarse tu amistad y confianza?"

# game/script.rpy:2842
translate es investigation_2_193c2676:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0148.ogg"
    # t "I don't even like blueberries, and waffles are superior in every way. They can hold syrup, melted butter, or whatever you top them with so you lose less to your plate."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0148.ogg"
    t "Ni siquiera me gustan los arándanos, y los waffles son superiores en todos los sentidos. Pueden sostener jarabe, mantequilla derretida o lo que sea que pongas encima, así pierdes menos en tu plato."

# game/script.rpy:2846
translate es investigation_2_491396ba:

    # p "But Taylor, I keep telling you that you need to lay your face down in a fresh stack of fluffy pancakes at least once in your life. It's like being hugged by a litter of puppies."
    p "Pero Taylor, sigo diciéndote que necesitas poner tu cara sobre una pila de pancakes esponjosos al menos una vez en tu vida. Es como ser abrazado por una camada de cachorros."

# game/script.rpy:2848
translate es investigation_2_ced5fe7b:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0149.ogg"
    # t "I am {i}not{/i} putting food on my face, or my face into food—"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0149.ogg"
    t "Yo {i}no{/i} voy a poner comida en mi cara, ni mi cara en la comida—"

# game/script.rpy:2854
translate es investigation_2_894c04eb:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0150.ogg"
    # t "No no, end of conversation. Get back to the mission!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0150.ogg"
    t "No no, fin de la conversación. ¡Vuelve a la misión!"

# game/script.rpy:2858
translate es investigation_2_f0c1f24a:

    # "I click my tongue in annoyance and he clicks back."
    "Chasqueo la lengua con molestia y él lo hace también."

# game/script.rpy:2868
translate es investigation_2_23686c3c:

    # "I could use more light in here, but these lamps are probably dead, aren't they?"
    "Podría usar más luz aquí, pero estas lámparas probablemente estén muertas, ¿no?"

# game/script.rpy:2870
translate es investigation_2_491369a0:

    # "... Yeah, they're just as dead as Elias."
    "... Sí, están tan muertas como Elias."

# game/script.rpy:2872
translate es investigation_2_990896ec:

    # p "I wonder if collectors would go wild over some antique light bulbs."
    p "Me pregunto si los coleccionistas enloquecerían por algunas bombillas antiguas."

# game/script.rpy:2874
translate es investigation_2_2c79deb7:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0151.ogg"
    # t "Of all the things in this mansion,\nyou're thinking of stealing the light bulbs?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0151.ogg"
    t "De todas las cosas en esta mansión,\nestás pensando en robar las bombillas?"

# game/script.rpy:2878
translate es investigation_2_2de72eab:

    # p "What, you want me to walk out of here with the table?"
    p "¿Qué, quieres que salga de aquí con la mesa?"

# game/script.rpy:2880
translate es investigation_2_1d56147b:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0152.ogg"
    # t "... Eh, fair enough."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0152.ogg"
    t "... Eh, está bien."

# game/script.rpy:2884
translate es investigation_2_45030e7f:

    # "I hold one of the lamps in my hand and try to twist the bulb off, but it doesn't budge."
    "Sostengo una de las lámparas en la mano e intento girar la bombilla, pero no se mueve."

# game/script.rpy:2886
translate es investigation_2_54418d1f:

    # p "Scratch that, I'm not gonna bother."
    p "Olvídalo, no me molestaré."

# game/script.rpy:2888
translate es investigation_2_56c2793c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0153.ogg"
    # t "Hey, wanna know another fun fact? Thomas Edison didn't actually invent the light bulb. He bought the patent from two dudes named Henry Woodward and Matthew Evan."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0153.ogg"
    t "Hey, ¿quieres otro dato curioso? Thomas Edison en realidad no inventó la bombilla. Compró la patente de dos tipos llamados Henry Woodward y Matthew Evan."

# game/script.rpy:2892
translate es investigation_2_d2dc10a5:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0154.ogg"
    # t "Edison was able to claim fame thanks to the fact that he had enough capital to finance improvements to the design."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0154.ogg"
    t "Edison pudo reclamar fama gracias a que tenía suficiente capital para financiar mejoras en el diseño."

# game/script.rpy:2896
translate es investigation_2_b2551330:

    # p "So the moral of the story is that the rich get richer and the poor stay starving?"
    p "¿Entonces la moraleja es que los ricos se vuelven más ricos y los pobres siguen hambrientos?"

# game/script.rpy:2898
translate es investigation_2_fdf5aaa3:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0155.ogg"
    # t "My point was that popular history gets written by the winners, but that works too."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0155.ogg"
    t "Mi punto era que la historia popular la escriben los ganadores, pero eso también funciona."

# game/script.rpy:2914
translate es investigation_2_83fc3ed1:

    # p "Nothing else to look at but the cabinet now."
    p "Nada más que revisar excepto el gabinete ahora."

# game/script.rpy:2916
translate es investigation_2_a5844b90:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0156.ogg"
    # t "Let me know what you find."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0156.ogg"
    t "Avísame si encuentras algo."

# game/script.rpy:2922
translate es investigation_2_a1e42b27:

    # "I kneel down by the floor and inspect the books on the bottom. These seem to be cookbooks for various European cuisines: Irish, Polish, Dutch, and so forth..."
    "Me arrodillo en el suelo e inspecciono los libros de abajo. Parecen ser libros de cocina de varias cocinas europeas: irlandesa, polaca, holandesa, y demás..."

# game/script.rpy:2926
translate es investigation_2_10fa018c:

    # p "No dessert cookbooks here, but maybe they're behind the glass."
    p "No hay libros de postres aquí, pero quizá estén detrás del vidrio."

# game/script.rpy:2928
translate es investigation_2_2deb6da2:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0157.ogg"
    # t "Right, Elias wanted to bake a cake for you... Would he even be able to eat it?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0157.ogg"
    t "Cierto, Elias quería hornear un pastel para ti... ¿Incluso podría comerlo?"

# game/script.rpy:2932
translate es investigation_2_7573d4b9:

    # p "He did have a tea set in the study, so maybe it's like food offerings for the departed."
    p "Tenía un juego de té en el estudio, así que tal vez sea como ofrendas de comida para los fallecidos."

# game/script.rpy:2936
translate es investigation_2_a8b26072:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0158.ogg"
    # t "Uh, can you say that again, [your_name]?\nI think the line's cutting out again—"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0158.ogg"
    t "Uh, ¿puedes repetir eso, [your_name]?\nCreo que la línea se está cortando otra vez—"

# game/script.rpy:2940
translate es investigation_2_7f1d6752:

    # p "I said—"
    p "Dije—"

# game/script.rpy:2944
translate es investigation_2_aedfbf5c:

    # "There's static in the earpiece and I'm suddenly overcome with dizziness. I groan while trying to get back upright, grabbing the back of a chair for balance."
    "Hay estática en el auricular y de repente me da mareo. Gimo mientras trato de enderezarme, agarrando el respaldo de una silla para mantener el equilibrio."

# game/script.rpy:2948
translate es investigation_2_9f9c7f3c:

    # "Suddenly my vision darkens and the room spins. My feet can't touch the ground. I'm falling, falling, down into a yawning abyss."
    "De repente mi visión se oscurece y la habitación gira. Mis pies no tocan el suelo. Estoy cayendo, cayendo, hacia un abismo que se abre."

# game/script.rpy:2953
translate es investigation_2_737afa47:

    # "I open my eyes."
    "Abro los ojos."

# game/script.rpy:2955
translate es investigation_2_73937337:

    # "Behind me, the chandelier starts swinging and the fireplace roars to life, and yet I'm freezing, like there's ice slushing through my veins again. It's horrible, and I'm scared."
    "Detrás de mí, la araña comienza a oscilar y la chimenea ruge, y aun así me congelo, como si hubiera hielo corriendo por mis venas otra vez. Es horrible, y tengo miedo."

# game/script.rpy:2957
translate es investigation_2_7be42747:

    # "This is definitely the same dining room, but everything feels wrong. I grip the chair harder and lift my head."
    "Definitivamente es el mismo comedor, pero todo se siente mal. Aprieto la silla con fuerza y levanto la cabeza."

# game/script.rpy:2959
translate es investigation_2_1c21100b:

    # "That was a mistake."
    "Eso fue un error."

# game/script.rpy:2965
translate es investigation_2_0b00c70b:

    # "Encased in the glass of the cabinet is the figure of a woman."
    "Encerrada en el vidrio del gabinete está la figura de una mujer."

# game/script.rpy:2978
translate es investigation_2_6eba74a6:

    # "She's so far away, but she's coming closer, and closer, and closer, with a knife in her hand and a cheshire cat grin painted across her lips."
    "Está tan lejos, pero se acerca más y más, con un cuchillo en la mano y una sonrisa tipo gato de Cheshire pintada en los labios."

# game/script.rpy:2982
translate es investigation_2_624c4ecf:

    # "Dripping with bloodlust, her needle-like gaze makes a pinboard of me. I can't breathe. I have to get out of here. How can I escape?"
    "Goteando de sed de sangre, su mirada de aguja me perfora como un tablero de corcho. No puedo respirar. Tengo que salir de aquí. ¿Cómo puedo escapar?"

# game/script.rpy:2986
translate es investigation_2_109303ad:

    # "In an act of defiance I spin in the opposite direction and try to make a break for it... but my feet are cemented in place."
    "En un acto de desafío giro en dirección opuesta e intento huir... pero mis pies están cementados en el lugar."

# game/script.rpy:2990
translate es investigation_2_fdc05a19:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0159.ogg"
    # t "[your_name]! Can you hear me? Answer if you can hear me!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0159.ogg"
    t "¡[your_name]! ¿Puedes oírme? ¡Responde si me escuchas!"

# game/script.rpy:2998
translate es investigation_2_e96d3a14:

    # p "Get away from me!"
    p "¡Aléjate de mí!"

# game/script.rpy:3000
translate es investigation_2_33d6aa99:

    # "My knees give out and I collapse back into the chair."
    "Mis rodillas ceden y caigo de nuevo en la silla."

# game/script.rpy:3006
translate es investigation_2_a9f270ee:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0160.ogg"
    # t "[your_name], are you okay? Were you attacked!?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0160.ogg"
    t "[your_name], ¿estás bien? ¿Te atacaron!?"

# game/script.rpy:3010
translate es investigation_2_6c2f78fd:

    # p "Not physically..."
    p "No físicamente..."

# game/script.rpy:3012
translate es investigation_2_bd9a5227:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0161.ogg"
    # t "Static took over the line again and I heard something garbled from your end, some kind of whispering o-or... chanting? Was that you?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0161.ogg"
    t "La estática volvió a tomar la línea y escuché algo distorsionado de tu lado, algún tipo de susurro o o... ¿cánticos? ¿Fuiste tú?"

# game/script.rpy:3016
translate es investigation_2_887c8ff6:

    # p "No... that... that wasn't me..."
    p "No... eso... eso no fui yo..."

# game/script.rpy:3018
translate es investigation_2_94f928b6:

    # "I swallow deep gasps of air trying to regain my breath as Taylor's voice rings in my ear."
    "Trago profundamente intentando recuperar el aliento mientras la voz de Taylor resuena en mi oído."

# game/script.rpy:3020
translate es investigation_2_0a069166:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0162.ogg"
    # t "[your_name], what did you see?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0162.ogg"
    t "[your_name], ¿qué viste?"

# game/script.rpy:3026
translate es investigation_2_6246397d:

    # p "I-I think it was Violet again."
    p "C-creo que fue Violet otra vez."

# game/script.rpy:3030
translate es investigation_2_bb4a88a2:

    # p "Dupont. Violet Dupont."
    p "Dupont. Violet Dupont."

# game/script.rpy:3032
translate es investigation_2_8f8c8179:

    # "I spit out the name without thinking. I know whoever I saw was a woman, but was it really Violet?"
    "Escupo el nombre sin pensar. Sé que quien vi era una mujer, pero ¿era realmente Violet?"

# game/script.rpy:3034
translate es investigation_2_3e13dc87:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0163.ogg"
    # t "... I'm starting to think that there are some other spirits in this mansion besides Elias. Why else would there be interference when he's not even in the room—"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0163.ogg"
    t "... Empiezo a pensar que hay otros espíritus en esta mansión además de Elias. ¿Por qué habría interferencia si él ni siquiera está en la habitación—"

# game/script.rpy:3042
translate es investigation_2_7a9f0703:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0117.ogg"
    # e "Goodness [your_name], are you quite alright?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0117.ogg"
    e "Dios mío [your_name], ¿estás bien?"

# game/script.rpy:3046
translate es investigation_2_c0a1503a:

    # "I look up at the sound of Elias' voice."
    "Miro hacia arriba al escuchar la voz de Elias."

# game/script.rpy:3052
translate es investigation_2_bdc3fc60:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0118.ogg"
    # e "Why do you look so pale?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0118.ogg"
    e "¿Por qué tienes tu piel pálida?"

# game/script.rpy:3058
translate es investigation_2_471573dc:

    # p "O-oh, my sweet Elias, I simply..."
    p "O-oh, mi dulce Elias, simplemente..."

# game/script.rpy:3060
translate es investigation_2_50b780cf:

    # "Am I going to tell him that I had a vision of someone — probably the woman he was supposed to marry — charging at me with a knife?"
    "¿Le voy a contar que tuve una visión de alguien — probablemente la mujer con la que se suponía que se iba a casar — lanzándose hacia mí con un cuchillo?"

# game/script.rpy:3062
translate es investigation_2_fb8948cf:

    # p "It simply feels as though a thousand years have passed since I last saw you, my love, and I began to feel a bit lonely."
    p "Simplemente siento como si hubieran pasado mil años desde la última vez que te vi, mi amor, y empecé a sentirme un poco de soledad."

# game/script.rpy:3064
translate es investigation_2_ecfba38a:

    # "Taylor groans on the other side while I fake a pacifying grin."
    "Taylor gime al otro lado mientras finjo una sonrisa pacificadora."

# game/script.rpy:3066
translate es investigation_2_1210e457:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0164.ogg"
    # t "It's been like what, 20 minutes tops?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0164.ogg"
    t "Han sido, ¿qué? ¿20 minutos como máximo?"

# game/script.rpy:3070
translate es investigation_2_71ca4173:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0119.ogg"
    # e closed_sad sad ah_sad "Forgive me for leaving you to your own devices for so long, dearest. I am here now, so there is no need to linger in the despair of solitude."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0119.ogg"
    e closed_sad sad ah_sad "Perdóname por dejarte a tu suerte tanto tiempo, cariño. Ahora estoy aquí, así que no hay necesidad de permanecer en la desesperación de la soledad."

# game/script.rpy:3076
translate es investigation_2_5526114b:

    # p "My gratitude, Elias, but surely my pain is nothing compared to your own."
    p "Mi gratitud, Elias, pero seguramente mi dolor no se compara con el tuyo."

# game/script.rpy:3078
translate es investigation_2_468cb8c0:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0120.ogg"
    # e forward_lidded_small @ oh_annoyed "Worry not, [your_name], for my years in the flesh prepared me for such an existence. I am not forgotten."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0120.ogg"
    e forward_lidded_small @ oh_annoyed "No te preocupes, [your_name], pues mis años en carne me prepararon para tal existencia. No estoy olvidado."

# game/script.rpy:3082
translate es investigation_2_c47f4785:

    # "It could be my imagination, but I see a flicker of pain in his eyes for a moment, as if he's trying to convince himself of that last bit."
    "Podría ser mi imaginación, pero veo un destello de dolor en sus ojos por un momento, como si intentara convencerse de esa última parte."

# game/script.rpy:3084
translate es investigation_2_0ef4dcd8:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0121.ogg"
    # e right_lidded grinding sweat "Why, even before you came to me, there would be the occasional visitor to my manor. None quite so welcome, mind you... Most were in a stupefied, intoxicated state."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0121.ogg"
    e right_lidded grinding sweat "Antes de que vinieras a mí, había de vez en cuando algún visitante en mi mansión. Ninguno demasiado bienvenido, debo decir... La mayoría estaba en un estado atontado o eufórico."

# game/script.rpy:3088
translate es investigation_2_4c7096ce:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0122.ogg"
    # e left_small pout "Good entertainment, but not the company I'd choose to spend the rest of my waking moments with. Unlike you, my love."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0122.ogg"
    e left_small pout "Buen entretenimiento, pero no la compañía con la que elegiría pasar el resto de mis momentos despierto. A diferencia de ti, mi amor."

# game/script.rpy:3096
translate es investigation_2_919159f3:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0165.ogg"
    # t "Man, this guy is just... Ugh."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0165.ogg"
    t "Vaya, este tipo es simplemente... Ugh."

# game/script.rpy:3100
translate es investigation_2_138d7760:

    # "I'm trying my hardest not to roll my eyes at Taylor's unnecessary commentary."
    "Estoy haciendo mi mayor esfuerzo por no poner los ojos en blanco ante los comentarios innecesarios de Taylor."

# game/script.rpy:3102
translate es investigation_2_db6386b5:

    # p "Let us not linger on such irrelevant matters, then. Shall we resume our preparations for the ceremony?"
    p "No nos detengamos en asuntos tan irrelevantes, entonces. ¿Reanudamos nuestros preparativos para la ceremonia?"

# game/script.rpy:3104
translate es investigation_2_55b95c3f:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0123.ogg"
    # e closed_happy grin_teeth happy "Why yes, a splendid idea!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0123.ogg"
    e closed_happy grin_teeth happy "¡Claro que sí, una idea espléndida!"

# game/script.rpy:3110
translate es investigation_2_436edd72:

    # "Elias moves towards the glass cabinet with a bounce in his... float? Swinging the doors open, he starts humming."
    "Elias se dirige hacia el gabinete de vidrio con un rebote en su... ¿flotación? Abriendo las puertas, empieza a tararear."

# game/script.rpy:3114
translate es investigation_2_31e61c26:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0124.ogg"
    # e forward_regular goofgrin_regular "Our wedding shall be oh so fine, the layer cake most of all, unforgettable! Nana's baking's divine, and when paired with white wine, to not taste it would be quite regrettable!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0124.ogg"
    e forward_regular goofgrin_regular "Nuestra boda será tan maravillosa, especialmente la torta de capas, ¡inolvidable! La repostería de Nana es divina, y al combinarla con vino blanco, ¡no probarla sería lamentable!"

# game/script.rpy:3118
translate es investigation_2_cae79fd0:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0125.ogg"
    # e goofgrin_drool left_lidded sad "Oh, though I do miss her cream pies as well. Shame those aren't quite appropriate for a wedding."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0125.ogg"
    e goofgrin_drool left_lidded sad "Oh, aunque también extraño sus pasteles de crema. Lástima que no sean muy apropiados para una boda."

# game/script.rpy:3124
translate es investigation_2_be31ba56:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0166.ogg"
    # t "Pfft, oh my god, did he just say cream pie?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0166.ogg"
    t "Pfft, oh dios, ¿acaba de decir pastel de crema? (Nota: Cream pie es un termino que tambien se usa en lo xxx xD)"

# game/script.rpy:3128
translate es investigation_2_5e05e4b7:

    # p "{i}Get your head out of the gutter or I'll make you cry.{/i}"
    p "{i}Saca tu mente de lo sucio o te haré llorar.{/i}"

# game/script.rpy:3130
translate es investigation_2_0006da75:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0126.ogg"
    # e forward_regular happy goofgrin_up "She wrote the recipe in a manner such that you could make it in any sort of flavor, so long as you had the proper ingredients. Say, what flavor shall our cake be, [your_name]?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0126.ogg"
    e forward_regular happy goofgrin_up "Ella escribió la receta de manera que pudieras hacerla en cualquier sabor, siempre que tuvieras los ingredientes correctos. Dime, ¿qué sabor tendrá nuestro pastel, [your_name]?"

# game/script.rpy:3136
translate es investigation_2_65d00186:

    # p "Oh, there's so many options to choose from, aren't there? I simply can't decide! What do you suggest, dearest?"
    p "Oh, hay tantas opciones, ¿verdad? ¡Simplemente no puedo decidir! ¿Qué sugieres, cariño?"

# game/script.rpy:3138
translate es investigation_2_6f26255e:

    # "Elias thumbs the spines of the cookbooks with a little more focus."
    "Elias pasa sus dedos por los lomos de los libros de cocina con un poco más de concentración."

# game/script.rpy:3140
translate es investigation_2_7f858587:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0127.ogg"
    # e up_regular oh_annoyed "I was quite partial to Earl Grey myself, but vanilla is always agreeable no matter the party. Though, perhaps a delicate lemon with hints of lavender..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0127.ogg"
    e up_regular oh_annoyed "Yo tenía cierta preferencia por Earl Grey, pero la vainilla siempre es agradable sin importar la ocasión. Aunque, tal vez un delicado limón con toques de lavanda..."

# game/script.rpy:3150
translate es investigation_2_3ff1d0dd:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0128.ogg"
    # e "Hm..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0128.ogg"
    e "Hm..."

# game/script.rpy:3154
translate es investigation_2_d3d1e3d4:

    # p "Is something the matter, Elias?"
    p "¿Sucede algo, Elias?"

# game/script.rpy:3156
translate es investigation_2_e6df8f3e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0129.ogg"
    # e closed_sad frown_disapprove sad "I... must have misplaced grandmother's dessert recipes. I can't find them."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0129.ogg"
    e closed_sad frown_disapprove sad "... Debo haber perdido las recetas de postres de la abuela. No puedo encontrarlas."

# game/script.rpy:3162
translate es investigation_2_6bcf02bb:

    # "Elias lowers his hands from the cabinet and sighs, crestfallen."
    "Elias baja las manos del gabinete y suspira, abatido."

# game/script.rpy:3166
translate es investigation_2_3fdc2d9d:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0130.ogg"
    # e left_lidded disapprove @ tch "Where did I leave them? I know I have seen it within the past decade, at least..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0130.ogg"
    e left_lidded disapprove @ tch "¿Dónde las dejé? Sé que las he visto en la última década, al menos..."

# game/script.rpy:3170
translate es investigation_2_36681e94:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0167.ogg"
    # t "Hey, here's our chance to look for more clues somewhere else."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0167.ogg"
    t "Oye, esta es nuestra oportunidad de buscar más pistas en otro lugar."

# game/script.rpy:3174
translate es investigation_2_fb457ea2:

    # "Taylor makes a good point."
    "Taylor tiene un buen punto."

# game/script.rpy:3176
translate es investigation_2_55378ba4:

    # p "Perhaps I can assist in your search? With two sets of eyes I'm sure we'll find your grandmother's recipes in no time."
    p "¿Quizás pueda ayudarte en la búsqueda? Con dos pares de ojos seguro encontraremos las recetas de tu abuela en poco tiempo."

# game/script.rpy:3178
translate es investigation_2_7ec55b2c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0131.ogg"
    # e closed_sad oh_sad sad "I am loathe to ask my [marriage_title] to make up for my mistakes, but yes, I would appreciate your help."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0131.ogg"
    e closed_sad oh_sad sad "Me disgusta pedirle a mi [marriage_title] que compense mis errores, pero sí, agradecería tu ayuda."

# game/script.rpy:3184
translate es investigation_2_853457bc:

    # p "Do you have any inkling of an idea where you may have left them?"
    p "¿Tienes alguna idea de dónde podrías haberlas dejado?"

# game/script.rpy:3186
translate es investigation_2_0bbb565b:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0132.ogg"
    # e forward_lidded_smaller ah_sad concerned "Unfortunately not. I do know that it must be in the manor however... None of my possessions have left the grounds."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0132.ogg"
    e forward_lidded_smaller ah_sad concerned "Desafortunadamente no. Pero sé que deben estar en la mansión... Ninguna de mis pertenencias ha salido del terreno."

# game/script.rpy:3190
translate es investigation_2_d2f7e702:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0133.ogg"
    # e sad left_small ugh "I will investigate the common room. Take care where you may search, and be cautious of the second floor. I have done my best to stabilize the structure but ah, it does take quite some energy."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0133.ogg"
    e sad left_small ugh "Investigaré la sala común. Ten cuidado donde busques y precaución con el segundo piso. Hice lo posible por estabilizar la estructura, pero ah, requiere bastante energía."

# game/script.rpy:3196
translate es investigation_2_0bac98c0:

    # p "Understood, my love. May we find your grandmother's recipes soon."
    p "Entendido, mi amor. Ojalá encontremos pronto las recetas de tu abuela."

# game/script.rpy:3200
translate es investigation_2_c3772651:

    # "Elias bows before he takes his leave through the door, and I release a breath I didn't realize I was holding."
    "Elias se inclina antes de retirarse por la puerta, y respiro aliviado sin darme cuenta que lo estaba conteniendo."

# game/script.rpy:3204
translate es investigation_2_d47db5df:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0168.ogg"
    # t "... Is he finally gone?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0168.ogg"
    t "... ¿Se habrá ido finalmente?"

# game/script.rpy:3208
translate es investigation_2_a81f90fb:

    # p "Looks like I can try looking around on the second floor, now. But where should we start?"
    p "Parece que puedo intentar buscar en el segundo piso ahora. Pero, ¿por dónde empezar?"

# game/script.rpy:3212
translate es investigation_2_3f3020bf:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0169.ogg"
    # t "Well, you never got to hunt around the study since Elias was hangin' out in there, but I wonder if you can find his bedroom..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0169.ogg"
    t "Bueno, nunca llegaste a buscar en el estudio porque Elias estaba ahí, pero me pregunto si podrás encontrar su habitación..."

# game/script.rpy:3216
translate es investigation_2_bd8a943a:

    # "Taylor pauses, and when he speaks again I can hear his voice waver."
    "Taylor hace una pausa, y cuando habla de nuevo puedo escuchar su voz vacilar."

# game/script.rpy:3218
translate es investigation_2_ecc64410:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0170.ogg"
    # t "We also have no idea what caused that vision you saw earlier."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0170.ogg"
    t "Tampoco tenemos idea de qué causó esa visión que tuviste antes."

# game/script.rpy:3222
translate es investigation_2_2bd80113:

    # "Hmm, should I return to the study, search for Elias' bedroom, or stay here in the dining room where I saw that vision? I can only be in one place at a time..."
    "Hmm, ¿debería volver al estudio, buscar la habitación de Elias o quedarme aquí en el comedor donde vi esa visión? Solo puedo estar en un lugar a la vez..."

# game/script.rpy:3232
translate es investigation_2_2a275a18:

    # "That vision with Violet — or whoever I saw just now —\nis really bothering me."
    "Esa visión con Violet — o quien haya sido que vi hace un momento —\nrealmente me está molestando."

# game/script.rpy:3234
translate es investigation_2_eeb5f1d9:

    # p "I'm staying here to inspect the glass cabinet a little more."
    p "Me quedo aquí para inspeccionar un poco más el gabinete de vidrio."

# game/script.rpy:3236
translate es investigation_2_50b04333:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0171.ogg"
    # t "Be careful, alright?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0171.ogg"
    t "Ten cuidado, ¿vale?"

# game/script.rpy:3240
translate es investigation_2_1478ba88:

    # "I pull myself out of the chair and step towards the cabinet and its book once more. This time nothing seems to appear."
    "Me levanto de la silla y me acerco al gabinete y su libro una vez más. Esta vez nada parece aparecer."

# game/script.rpy:3244
translate es investigation_2_cda4db67:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0172.ogg"
    # t "Though, how are you going to explain to Elias that you're basically staying put?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0172.ogg"
    t "Aunque, ¿cómo vas a explicarle a Elias que básicamente te quedaste en el mismo lugar?"

# game/script.rpy:3248
translate es investigation_2_550dca83:

    # p "... We'll cross that bridge when we get to it."
    p "... Cruzaremos ese puente cuando lleguemos a él."

# game/script.rpy:3250
translate es investigation_2_0aab25c5:

    # "I swing the cabinet door open and shut, investigating it from multiple angles."
    "Abro y cierro la puerta del gabinete, investigándolo desde varios ángulos."

# game/script.rpy:3252
translate es investigation_2_aad7551c:

    # "Then I take out a book to inspect it. The words are nothing but jumbled old English to me."
    "Luego saco un libro para inspeccionarlo. Las palabras no son más que inglés antiguo y desordenado para mí."

# game/script.rpy:3254
translate es investigation_2_c944ad20:

    # p "Man, some of this stuff is illegible."
    p "Vaya, algunas de estas cosas son ilegibles."

# game/script.rpy:3256
translate es investigation_2_4f4591f1:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0173.ogg"
    # t "Too hard to read?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0173.ogg"
    t "¿Demasiado difícil de leer?"

# game/script.rpy:3260
translate es investigation_2_68e8c683:

    # p "More like too hard to understand. Did people really talk like this?"
    p "Más bien demasiado difícil de entender. ¿La gente realmente hablaba así?"

# game/script.rpy:3264
translate es investigation_2_08945306:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0174.ogg"
    # t "I don't know, you seem to do a pretty good job of it."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0174.ogg"
    t "No sé, parece que tú lo haces bastante bien."

# game/script.rpy:3268
translate es investigation_2_3b365cd1:

    # p "Tch."
    p "Tch."

# game/script.rpy:3270
translate es investigation_2_5ac29a2b:

    # "I slot the book back in place and I cough as dust gets into my nose."
    "Vuelvo a colocar el libro en su lugar y toso cuando el polvo me entra en la nariz."

# game/script.rpy:3272
translate es investigation_2_b47f97b8:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0175.ogg"
    # t "You ok there, bud?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0175.ogg"
    t "¿Estás bien, compi?"

# game/script.rpy:3276
translate es investigation_2_7f97b339:

    # p "Even though this place looks clean,\nthe dust in this cabinet is still {i}very{/i} real."
    p "Aunque este lugar parezca limpio,\nel polvo en este gabinete sigue siendo {i}muy{/i} real."

# game/script.rpy:3278
translate es investigation_2_4efa6363:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0176.ogg"
    # t "Maybe that was Elias' plan all along. Death by choking on dust."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0176.ogg"
    t "Quizás ese era el plan de Elias desde el principio. Muerte por atragantamiento con polvo."

# game/script.rpy:3282
translate es investigation_2_46b7b77a:

    # "I roll my eyes."
    "Pongo los ojos en blanco."

# game/script.rpy:3284
translate es investigation_2_4d5498f1:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0177.ogg"
    # t "See anything new?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0177.ogg"
    t "¿Ves algo nuevo?"

# game/script.rpy:3288
translate es investigation_2_aab19efe:

    # p "Not really. I wonder where the kitchen is in this place..."
    p "No realmente. Me pregunto dónde estará la cocina en este lugar..."

# game/script.rpy:3290
translate es investigation_2_d561d035:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0178.ogg"
    # t "Oh no no no, you probably don't wanna go into the kitchen even if you're able to find it. Eugh, imagine the mildew and rot, ugh!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0178.ogg"
    t "Oh no no no, probablemente no quieras ir a la cocina aunque logres encontrarla. ¡Eugh, imagina el moho y la putrefacción, ugh!"

# game/script.rpy:3294
translate es investigation_2_86d18051:

    # p "You think so? You know, since you love comparing yourself to Egon so much, I bet you'd love something like that. Somewhere {i}covered{/i} in mold."
    p "¿De veras? Sabes, como tanto te gusta compararte con Egon, apuesto que te encantaría algo así. Un lugar {i}cubierto{/i} de moho."

# game/script.rpy:3296
translate es investigation_2_e69a4308:

    # "Taylor laughs heartily, the sound light in my ear. "
    "Taylor se ríe con fuerza, el sonido ligero en mi oído."

# game/script.rpy:3298
translate es investigation_2_5ba43d82:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0179.ogg"
    # t "Well if we're comparing each other to Ghostbusters characters, I {i}am{/i} the brains of the operation... Egon just makes sense."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0179.ogg"
    t "Bueno, si vamos a compararnos con personajes de Cazafantasmas, yo {i}soy{/i} el cerebro de la operación... Egon simplemente tiene sentido."

# game/script.rpy:3302
translate es investigation_2_836ad049:

    # p "I was thinking you're more of a Janine. Your red hair and cute face is much better suited for that role."
    p "Yo pensaba que eres más bien una Janine. Tu cabello rojo y tu carita linda se adapta mejor a ese papel."

# game/script.rpy:3304
translate es investigation_2_61142fca:

    # "Taylor makes an odd, barely noticeable noise, then clears his throat."
    "Taylor hace un ruido extraño, apenas perceptible, y luego carraspea."

# game/script.rpy:3306
translate es investigation_2_8ebb6f01:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0180.ogg"
    # t "I knew it. You do think I'm cute. "
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0180.ogg"
    t "Lo sabía. De verdad piensas que soy lindo."

# game/script.rpy:3310
translate es investigation_2_119e4e89:

    # p "Anyway, I think I deserve some credit. You may be the planner, but {i}I'm{/i} the one about to marry a ghost."
    p "De todos modos, creo que merezco algo de crédito. Tú puedes ser la planificadora, pero {i}soy{/i} quien está a punto de casarse con un fantasma."

# game/script.rpy:3312
translate es investigation_2_1f4cf689:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0181.ogg"
    # t "Hey!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0181.ogg"
    t "¡Oye!"

# game/script.rpy:3316
translate es investigation_2_590d8dee:

    # "I smile at the pout in his voice."
    "Sonrío ante el puchero en su voz."

# game/script.rpy:3318
translate es investigation_2_70a83bd3:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0182.ogg"
    # t "I would've joined you, but backup is important. I'm prioritizing the evidence {i}and{/i} trying to avoid Elias' suspicions."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0182.ogg"
    t "Me habría unido a ti, pero la ayuda es importante. Estoy priorizando la evidencia {i}y{/i} tratando de evitar las sospechas de Elias."

# game/script.rpy:3322
translate es investigation_2_42342f35:

    # "I shuffle back and lower myself into one of the chairs at the dinner table."
    "Retrocedo y me siento en una de las sillas de la mesa del comedor."

# game/script.rpy:3324
translate es investigation_2_9f351dcb:

    # p "Is that {i}really{/i} the reason? Or are you worried you won't be able to hide your insatiable desire to be ravished by a ghost?"
    p "¿Esa es {i}realmente{/i} la razón? ¿O te preocupa no poder ocultar tu deseo insaciable de ser devorado por un fantasma?"

# game/script.rpy:3326
translate es investigation_2_41dc6eb9:

    # "I pause for a second, smirking."
    "Hago una pausa por un segundo, sonriendo con malicia."

# game/script.rpy:3328
translate es investigation_2_471b60cb:

    # p "... You know, I found that notebook you left\nin the club room last week... The one filled with lewd fanfiction? Try as you might, you aren't that subtle."
    p "... Sabes, encontré ese cuaderno que dejaste\nen la sala del club la semana pasada... ¿El lleno de fanfiction subido de tono? Por más que lo intentes, no eres tan sutil."

# game/script.rpy:3332
translate es investigation_2_00eb0fe1:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0183.ogg"
    # t "Ahh!!!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0183.ogg"
    t "¡Ahh!!!"

# game/script.rpy:3336
translate es investigation_2_ace399a5:

    # "His squeal is enough to make me stifle a laugh. "
    "Su chillido es suficiente para que contenga la risa."

# game/script.rpy:3338
translate es investigation_2_523ad679:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0184.ogg"
    # t "I—"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0184.ogg"
    t "Yo—"

# game/script.rpy:3342
translate es investigation_2_fa88c53c:

    # "Taylor clears his throat, his voice lowering."
    "Taylor carraspea, bajando la voz."

# game/script.rpy:3344
translate es investigation_2_61884233:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0185.ogg"
    # t "I have no clue what you're talking about."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0185.ogg"
    t "No tengo idea de lo que estás hablando."

# game/script.rpy:3348
translate es investigation_2_e8cd98db:

    # "I take a deep breath before sighing dramatically."
    "Respiro hondo antes de suspirar dramáticamente."

# game/script.rpy:3350
translate es investigation_2_515f72d0:

    # p "\"{0}He{/0}{1}She{/1}{2}They{/2} had me pinned against the wall. {0}His{/0}{1}Her{/1}{2}Their{/2} lips left a trail of fire along my skin as {0}he{/0}{1}she{/1}{2}they{/2}-\""
    p "{0}Él{/0}{1}Ella{/1}{2}Elle{/2} me tuvo pegado contra la pared. {0}Sus{/0}{1}Sus{/1}{2}Sus{/2} labios dejaron un rastro de fuego sobre mi piel mientras {0}él{/0}{1}ella{/1}{2}elle{/2}-"

# game/script.rpy:3352
translate es investigation_2_186912fa:

    # "I cease, realizing he hasn't tried to stop me. He then speaks, his voice soft and low."
    "Me detengo, dándome cuenta de que él no ha intentado detenerme. Luego habla, su voz suave y baja."

# game/script.rpy:3354
translate es investigation_2_9526b96f:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0186.ogg"
    # t "... I'm not writing about ghosts."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0186.ogg"
    t "... No estoy escribiendo sobre fantasmas."

# game/script.rpy:3358
translate es investigation_2_09722dcb:

    # "I raise an eyebrow."
    "Levanto una ceja."

# game/script.rpy:3360
translate es investigation_2_7828f5a0:

    # p "Then what are you writing about?"
    p "Entonces, ¿sobre qué estás escribiendo?"

# game/script.rpy:3362
translate es investigation_2_c273b113:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0187.ogg"
    # t "It doesn't matter... and it's not fanfiction!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0187.ogg"
    t "No importa... ¡y no es fanfiction!"

# game/script.rpy:3366
translate es investigation_2_2ae0bdf7:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0188.ogg"
    # t "Just... get back to the mission."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0188.ogg"
    t "Solo... vuelve a la misión."

# game/script.rpy:3372
translate es investigation_2_20d4d0ac:

    # "Taylor sounds... unusually meek right now.\nMaybe I stepped on a nerve."
    "Taylor suena... inusualmente sumiso ahora.\nQuizá toqué un nervio."

# game/script.rpy:3374
translate es investigation_2_5bbd41a8:

    # p "Hey um, I'm sorry. Didn't mean to make you uncomfortable."
    p "Oye, um, lo siento. No quise incomodarte."

# game/script.rpy:3376
translate es investigation_2_9bf38b78:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0189.ogg"
    # t "It's okay, [your_name]. How are you doing over there with all those visions and everything?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0189.ogg"
    t "Está bien, [your_name]. ¿Cómo estás con todas esas visiones y todo eso?"

# game/script.rpy:3380
translate es investigation_2_5f4c01dd:

    # p "Honestly? It's a lot all at once. But hearing your voice through this all really keeps me calm."
    p "¿Honestamente? Es mucho todo a la vez. Pero escuchar tu voz en medio de esto realmente me calma."

# game/script.rpy:3382
translate es investigation_2_2b648187:

    # "I can almost pick up a smile in his voice as he replies, softly."
    "Casi puedo percibir una sonrisa en su voz mientras responde, suavemente."

# game/script.rpy:3384
translate es investigation_2_a74ada8e:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0190.ogg"
    # t "Good. I'm glad."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0190.ogg"
    t "Bien. Me alegra."

# game/script.rpy:3388
translate es investigation_2_c52261bd:

    # p "I better get going somewhere before I waste too much time."
    p "Será mejor que me vaya a algún lugar antes de perder demasiado tiempo."

# game/script.rpy:3392
translate es investigation_2_769d9190:

    # "I push the chair back and try to stand up, but the leg catches on my clothes."
    "Empujo la silla hacia atrás e intento ponerme de pie, pero la pata se engancha en mi ropa."

# game/script.rpy:3398
translate es investigation_2_c713f02a:

    # p "Ahhh!!!"
    p "¡Ahhh!!!"

# game/script.rpy:3400
translate es investigation_2_4199e68a:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0191.ogg"
    # t "[your_name], what's going on!?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0191.ogg"
    t "¡[your_name], ¿qué pasa!?"

# game/script.rpy:3408
translate es investigation_2_2b6d3bab:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0134.ogg"
    # e "[your_name], are you alright!?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0134.ogg"
    e "¡[your_name], ¿estás bien!?"

# game/script.rpy:3414
translate es investigation_2_63774c3d:

    # "Out of nowhere, Elias grabs my hand, his other arm wrapping around my waist as he steadies me."
    "De repente, Elias agarra mi mano, mientras su otro brazo se envuelve alrededor de mi cintura para sostenerme."

# game/script.rpy:3418
translate es investigation_2_ae6b5430:

    # p "Elias, I—"
    p "Elias, yo—"

# game/script.rpy:3422
translate es investigation_2_7022ec93:

    # "My vision blurs as the scene before me dissipates and molds into something else entirely."
    "Mi visión se nubla mientras la escena frente a mí desaparece y se transforma en algo completamente distinto."

# game/script.rpy:3435
translate es investigation_2_e0dddc06:

    # "I see Elias surrounded by his siblings and father, all of them shouting and jeering."
    "Veo a Elias rodeado por sus hermanos y su padre, todos gritando y burlándose."

# game/script.rpy:3442
translate es investigation_2_696f2cce:

    # "Horrible, terrible things in a mocking tone. Making fun of him, calling him weak. A mistake."
    "Cosas horribles, terribles, en un tono burlón. Se burlan de él, lo llaman débil. Un error."

# game/script.rpy:3446
translate es investigation_2_612878d9:

    # "Grief and guilt fill my heart before I snap back to reality.\nI'm leaning against the wall, Elias kneeling next to me. He looks exhausted."
    "La tristeza y la culpa llenan mi corazón antes de que vuelva a la realidad.\nMe estoy apoyando contra la pared, Elias arrodillado junto a mí. Parece agotado."

# game/script.rpy:3454
translate es investigation_2_250dba18:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0135.ogg"
    # e "I-I apologize, I should have come for you sooner. Are you alright?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0135.ogg"
    e "D-debo disculparme, debería haber venido por ti antes. ¿Estás bien?"

# game/script.rpy:3458
translate es investigation_2_09289e97:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0192.ogg"
    # t "[your_name], are you okay? What happened? You suddenly shouted and..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0192.ogg"
    t "[your_name], ¿estás bien? ¿Qué pasó? De repente gritaste y..."

# game/script.rpy:3462
translate es investigation_2_64555184:

    # "I nod, my heart pounding out of my chest."
    "Asiento, con el corazón latiendo fuera de mi pecho."

# game/script.rpy:3464
translate es investigation_2_486d1bfc:

    # p "... I'm alright."
    p "... Estoy bien."

# game/script.rpy:3466
translate es investigation_2_4ec8fffd:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0136.ogg"
    # e sad forward_lidded_small ah_sad "I am relieved to hear that."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0136.ogg"
    e sad forward_lidded_small ah_sad "Me alivia escucharlo."

# game/script.rpy:3472
translate es investigation_2_afef629f:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0193.ogg"
    # t "Oh, thank god..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0193.ogg"
    t "Oh, gracias a Dios..."

# game/script.rpy:3478
translate es investigation_2_54c32f4d:

    # p "Elias, did you feel that... connection?"
    p "Elias, ¿sentiste esa... conexión?"

# game/script.rpy:3480
translate es investigation_2_b9cc5566:

    # "Elias nods."
    "Elias asiente."

# game/script.rpy:3482
translate es investigation_2_6282aaa6:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0137.ogg"
    # e sad closed_sad ah_sad "If only for a brief moment, yes. I saw a redheaded gentleman smiling at you. Who is that, if I may ask?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0137.ogg"
    e sad closed_sad ah_sad "Aunque sea por un breve momento, sí. Vi a un caballero pelirrojo sonriéndote. ¿Quién es, si puedo preguntar?"

# game/script.rpy:3488
translate es investigation_2_dd257f9d:

    # "Taylor immediately pops into my mind."
    "Taylor inmediatamente viene a mi mente."

# game/script.rpy:3490
translate es investigation_2_c81da78d:

    # p "A friend. He's a friend."
    p "Un amigo. Es un amigo."

# game/script.rpy:3494
translate es investigation_2_80e0ca08:

    # "I swear I catch a flash of jealousy across Elias' face, but it dissipates just as quickly as it appeared."
    "Juro que percibo un destello de celos en el rostro de Elias, pero desaparece tan rápido como apareció."

# game/script.rpy:3496
translate es investigation_2_13f202fc:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0138.ogg"
    # e neutral forward_regular ah_sad "I would love to meet your friend."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0138.ogg"
    e neutral forward_regular ah_sad "Me encantaría conocer a tu amigo."

# game/script.rpy:3502
translate es investigation_2_c4d23ece:

    # p "I would love for you to meet him as well... and I'm sure that he would be excited for the opportunity, too."
    p "También me encantaría que lo conocieras... y estoy segur@ de que él estaría emocionado por la oportunidad también."

# game/script.rpy:3504
translate es investigation_2_a2a90a4f:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0194.ogg"
    # t "Hm..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0194.ogg"
    t "Hm..."

# game/script.rpy:3510
translate es investigation_2_430b11df:

    # "Elias' expression softens as he leads me away from the dining room and into one of the many hallways."
    "La expresión de Elias se suaviza mientras me conduce fuera del comedor hacia uno de los muchos pasillos."

# game/script.rpy:3516
translate es investigation_2_8f10111e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0139.ogg"
    # e "Anyways, my darling, I did come back to find you as I have finally uncovered my grandmother's recipes. If you can tell me which one you'd like, I will make the preparations while you freshen up."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0139.ogg"
    e "De todos modos, cariño, regresé para encontrarte ya que finalmente descubrí las recetas de mi abuela. Si me dices cuál quieres, haré los preparativos mientras te refrescas."

# game/script.rpy:3520
translate es investigation_2_50a29d1d:

    # p "Oh, I'd really appreciate that. When it comes to the cake, I think I'd like to try..."
    p "Oh, realmente lo agradecería. Cuando se trata del pastel, creo que me gustaría probar..."

# game/script.rpy:3530
translate es investigation_2_ebb02a78:

    # p "I want to revisit the study... We might find something out about the Gallagher family business, or that curse that killed them all."
    p "Quiero volver al estudio... Podríamos descubrir algo sobre el negocio familiar de los Gallagher, o esa maldición que los mató a todos."

# game/script.rpy:3532
translate es investigation_2_0da81b6d:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0195.ogg"
    # t "Not a bad plan. Archibald Gallagher made his office in that study so he'd talk business deals there."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0195.ogg"
    t "No es un mal plan. Archibald Gallagher tenía su oficina en ese estudio, así que allí trataba los asuntos de negocios."

# game/script.rpy:3538
translate es investigation_2_03cfbbb4:

    # "I exit the dining room and head towards the study, back to where I first found Elias after waking up."
    "Salgo del comedor y me dirijo al estudio, de regreso a donde encontré a Elias después de despertar."

# game/script.rpy:3542
translate es investigation_2_66692e34:

    # p "Did you have any theories about the curse by the way, Taylor?"
    p "Por cierto, ¿tenías alguna teoría sobre la maldición, Taylor?"

# game/script.rpy:3544
translate es investigation_2_ac4b180d:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0196.ogg"
    # t "I know about as much as you do. Perhaps one of those shuttered small businesses cast black magic on the family in retaliation for Archibald using them as a stepping-stone on his way to the top?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0196.ogg"
    t "Sé tanto como tú. ¿Quizá uno de esos pequeños negocios cerrados lanzó magia negra sobre la familia en represalia por Archibald usarlos como escalón hacia la cima?"

# game/script.rpy:3548
translate es investigation_2_be94c231:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0197.ogg"
    # t "Mr. Archibald Gallagher was known to be a rather stern and ruthless businessman."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0197.ogg"
    t "El Sr. Archibald Gallagher era conocido por ser un hombre de negocios bastante severo y despiadado."

# game/script.rpy:3552
translate es investigation_2_4d784eae:

    # p "Guess we'll see if we can find any evidence of that in the ledgers."
    p "Supongo que veremos si podemos encontrar alguna evidencia de eso en los libros contables."

# game/script.rpy:3556
translate es investigation_2_2163ca2d:

    # "Back in the study, the gentle aroma of camomile tea permeates the room. Everything looks to be the same as the first time I was in here."
    "De vuelta en el estudio, el suave aroma de té de manzanilla impregna la habitación. Todo parece igual que la primera vez que estuve aquí."

# game/script.rpy:3558
translate es investigation_2_93f2cdba:

    # p "It looks like it's business as usual."
    p "Parece que todo sigue como siempre."

# game/script.rpy:3560
translate es investigation_2_26ea96fd:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0198.ogg"
    # t "What does that mean?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0198.ogg"
    t "¿Qué significa eso?"

# game/script.rpy:3564
translate es investigation_2_6dab855b:

    # p "The tea set that Elias had out is still here, and there's way too many books to look through. Not sure where to start."
    p "El juego de té que Elias había puesto sigue aquí, y hay demasiados libros para revisar. No sé por dónde empezar."

# game/script.rpy:3566
translate es investigation_2_ea29cbcc:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0199.ogg"
    # t "Unless he took a nap, he had to have been doing something."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0199.ogg"
    t "A menos que haya tomado una siesta, debía estar haciendo algo."

# game/script.rpy:3570
translate es investigation_2_3f439986:

    # "I scan the room once more, spotting a few new books on the desk. Maybe Elias was looking at those?"
    "Escaneo la habitación una vez más, viendo algunos libros nuevos sobre el escritorio. Tal vez Elias estaba revisando esos."

# game/script.rpy:3572
translate es investigation_2_5a20079e:

    # p "I'll start at the desk... there're some volumes here I didn't catch before."
    p "Empezaré por el escritorio... hay algunos volúmenes que no vi antes."

# game/script.rpy:3574
translate es investigation_2_690402c3:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0200.ogg"
    # t "Sounds good—"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0200.ogg"
    t "Suena bien—"

# game/script.rpy:3584
translate es investigation_2_0ed1d81c:

    # "Static cuts Taylor off again while\na rush of dizziness knocks me into the chair."
    "La estática corta a Taylor de nuevo mientras\nun mareo me derriba en la silla."

# game/script.rpy:3588
translate es investigation_2_241eef9d:

    # p "Not again—!"
    p "¡No otra vez—!"

# game/script.rpy:3594
translate es investigation_2_cb687a08:

    # "Hushed, hurried voices emanate in the darkness. Heavy feet stomp on plush rugs. Tension and anger loom in the air."
    "Voces susurradas y apresuradas emanan en la oscuridad. Pesados pasos sobre alfombras mullidas. La tensión y la ira llenan el aire."

# game/script.rpy:3596
translate es investigation_2_a69de1dc:

    # "Louder... Louder... They're yelling... They're shouting!"
    "¡Más fuerte... Más fuerte... Están gritando... Están vociferando!"

# game/script.rpy:3598
translate es investigation_2_1298c2ba:

    # "Which way is up? Which way is down? I don't know if I'm standing, or floating, or sitting, or lying."
    "¿Hacia arriba o hacia abajo? No sé si estoy de pie, flotando, sentado o acostado."

# game/script.rpy:3600
translate es investigation_2_cf4d1ac6:

    # "I can't feel anything, I'm suffocating,\nmy lungs are bursting, I want to cry."
    "No siento nada, me estoy asfixiando,\nmis pulmones estallan, quiero llorar."

# game/script.rpy:3604
translate es investigation_2_ac2ae7c5:

    # "A tiny ray of light blinds me. I rush towards it in hopes of it granting me solace; cupping my hands around it so it doesn't escape."
    "Un pequeño rayo de luz me enceguece. Me apresuro hacia él con la esperanza de que me brinde alivio; cubro mis manos alrededor para que no escape."

# game/script.rpy:3610
translate es investigation_2_2fae999f:

    # "Inside the light is a little motion picture; two figures in the study, one taller and older in a chair; the other much more youthful, leaning on a cane held in his right hand."
    "Dentro de la luz hay una pequeña película en movimiento; dos figuras en el estudio, una más alta y mayor en una silla; la otra mucho más joven, apoyada en un bastón sostenido en su mano derecha."

# game/script.rpy:3616
translate es investigation_2_3dbaed05:

    # "The figure is vaguely familiar, yet I barely recognize him. His skin isn't translucent and blue."
    "La figura me resulta vagamente familiar, pero apenas la reconozco. Su piel no es translúcida ni azul."

# game/script.rpy:3622
translate es investigation_2_5154676d:

    # "It's Elias."
    "Es Elias."

# game/script.rpy:3628
translate es investigation_2_3aa28481:

    # voice "audio/voice/" + persistent.lang_voice + "/Archibald_0001.ogg"
    # ar "Blast it all! Your sister died earlier this spring and {i}already{/i} we have to make arrangements for the next funeral!"
    voice "audio/voice/" + persistent.lang_voice + "/Archibald_0001.ogg"
    ar "¡Maldita sea! Tu hermana murió esta primavera y {i}ya{/i} tenemos que hacer arreglos para el próximo funeral!"

# game/script.rpy:3640
translate es investigation_2_cc048da4:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0140.ogg"
    # e "Father, if you would let me speak just once—"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0140.ogg"
    e "Padre, si me permitiera hablar una sola vez—"

# game/script.rpy:3644
translate es investigation_2_b2c61e91:

    # voice "audio/voice/" + persistent.lang_voice + "/Archibald_0002.ogg"
    # ar "What is it, Elias? I don't have time for idle chatter from a child like you."
    voice "audio/voice/" + persistent.lang_voice + "/Archibald_0002.ogg"
    ar "¿Qué sucede, Elias? No tengo tiempo para charlas ociosas de un niño como tú."

# game/script.rpy:3654
translate es investigation_2_d1a48e2c:

    # "Elias taps his cane on the carpet several times in barely restrained protest, though the man named Archibald Gallagher doesn't notice."
    "Elias golpea su bastón contra la alfombra varias veces en una protesta apenas contenida, aunque el hombre llamado Archibald Gallagher no se da cuenta."

# game/script.rpy:3661
translate es investigation_2_1fdb4039:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0141.ogg"
    # e "I am {i}not{/i} a child anymore! I am already of age, and I'd like to make a single request of you. It will not be too much trouble to you, Father."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0141.ogg"
    e "¡Ya no soy un niño! Ya soy mayor de edad y me gustaría hacer una sola petición. No será demasiado problema para ti, padre."

# game/script.rpy:3665
translate es investigation_2_7b0877d4:

    # voice "audio/voice/" + persistent.lang_voice + "/Archibald_0003.ogg"
    # ar "And what would that be?"
    voice "audio/voice/" + persistent.lang_voice + "/Archibald_0003.ogg"
    ar "¿Y cuál sería esa?"

# game/script.rpy:3671
translate es investigation_2_0f2955b4:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0142.ogg"
    # e "My mirror has been in need of repair for the longest time. If you could have someone restore it—"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0142.ogg"
    e "Mi espejo ha necesitado reparación desde hace mucho. Si pudieras hacer que alguien lo restaurara—"

# game/script.rpy:3677
translate es investigation_2_bc8cc4b6:

    # voice "audio/voice/" + persistent.lang_voice + "/Archibald_0004.ogg"
    # ar "What mirror?"
    voice "audio/voice/" + persistent.lang_voice + "/Archibald_0004.ogg"
    ar "¿Qué espejo?"

# game/script.rpy:3683
translate es investigation_2_1e419be4:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0143.ogg"
    # e "G-Grandmother's mirror, the one that used to be in the attic. It shattered, but I still have all the pieces!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0143.ogg"
    e "E-El espejo de la abuela, el que estaba en el ático. Se rompió, ¡pero todavía tengo todas las piezas!"

# game/script.rpy:3687
translate es investigation_2_4b350eac:

    # "Archibald turns toward his son in disgust."
    "Archibald se vuelve hacia su hijo con disgusto."

# game/script.rpy:3689
translate es investigation_2_fc50924f:

    # voice "audio/voice/" + persistent.lang_voice + "/Archibald_0005.ogg"
    # ar "You still have that trash in your room? And you dare ask me to repair it after {i}you{/i} broke it!?"
    voice "audio/voice/" + persistent.lang_voice + "/Archibald_0005.ogg"
    ar "¿Todavía tienes esa basura en tu habitación? ¿Y te atreves a pedirme que lo repare después de que {i}tú{/i} lo rompiste!?"

# game/script.rpy:3697
translate es investigation_2_aacb05cc:

    # "Elias' knuckles turn white on his left fist while he's trying to keep as much of a neutral face as he can."
    "Los nudillos de Elias se ponen blancos en su puño izquierdo mientras intenta mantener una expresión neutral lo más posible."

# game/script.rpy:3699
translate es investigation_2_00f768c2:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0144.ogg"
    # e "It wasn't me! It was—"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0144.ogg"
    e "¡No fui yo! Fue—"

# game/script.rpy:3703
translate es investigation_2_53ce1d48:

    # voice "audio/voice/" + persistent.lang_voice + "/Archibald_0006.ogg"
    # ar "I have no time for your childish sentimentality, Elias. That mirror is worth nothing, and I have much more pressing matters to attend to."
    voice "audio/voice/" + persistent.lang_voice + "/Archibald_0006.ogg"
    ar "No tengo tiempo para tu sentimentalismo infantil, Elias. Ese espejo no vale nada, y tengo asuntos mucho más urgentes que atender."

# game/script.rpy:3709
translate es investigation_2_35e47a10:

    # voice "audio/voice/" + persistent.lang_voice + "/Archibald_0007.ogg"
    # ar "Leave now, or I'll have one of the servants remove you!"
    voice "audio/voice/" + persistent.lang_voice + "/Archibald_0007.ogg"
    ar "¡Vete ahora, o haré que uno de los sirvientes te saque!"

# game/script.rpy:3717
translate es investigation_2_cb4394ef:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0145.ogg"
    # e "Father, I can walk on my own two feet just fine."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0145.ogg"
    e "Padre, puedo caminar perfectamente por mis propios pies."

# game/script.rpy:3721
translate es investigation_2_b04721d6:

    # "If Archibald heard Elias, he certainly didn't care to react."
    "Si Archibald escuchó a Elias, ciertamente no le importó reaccionar."

# game/script.rpy:3727
translate es investigation_2_9f9ee121:

    # "Elias grips his cane tightly before turning towards the door, and in the process, our eyes meet."
    "Elias agarra su bastón con fuerza antes de girar hacia la puerta, y en el proceso, nuestras miradas se cruzan."

# game/script.rpy:3729
translate es investigation_2_2b90ca71:

    # "My breath hitches in my throat before I can muster the willpower to do anything else."
    "Mi respiración se detiene en mi garganta antes de poder reunir la fuerza de voluntad para hacer cualquier otra cosa."

# game/script.rpy:3733
translate es investigation_2_c57e1b03:

    # "And just like that, the scene disappears with a blink."
    "Y así, la escena desaparece en un parpadeo."

# game/script.rpy:3741
translate es investigation_2_8ee47b2f:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0201.ogg"
    # t "— copy! Hey [your_name], do you copy!?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0201.ogg"
    t "— ¡copia! ¡Oye [your_name], ¿me copias!?"

# game/script.rpy:3745
translate es investigation_2_94613524:

    # p "T-Taylor!"
    p "¡T-Taylor!"

# game/script.rpy:3751
translate es investigation_2_88d1bae6:

    # "My vision adjusts and suddenly I'm back in the study I walked into. A cold sweat clings to my skin."
    "Mi visión se ajusta y de repente estoy de vuelta en el estudio al que entré. Un sudor frío se adhiere a mi piel."

# game/script.rpy:3753
translate es investigation_2_611192f0:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0202.ogg"
    # t "Another vision?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0202.ogg"
    t "¿Otra visión?"

# game/script.rpy:3757
translate es investigation_2_7c99f69a:

    # p "Y-yeah... I'm still not used to these..."
    p "S-sí... Todavía no me acostumbro a estas..."

# game/script.rpy:3759
translate es investigation_2_9ad22de9:

    # "These things are way worse than the one time Taylor and I tried experimenting with weed and got a bad batch."
    "Estas cosas son mucho peores que aquella vez que Taylor y yo intentamos experimentar con marihuana y nos tocó un lote malo."

# game/script.rpy:3761
translate es investigation_2_fb1181d1:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0203.ogg"
    # t "Give me a status report."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0203.ogg"
    t "Dame un informe de situación."

# game/script.rpy:3765
translate es investigation_2_00eafd73:

    # "I steady my breath and grip the arms of the chair as I sink down."
    "Enderezo la respiración y agarro los brazos de la silla mientras me hundo."

# game/script.rpy:3767
translate es investigation_2_048a36e6:

    # p "I um, I landed in the chair at least.\nAnd this time I saw Archibald Gallagher."
    p "Um, al menos caí en la silla.\nY esta vez vi a Archibald Gallagher."

# game/script.rpy:3769
translate es investigation_2_d0bc63be:

    # p "He was arranging the next family funeral while Elias wanted him to... fix a... mirror?"
    p "Estaba organizando el próximo funeral familiar mientras Elias quería que él... arreglara un... espejo?"

# game/script.rpy:3771
translate es investigation_2_b4e597e0:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0204.ogg"
    # t "... A mirror?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0204.ogg"
    t "... ¿Un espejo?"

# game/script.rpy:3775
translate es investigation_2_9d544874:

    # p "He said it belonged to his grandmother..."
    p "Dijo que pertenecía a su abuela..."

# game/script.rpy:3777
translate es investigation_2_9ebedc6a:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0205.ogg"
    # t "I'll see what I can find out about it. Was there anything else?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0205.ogg"
    t "Veré qué puedo averiguar al respecto. ¿Había algo más?"

# game/script.rpy:3781
translate es investigation_2_90f2d6c9:

    # p "One of the other things I saw was that Elias was using\na cane, and his dad said something about \"having servants remove him\" like he was an object..."
    p "Otra cosa que vi fue que Elias estaba usando\nun bastón, y su padre dijo algo sobre \"hacer que los sirvientes lo saquen\" como si fuera un objeto..."

# game/script.rpy:3783
translate es investigation_2_cd98c627:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0206.ogg"
    # t "What the actual fuck?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0206.ogg"
    t "¿Qué demonios?"

# game/script.rpy:3787
translate es investigation_2_0149e23c:

    # p "I don't know, Archibald said it as if Elias couldn't\nleave the study on his own, like he had zero autonomy. And of course Elias was really upset."
    p "No sé, Archibald lo dijo como si Elias no pudiera\nsalir del estudio por su cuenta, como si no tuviera autonomía. Y por supuesto, Elias estaba realmente molesto."

# game/script.rpy:3789
translate es investigation_2_c00161bc:

    # p "Fuck, {i}I'm{/i} upset about it."
    p "Maldita sea, {i}estoy{/i} molesto por esto."

# game/script.rpy:3791
translate es investigation_2_13046db0:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0207.ogg"
    # t "Take your time to catch your breath. Let me know when you're ready."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0207.ogg"
    t "Tómate tu tiempo para recuperar el aliento. Avísame cuando estés list@."

# game/script.rpy:3795
translate es investigation_2_35b9b55a:

    # "I close my eyes and take in another deep breath. These flashbacks or memories or whatever are extremely tiring, but assuming they're all from Elias' life..."
    "Cierro los ojos y tomo otra respiración profunda. Estos flashbacks o recuerdos o lo que sea son extremadamente agotadores, pero asumiendo que todos provienen de la vida de Elias..."

# game/script.rpy:3797
translate es investigation_2_a3774dd7:

    # "I shudder a little. I can't believe he had to go through that. I almost want to cry for him, but I don't know if I have enough time to do that right now."
    "Me estremezco un poco. No puedo creer que haya tenido que pasar por eso. Casi quiero llorar por él, pero no sé si tengo suficiente tiempo para hacerlo ahora mismo."

# game/script.rpy:3799
translate es investigation_2_1d8af0e7:

    # "I need to focus. I bring the chair up to the desk and immediately start rifling through the books."
    "Necesito concentrarme. Llevo la silla hasta el escritorio y empiezo a hojear los libros de inmediato."

# game/script.rpy:3803
translate es investigation_2_7d1d75da:

    # "There's a series of large notebooks filled with sheets upon sheets of information, aged yellow from the passage of time."
    "Hay una serie de cuadernos grandes llenos de hojas y hojas de información, amarillentas por el paso del tiempo."

# game/script.rpy:3807
translate es investigation_2_0c828c14:

    # p "I think I found the old Gallagher business ledgers. Journals detailing where all the assets are, as well."
    p "Creo que encontré los antiguos libros contables de Gallagher. Diarios que detallan dónde están todos los activos también."

# game/script.rpy:3811
translate es investigation_2_272e094a:

    # "I flip through more pages. More books."
    "Paso más páginas. Más libros."

# game/script.rpy:3813
translate es investigation_2_4b3c4791:

    # p "There's bank names but... no clue as to where the jewels might be."
    p "Hay nombres de bancos pero... ninguna pista de dónde podrían estar las joyas."

# game/script.rpy:3815
translate es investigation_2_7ce74f49:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0208.ogg"
    # t "So close, yet so far."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0208.ogg"
    t "Tan cerca, pero tan lejos."

# game/script.rpy:3821
translate es investigation_2_a5bae515:

    # "I reach the end of the final notebook and stare stunned at the last leaf. Unlike the other pages written in neat black ink, a red scrawl screams at me."
    "Llego al final del último cuaderno y me quedo atónito ante la última hoja. A diferencia de las otras páginas escritas con tinta negra prolija, un garabato rojo me grita."

# game/script.rpy:3823
translate es investigation_2_cf0527cf:

    # p "The... hell...?"
    p "¿El... qué demonios...?"

# game/script.rpy:3825
translate es investigation_2_3f82b408:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0209.ogg"
    # t "What's wrong?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0209.ogg"
    t "¿Qué pasa?"

# game/script.rpy:3829
translate es investigation_2_13258ef5:

    # p "The last page of the ledger says, {color=#ed1f29}\"Those without fortune cling to what they can.\"{/color} It's written in red ink like... someone was desperate..."
    p "La última página del libro contable dice, {color=#ed1f29}\"Los que no tienen fortuna se aferran a lo que pueden.\"{/color} Está escrito con tinta roja como... alguien estaba desesperado..."

# game/script.rpy:3831
translate es investigation_2_d7454be9:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0210.ogg"
    # t "Wow, that's... ominous and not helpful at all. What does it even mean?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0210.ogg"
    t "Vaya, eso es... ominoso y nada útil. ¿Qué significa siquiera?"

# game/script.rpy:3835
translate es investigation_2_17078b4c:

    # p "Elias is probably the only one who knows."
    p "Probablemente Elias sea el único que lo sabe."

# game/script.rpy:3839
translate es investigation_2_e51eea3e:

    # "I sift through the ledgers once more. After a sigh, I put the books away."
    "Reviso los libros una vez más. Tras un suspiro, guardo los libros."

# game/script.rpy:3841
translate es investigation_2_48bd0ea4:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0211.ogg"
    # t "Nothing else?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0211.ogg"
    t "¿Nada más?"

# game/script.rpy:3845
translate es investigation_2_08c00fa8:

    # p "Only hastily scribbled locations."
    p "Solo ubicaciones garabateadas apresuradamente."

# game/script.rpy:3847
translate es investigation_2_56e70331:

    # p "... I think I'd better get back."
    p "... Creo que será mejor que regrese."

# game/script.rpy:3851
translate es investigation_2_c9b9e362:

    # "I quickly put everything away where I found it, then stand up from the desk. After scanning the study one last time, I head out back into the hallway."
    "Rápidamente guardo todo donde lo encontré, luego me levanto del escritorio. Tras revisar el estudio por última vez, salgo de nuevo al pasillo."

# game/script.rpy:3857
translate es investigation_2_c3cabd0c:

    # "Just as I'm a few paces from the study, I see Elias turn the corner with a giant grin on his face."
    "Justo cuando estoy a unos pasos del estudio, veo a Elias girar la esquina con una enorme sonrisa en el rostro."

# game/script.rpy:3863
translate es investigation_2_79ae12fd:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0146.ogg"
    # e "Good news, [your_name]! I have recovered the recipes. No need to fret any longer!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0146.ogg"
    e "¡Buenas noticias, [your_name]! He recuperado las recetas. ¡No hay necesidad de preocuparse más!"

# game/script.rpy:3867
translate es investigation_2_6c6e40bb:

    # "I jump as he floats closer, quickly trying to regain my composure. Elias, completely oblivious to my panic, continues giving me a reassuring smile."
    "Salto cuando se acerca flotando, tratando de recuperar mi compostura rápidamente. Elias, completamente ajeno a mi pánico, sigue dándome una sonrisa tranquilizadora."

# game/script.rpy:3873
translate es investigation_2_a3e080f0:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0147.ogg"
    # e "It's alright, my dear. Now then, have you decided on a flavor?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0147.ogg"
    e "Está bien, cariño. Ahora, ¿has decidido el sabor?"

# game/script.rpy:3877
translate es investigation_2_34a070ca:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0212.ogg"
    # t "Choose funfetti, choose funfetti!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0212.ogg"
    t "¡Elige funfetti, elige funfetti!"

# game/script.rpy:3881
translate es investigation_2_aeb6bf47:

    # "Ignoring Taylor, I choose..."
    "Ignorando a Taylor, yo elijo..."

# game/script.rpy:3893
translate es investigation_2_6c0fe8b8:

    # "I exit the dining room and head towards some stairs to the side of the foyer."
    "Salgo del comedor y me dirijo hacia unas escaleras al lado del vestíbulo."

# game/script.rpy:3897
translate es investigation_2_ee22230e:

    # p "If I remember right, Elias Gallagher lived a solitary and mostly sedentary life inside this manor."
    p "Si recuerdo bien, Elias Gallagher vivió una vida solitaria y mayormente sedentaria dentro de esta mansión."

# game/script.rpy:3899
translate es investigation_2_69dc6c54:

    # p "If he was put on bedrest for the majority of his time here, chances are that he'd stash personal valuables in his bedroom for easy access."
    p "Si estuvo en reposo en cama durante la mayor parte de su tiempo aquí, es probable que haya escondido objetos de valor personales en su habitación para fácil acceso."

# game/script.rpy:3901
translate es investigation_2_24fb4b59:

    # p "I don't know where his room would be, but I get the feeling it's upstairs. Either way, we're about to find out."
    p "No sé dónde estaría su habitación, pero tengo la sensación de que está arriba. De cualquier forma, estamos a punto de descubrirlo."

# game/script.rpy:3905
translate es investigation_2_7c0c9cc9:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0213.ogg"
    # t "And what are you planning to do? Reenact the BJ scene from Ghostbusters?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0213.ogg"
    t "¿Y qué planeas hacer? ¿Recrear la escena de BJ de Cazafantasmas?"

# game/script.rpy:3909
translate es investigation_2_1931706d:

    # "I laugh, shaking my head."
    "Me río, sacudiendo la cabeza."

# game/script.rpy:3913
translate es investigation_2_954f70e2:

    # p "{i}You're{/i} the one who wrote those types of scenes in that notebook I found in the club room."
    p "{i}Tú{/i} eres quien escribió ese tipo de escenas en ese cuaderno que encontré en la sala del club."

# game/script.rpy:3915
translate es investigation_2_8ca7e6d9:

    # "Taylor starts to stutter as he tries to come up with an excuse."
    "Taylor empieza a tartamudear mientras intenta inventar una excusa."

# game/script.rpy:3919
translate es investigation_2_920e367f:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0214.ogg"
    # t "That— I never— How did you even—!?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0214.ogg"
    t "Eso— yo nunca— ¡¿Cómo siquiera...!?"

# game/script.rpy:3927
translate es investigation_2_7997cee1:

    # "I try not to break out in laughter, for fear that Elias might hear me."
    "Intento no reírme, por miedo a que Elias me escuche."

# game/script.rpy:3929
translate es investigation_2_861a99e9:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0215.ogg"
    # t "That notebook contains highly classified information, I'll have you know, and I do not appreciate the invasion of my privacy!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0215.ogg"
    t "Ese cuaderno contiene información altamente clasificada, te hago saber, y no aprecio la invasión de mi privacidad."

# game/script.rpy:3933
translate es investigation_2_520646ed:

    # p "You're the one who left it open."
    p "Tú eres quien lo dejó abierto."

# game/script.rpy:3935
translate es investigation_2_b28f6587:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0216.ogg"
    # t "Still, I... never mind, forget it."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0216.ogg"
    t "Aun así, yo... olvídalo."

# game/script.rpy:3941
translate es investigation_2_fb11cf85:

    # p "Oh, this door is slightly ajar? Guess I'll go in."
    p "Oh, ¿esta puerta está un poco entreabierta? Supongo que entraré."

# game/script.rpy:3945
translate es investigation_2_9e718a9a:

    # "I swing the door completely open, wincing as the hinges creak."
    "Abro la puerta completamente, haciendo una mueca mientras las bisagras crujen."

# game/script.rpy:3951
translate es investigation_2_89ab1838:

    # p "It's... another bedroom?"
    p "¿Es... otra habitación?"

# game/script.rpy:3953
translate es investigation_2_69f09c0b:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0217.ogg"
    # t "What's wrong?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0217.ogg"
    t "¿Qué pasa?"

# game/script.rpy:3957
translate es investigation_2_eed6750d:

    # p "The layout is the same, but it almost looks... sad?"
    p "La disposición es la misma, pero casi se ve... triste?"

# game/script.rpy:3959
translate es investigation_2_acbe0807:

    # "I take this moment to look at what's in front of me."
    "Aprovecho este momento para mirar lo que tengo frente a mí."

# game/script.rpy:3961
translate es investigation_2_5cd79798:

    # "In the center is a bed that's perfectly made. Fluffy pillows donned in silk covers sit upon a thick comforter."
    "En el centro hay una cama perfectamente hecha. Almohadas esponjosas con fundas de seda descansan sobre un grueso edredón."

# game/script.rpy:3963
translate es investigation_2_781acdc3:

    # "My hand runs over the plush fabric as I walk up to the bedside table."
    "Mi mano recorre la tela suave mientras me acerco a la mesita de noche."

# game/script.rpy:3965
translate es investigation_2_445934ea:

    # "There's a few books here, but overall, this room is almost barren compared to the one I woke up in."
    "Hay algunos libros aquí, pero en general, esta habitación está casi vacía comparada con la que desperté."

# game/script.rpy:3967
translate es investigation_2_a7ff0b4c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0218.ogg"
    # t "I'm actually not too surprised. There were seven kids and the heads of the household after all, so it wouldn't be unusual for the bedrooms to look the same."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0218.ogg"
    t "No estoy realmente sorprendido. Después de todo, había siete niños y los jefes del hogar, así que no sería inusual que las habitaciones se vieran iguales."

# game/script.rpy:3971
translate es investigation_2_19803b2f:

    # p "I guess that's fair."
    p "Supongo que eso es justo."

# game/script.rpy:3973
translate es investigation_2_7be5e649:

    # "I catch a glimpse of something on the vanity and head over to it."
    "Veo algo en el tocador y me dirijo hacia ello."

# game/script.rpy:3975
translate es investigation_2_371d902a:

    # p "Hey, there's an ornate box on the vanity. Surely something like this has to contain something important in it, right?"
    p "Hey, hay una caja ornamentada en el tocador. Seguramente algo así tiene que contener algo importante, ¿no?"

# game/script.rpy:3977
translate es investigation_2_87d12ca1:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0219.ogg"
    # t "Be careful, we don't know if that's spring-loaded with some kinda trap."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0219.ogg"
    t "Ten cuidado, no sabemos si está cargada con algún tipo de trampa."

# game/script.rpy:3981
translate es investigation_2_5cf7f385:

    # p "I don't think it will be but..."
    p "No creo que lo esté pero..."

# game/script.rpy:3983
translate es investigation_2_7c9af926:

    # "I hold my breath and take off the lid slowly."
    "Contengo la respiración y retiro la tapa lentamente."

# game/script.rpy:3991
translate es investigation_2_868fb9fc:

    # p "... Glass... shards? That's it?"
    p "... ¿Vidrio... astillas? ¿Eso es todo?"

# game/script.rpy:3995
translate es investigation_2_ce949910:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0220.ogg"
    # t "Seriously? Why waste such a neat box like that on trash?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0220.ogg"
    t "¿En serio? ¿Por qué desperdiciar una caja tan bonita en basura?"

# game/script.rpy:3999
translate es investigation_2_48ab7c82:

    # p "... Maybe it's something important?"
    p "... ¿Tal vez sea algo importante?"

# game/script.rpy:4001
translate es investigation_2_7aae5501:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0221.ogg"
    # t "Kinda doubt it."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0221.ogg"
    t "Lo dudo bastante."

# game/script.rpy:4009
translate es investigation_2_ad193788:

    # "I slide the lid back onto the box and look around the rest of the bedroom. There's a bookshelf in the corner I hadn't noticed when I walked in."
    "Vuelvo a colocar la tapa en la caja y miro alrededor del resto del dormitorio. Hay una estantería en la esquina que no había notado al entrar."

# game/script.rpy:4011
translate es investigation_2_0633057c:

    # p "Guess what? There's another bookshelf in here. Guess it must actually be Elias' bedroom after all."
    p "¿Adivina qué? Hay otra estantería aquí. Supongo que en realidad debe ser la habitación de Elias."

# game/script.rpy:4013
translate es investigation_2_a17ebc46:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0222.ogg"
    # t "What's on it?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0222.ogg"
    t "¿Qué hay en ella?"

# game/script.rpy:4019
translate es investigation_2_88c48bc7:

    # p "Seems to all be fiction... {i}Jane Eyre{/i}, {i}Persuasion{/i}, {i}Sentimental Education{/i}, {i}The Portrait of a Lady{/i}..."
    p "Parece toda ficción... {i}Jane Eyre{/i}, {i}Persuasión{/i}, {i}Educación sentimental{/i}, {i}El retrato de una dama{/i}..."

# game/script.rpy:4021
translate es investigation_2_a3536062:

    # "The click of the keyboard is comforting as Taylor lets out a chuckle."
    "El clic del teclado es reconfortante mientras Taylor suelta una risa."

# game/script.rpy:4023
translate es investigation_2_f2849b0d:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0223.ogg"
    # t "Those are all romance novels."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0223.ogg"
    t "Todos son novelas románticas."

# game/script.rpy:4027
translate es investigation_2_c5bf1605:

    # "My fingers gently brush over the well worn spines. It looks like they've been read countless times."
    "Mis dedos rozan suavemente los lomos gastados. Parece que han sido leídas innumerables veces."

# game/script.rpy:4029
translate es investigation_2_25b21408:

    # p "Not only did he lack familial love, it looked like Elias didn't have any platonic or romantic love, either. He was stuck here...and only had a fantasy world to live in."
    p "No solo carecía de amor familiar, también parece que Elias no tuvo amor platónico o romántico. Estaba atrapado aquí... y solo tenía un mundo de fantasía para vivir."

# game/script.rpy:4031
translate es investigation_2_fddba29f:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0224.ogg"
    # t "[your_name], don't feel too bad for him. We can't change what his life was like, no matter how sad it is. It's already over."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0224.ogg"
    t "[your_name], no te sientas demasiado mal por él. No podemos cambiar cómo fue su vida, por muy triste que sea. Ya terminó."

# game/script.rpy:4035
translate es investigation_2_eb7b24b3:

    # p "The least I can provide is solace. Make his afterlife a little more enjoyable. Less lonely."
    p "Lo mínimo que puedo ofrecer es consuelo. Hacer que su otra vida sea un poco más agradable. Menos solitaria."

# game/script.rpy:4037
translate es investigation_2_c9cee039:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0225.ogg"
    # t "Don't fall for his act."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0225.ogg"
    t "No caigas en su actuación."

# game/script.rpy:4041
translate es investigation_2_f5f37e26:

    # "I scoff slightly."
    "Resoplo levemente."

# game/script.rpy:4043
translate es investigation_2_671aa40f:

    # p "Act? What act? Elias has {i}not once{/i} shown any hostility or invasiveness. He doesn't have {i}any{/i} malicious intent."
    p "¿Actuación? ¿Qué actuación? Elias no ha mostrado {i}ni una sola vez{/i} hostilidad ni invasión. No tiene {i}ninguna{/i} intención maliciosa."

# game/script.rpy:4045
translate es investigation_2_8532fb4f:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0226.ogg"
    # t "But... but what if he tries to possess you? Didn't he—"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0226.ogg"
    t "Pero... ¿y si intenta poseerte? ¿No podría..."

# game/script.rpy:4053
translate es investigation_2_d03f3897:

    # p "Taylor. I appreciate your concern and I care about you a lot, but accusing Elias of something like that without any evidence — especially considering how he died — is unreasonable. You're being paranoid."
    p "Taylor. Aprecio tu preocupación y me importas mucho, pero acusar a Elias de algo así sin pruebas —especialmente considerando cómo murió— es irrazonable. Estás paranoico."

# game/script.rpy:4055
translate es investigation_2_c4478803:

    # "The line is silent. For a moment I think he may have hung up on me, but his quiet voice finally breaks the silence."
    "La línea queda en silencio. Por un momento pienso que podría haber colgado, pero su voz tranquila finalmente rompe el silencio."

# game/script.rpy:4057
translate es investigation_2_5a79f150:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0227.ogg"
    # t "I'm sorry."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0227.ogg"
    t "Lo siento."

# game/script.rpy:4061
translate es investigation_2_7270ff2b:

    # "He sounds upset. It elicits a soft sigh from me, my whole demeanor softening."
    "Suena molesto. Me provoca un suave suspiro, y toda mi actitud se suaviza."

# game/script.rpy:4065
translate es investigation_2_b3d1674f:

    # p "... I apologize if I sounded harsh. Elias just deserves someone too, you know? He's all alone."
    p "... Me disculpo si soné dur@. Elias solo merece a alguien también, ¿sabes? Está completamente solo."

# game/script.rpy:4067
translate es investigation_2_a9559bcb:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0228.ogg"
    # t "I'm just really worried about you, bud. You're alone in there."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0228.ogg"
    t "Solo estoy realmente preocupado por ti. Estás sol@ ahí."

# game/script.rpy:4071
translate es investigation_2_f237def9:

    # p "Don't worry, Taylor. If I were truly in danger, I'd have asked you to come save me by now."
    p "No te preocupes, Taylor. Si realmente estuviera en peligro, te habría pedido que vinieras a salvarme ya."

# game/script.rpy:4073
translate es investigation_2_0ae79e87:

    # "Taylor's voice sounds less upset as he speaks."
    "La voz de Taylor suena menos molesta al hablar."

# game/script.rpy:4075
translate es investigation_2_27c3440c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0229.ogg"
    # t "Yeah. Yeah, of course. You're right."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0229.ogg"
    t "Sí. Sí, claro. Tienes razón."

# game/script.rpy:4079
translate es investigation_2_044f61fe:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0148.ogg"
    # e "[your_name]! Are you here?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0148.ogg"
    e "¡[your_name]! ¿Estás aquí?"

# game/script.rpy:4087
translate es investigation_2_be69233b:

    # p "Shoot, Elias is coming."
    p "Vaya, Elias viene."

# game/script.rpy:4089
translate es investigation_2_39297bb6:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0230.ogg"
    # t "H-he is!? Can you hide or something?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0230.ogg"
    t "¿É-él viene!? ¿Puedes esconderte o algo?"

# game/script.rpy:4093
translate es investigation_2_85c19545:

    # p "I'm trying—"
    p "Estoy tratando—"

# game/script.rpy:4097
translate es investigation_2_023533b5:

    # "Elias appears before me the moment I turn towards the doorway."
    "Elias aparece frente a mí justo cuando me giro hacia la puerta."

# game/script.rpy:4101
translate es investigation_2_2f2056a8:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0149.ogg"
    # e @ ah_sad "... What are you doing in here, my dear?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0149.ogg"
    e @ ah_sad "... ¿Qué haces aquí, cariño?"

# game/script.rpy:4105
translate es investigation_2_39d28e93:

    # p "T-the um, the door was open, and I noticed quite a few books on the shelves, so I wanted to see if the recipe might be in here."
    p "L-la eh, la puerta estaba abierta, y noté bastantes libros en las estanterías, así que quería ver si la receta podría estar aquí."

# game/script.rpy:4107
translate es investigation_2_e8ba89c0:

    # "I pull out a random book, a smile on my face."
    "Saco un libro al azar, con una sonrisa en el rostro."

# game/script.rpy:4109
translate es investigation_2_a55cb8f3:

    # p "You have quite the taste after all, Mr. Elias Gallagher."
    p "Tienes bastante gusto después de todo, Sr. Elias Gallagher."

# game/script.rpy:4113
translate es investigation_2_deaa15d2:

    # "My grin widens as Elias blushes."
    "Mi sonrisa se ensancha mientras Elias se sonroja."

# game/script.rpy:4115
translate es investigation_2_70c073de:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0231.ogg"
    # t "What, is he getting embarrassed over there?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0231.ogg"
    t "¿Qué, se está avergonzando allá?"

# game/script.rpy:4123
translate es investigation_2_8cc305d2:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0150.ogg"
    # e "I-I read it for the plot! It's actually quite good."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0150.ogg"
    e "L-lo leí por la trama! En realidad es bastante bueno."

# game/script.rpy:4129
translate es investigation_2_de836be9:

    # p "Really? Let's see..."
    p "¿De veras? Veamos..."

# game/script.rpy:4133
translate es investigation_2_799a02a3:

    # "I open to a random page. The corner is folded down like a bookmark. I clear my throat and start to read."
    "Abro una página al azar. La esquina está doblada como un marcador. Aclaro mi garganta y empiezo a leer."

# game/script.rpy:4135
translate es investigation_2_a56e2613:

    # p "\"Our clothes were long gone. I couldn't keep my hands off her. Every inch of her body called out to me...\" Oh—"
    p "\"!Nuestra ropa había desaparecido. No podía mantener mis manos lejos de ella. Cada centímetro de su cuerpo me llamaba...\" Oh—"

# game/script.rpy:4139
translate es investigation_2_9f215ca8:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0151.ogg"
    # e @ oh_disapprove "Heavens!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0151.ogg"
    e @ oh_disapprove "¡Cielos!"

# game/script.rpy:4143
translate es investigation_2_531c9e4b:

    # "Elias covers his face, bending over from embarrassment. I could hear Taylor having a laughing fit in the earpiece."
    "Elias se cubre el rostro, inclinándose por la vergüenza. Puedo escuchar a Taylor riéndose a carcajadas por el auricular."

# game/script.rpy:4145
translate es investigation_2_4b0d790f:

    # "Ignoring my own embarrassment, I put the book away and comfort Elias, however halfheartedly."
    "Ignorando mi propia vergüenza, guardo el libro y consuelo a Elias, aunque de manera poco convincente."

# game/script.rpy:4151
translate es investigation_2_8473c625:

    # p "My apologies!! It's quite alright that you... uh... that you divulge in all types of literature."
    p "¡Mis disculpas!! Está perfectamente bien que tú... eh... que te deleites con todo tipo de literatura."

# game/script.rpy:4153
translate es investigation_2_6cf54bd0:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0152.ogg"
    # e comical_surprised @ frown_open "I should have hidden those books better when you were asleep, I'm so sorry you had to see that..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0152.ogg"
    e comical_surprised @ frown_open "Debí haber escondido esos libros mejor mientras dormías, lo siento mucho que tuvieras que ver eso..."

# game/script.rpy:4157
translate es investigation_2_f4c5d46c:

    # p "I-I mean, it's fine? Most people are interested in sex—"
    p "Y-yo quiero decir, ¿está bien? La mayoría de la gente está interesada en el sexo—"

# game/script.rpy:4161
translate es investigation_2_df1cc5f4:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0153.ogg"
    # e comical_cry @ tch "Gaah!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0153.ogg"
    e comical_cry @ tch "¡Aaah!"

# game/script.rpy:4165
translate es investigation_2_c8ea8a4a:

    # p "..."
    p "..."

# game/script.rpy:4171
translate es investigation_2_0cc31b76:

    # e pout "..."
    e pout "..."

# game/script.rpy:4173
translate es investigation_2_a6b709e8:

    # p "Are you alright, dear?"
    p "¿Estás bien, querido?"

# game/script.rpy:4179
translate es investigation_2_de183fcc:

    # "Elias lets out a groan and peeks at me through his hands. He then slowly straightens, finding it hard to look me in the eye."
    "Elias deja escapar un gemido y me mira entre sus manos. Luego se endereza lentamente, encontrando difícil mirarme a los ojos."

# game/script.rpy:4181
translate es investigation_2_67bcada9:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0154.ogg"
    # e closed_sad sad oh_sad "I um, yes. I just find the subject of... physical intimacy to be rather difficult to talk about."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0154.ogg"
    e closed_sad sad oh_sad "Y-yo eh, sí. Solo que el tema de... la intimidad física me resulta bastante difícil de tratar."

# game/script.rpy:4185
translate es investigation_2_81ab4d4c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0232.ogg"
    # t "Oh, don't tell me the guy's a prude, he's freakin' obsessed with marriage. What does he expect married allosexual people to do?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0232.ogg"
    t "Oh, no me digas que el tipo es mojigato, está obsesionadísimo con el matrimonio. ¿Qué espera que hagan las personas alosexuales casadas?"

# game/script.rpy:4189
translate es investigation_2_83c7eaa1:

    # p "{i}Everyone in the Victorian Era was a prude, Taylor.{/i}"
    p "{i}Todo el mundo en la era victoriana era mojigato, Taylor.{/i}"

# game/script.rpy:4191
translate es investigation_2_0597c218:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0155.ogg"
    # e comical_surprised squiggle "Did you say something, [your_name]?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0155.ogg"
    e comical_surprised squiggle "¿Dijiste algo, [your_name]?"

# game/script.rpy:4195
translate es investigation_2_4adbf8cf:

    # "I clear my throat loudly while Taylor sighs on the other line."
    "Aclaro mi garganta ruidosamente mientras Taylor suspira al otro lado de la línea."

# game/script.rpy:4197
translate es investigation_2_d65feb01:

    # p "What I said was, were you never close to anyone before you met me?"
    p "Lo que dije fue, ¿nunca fuiste cercano a alguien antes de conocerme?"

# game/script.rpy:4199
translate es investigation_2_f4892333:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0156.ogg"
    # e @ comical_cry ah_sad concerned "I, well..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0156.ogg"
    e @ comical_cry ah_sad concerned "Y-yo, bueno..."

# game/script.rpy:4207
translate es investigation_2_1afd3df8:

    # "Elias plays nervously with his fingers, fascinated with the decor of his room instead of me."
    "Elias juega nerviosamente con los dedos, fascinado con la decoración de su habitación en lugar de conmigo."

# game/script.rpy:4209
translate es investigation_2_cb3bbe66:

    # p "Have you... ever kissed anyone?"
    p "¿Alguna vez... has besado a alguien?"

# game/script.rpy:4213
translate es investigation_2_62fd072a:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0157.ogg"
    # e comical_cry @ frown_open angry "N-no! I... was never... really thought of as attractive to anyone..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0157.ogg"
    e comical_cry @ frown_open angry "N-no! Y-yo... nunca... realmente se me consideró atractivo para nadie..."

# game/script.rpy:4217
translate es investigation_2_dca2c431:

    # p "Hold on, you? Not attractive? You're kidding right?"
    p "Espera, ¿tú? ¿No atractivo? ¿Estás bromeando, verdad?"

# game/script.rpy:4223
translate es investigation_2_d24745aa:

    # "Elias shrinks further into himself."
    "Elias se encoge aún más sobre sí mismo."

# game/script.rpy:4225
translate es investigation_2_d028b2a6:

    # p "Elias, you're one of the most handsome men I've ever met! I'm serious, the things I'd love to do to you—"
    p "¡Elias, eres uno de los hombres más guapos que he conocido! Hablo en serio, las cosas que me encantaría hacerte—"

# game/script.rpy:4229
translate es investigation_2_bcfc66ba:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0233.ogg"
    # t "{b}THE WHAT YOU'D DO TO WHO!?{/b}"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0233.ogg"
    t "{b}¿¡EL QUÉ HARÍAS A QUIÉN!?{/b}"

# game/script.rpy:4235
translate es investigation_2_05f53133:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0158.ogg"
    # e comical_surprised upset_open "{b}G-gaaah!{/b}"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0158.ogg"
    e comical_surprised upset_open "{b}¡G-gaaah!{/b}"

# game/script.rpy:4239
translate es investigation_2_8e4a785c:

    # "Ah shit, maybe I was too forward with that."
    "Ah mierda, tal vez fui demasiado directo con eso."

# game/script.rpy:4245
translate es investigation_2_5a4a70f7:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0159.ogg"
    # e "Darling [your_name], I'm quite flattered by your compliments, b-but I... have my reasons for... being inexperienced..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0159.ogg"
    e "Dulce [your_name], me siento halagado por tus cumplidos, p-pero yo... tengo mis razones para... ser sin inexperiencia..."

# game/script.rpy:4249
translate es investigation_2_a2054587:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0160.ogg"
    # e comical_cry frown_open "Well, beyond simply never having been properly wed before, of course..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0160.ogg"
    e comical_cry frown_open "Bueno, más allá de simplemente nunca haber estado propiamente casado antes, claro..."

# game/script.rpy:4261
translate es investigation_2_8238a8ee:

    # p "What sorts of things strike your fancy?"
    p "¿Qué tipo de cosas te llaman la atención?"

# game/script.rpy:4265
translate es investigation_2_0fe71bc6:

    # "Elias stops fidgeting as he calms down."
    "Elias deja de inquietarse mientras se calma."

# game/script.rpy:4267
translate es investigation_2_108b5e6d:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0161.ogg"
    # e up_regular "Oh, plenty of things! Like the flowers from earlier, reading books, writing, drinking tea... The list can go on and on, really."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0161.ogg"
    e up_regular "¡Oh, un montón de cosas! Como las flores de antes, leer libros, escribir, beber té... La lista puede seguir y seguir, en serio."

# game/script.rpy:4271
translate es investigation_2_ded04cc4:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0234.ogg"
    # t "Holy shit, he's so innocent. This is hilarious!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0234.ogg"
    t "¡Santo cielo, es tan inocente! ¡Esto es hilarante!"

# game/script.rpy:4277
translate es investigation_2_a3938f07:

    # "I want to hit Taylor so bad right now, but I can't really reach through my earpiece and strangle him from here so I bite the inside of my mouth."
    "Quiero golpear a Taylor ahora mismo, pero no puedo realmente alcanzar el auricular y estrangularlo desde aquí, así que muerdo el interior de mi boca."

# game/script.rpy:4279
translate es investigation_2_d0b824bf:

    # p "That's lovely dear, but I meant your interests in a more... intimate sense."
    p "Eso es encantador, cariño, pero me refería a tus intereses en un sentido más... íntimo."

# game/script.rpy:4283
translate es investigation_2_ef0355f2:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0162.ogg"
    # e comical_surprised concerned frown_disapprove "Intimate— oh heavens, this really isn't something to discuss out of wedlock!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0162.ogg"
    e comical_surprised concerned frown_disapprove "Íntimo— oh cielos, ¡esto realmente no es algo de lo que hablar fuera del matrimonio!"

# game/script.rpy:4287
translate es investigation_2_b6286140:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0163.ogg"
    # e comical_cry squiggle disapprove "P-please, I'm really only interested in satisfying my partner. Now, may we please return to the wedding preparations?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0163.ogg"
    e comical_cry squiggle disapprove "P-por favor, realmente solo me interesa satisfacer a mi pareja. Ahora, ¿podemos volver a los preparativos de la boda?"

# game/script.rpy:4293
translate es investigation_2_c48b056d:

    # p "I'm sure you'll perform well in the bedroom, Elias. After all, you're looking forward to what comes after the wedding ceremony, aren't you?"
    p "Estoy segur@ de que lo harás bien en el dormitorio, Elias. Después de todo, esperas lo que viene después de la ceremonia, ¿no?"

# game/script.rpy:4297
translate es investigation_2_fe20c53b:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0235.ogg"
    # t "{b}What the hell kind of comment is that!?{/b}"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0235.ogg"
    t "{b}¿Qué tipo de comentario es ese!?{/b}"

# game/script.rpy:4301
translate es investigation_2_a985bcf5:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0164.ogg"
    # e nervous up_left squiggle concerned "Ahahaha, I... well, was... I am. The um, consummation of our marriage that is."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0164.ogg"
    e nervous up_left squiggle concerned "Ahahaha, yo... bueno, estaba... estoy. La eh, consumación de nuestro matrimonio, eso es."

# game/script.rpy:4307
translate es investigation_2_ae251d00:

    # "Elias looks around nervously before puffing out his chest in mock bravado, or some semblance of it."
    "Elias mira alrededor nerviosamente antes de inflar el pecho con falsa valentía, o alguna apariencia de ella."

# game/script.rpy:4309
translate es investigation_2_b77d4ee1:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0165.ogg"
    # e lipbite_big bleed forward_heart happy "My strength and will is ever stronger after death, so I will do my best!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0165.ogg"
    e lipbite_big bleed forward_heart happy "¡Mi fuerza y voluntad son cada vez más fuertes tras la muerte, así que daré lo mejor de mí!"

# game/script.rpy:4313
translate es investigation_2_3c45bf43:

    # p "Ahaha, lovely! That's quite the spirit now."
    p "¡Ahaha, encantador! Ese espíritu está muy bien."

# game/script.rpy:4315
translate es investigation_2_5f7b04b1:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0236.ogg"
    # t "Ughhhhhhh..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0236.ogg"
    t "Ughhhhhhh..."

# game/script.rpy:4319
translate es investigation_2_26fc227a:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0166.ogg"
    # e left_small sad pout sweat "Anyhow, [your_name], it would be in our best interest to move forward with the preparations. If you may, please follow me."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0166.ogg"
    e left_small sad pout sweat "De cualquier manera, [your_name], sería lo mejor para nosotros continuar con los preparativos. Si puedes, sígueme por favor."

# game/script.rpy:4325
translate es investigation_2_08590f1a:

    # p "I'll guide you through it, my dear Elias. It's nothing to be ashamed of, at least in this day and age."
    p "Te guiaré a través de ello, mi querido Elias. No hay nada de qué avergonzarse, al menos en estos tiempos."

# game/script.rpy:4329
translate es investigation_2_7396307e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0167.ogg"
    # e comical_surprised oh_disapprove angry "O-oh, is it...?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0167.ogg"
    e comical_surprised oh_disapprove angry "O-oh, ¿en serio...?"

# game/script.rpy:4333
translate es investigation_2_fd66b76e:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0237.ogg"
    # t "Alright, I'm tuning this out, tell me when it's over."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0237.ogg"
    t "Está bien, voy a desconectarme de esto, dime cuando termine."

# game/script.rpy:4337
translate es investigation_2_2bd8856b:

    # p "It's not uncommon for one to explore themselves in solitude. How familiar are you with your own pleasure?"
    p "No es raro que uno explore su propio cuerpo en soledad. ¿Qué tan familiarizado estás con tu propio placer?"

# game/script.rpy:4341
translate es investigation_2_04eefa26:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0168.ogg"
    # e comical_cry sad pucker "I-I um... not very well, admittedly..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0168.ogg"
    e comical_cry sad pucker "Y-yo eh... no muy bien, admito..."

# game/script.rpy:4345
translate es investigation_2_52754eb8:

    # p "If you'd like, we can explore together."
    p "Si quieres, podemos explorar juntos."

# game/script.rpy:4347
translate es investigation_2_5704d0eb:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0169.ogg"
    # e nervous left_small pout "I... will consider it."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0169.ogg"
    e nervous left_small pout "Yo... lo consideraré."

# game/script.rpy:4351
translate es investigation_2_5ab5e404:

    # "He clears his throat, trying to regain his composure."
    "Aclara su garganta, tratando de recuperar la compostura."

# game/script.rpy:4353
translate es investigation_2_4ec8a0cd:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0170.ogg"
    # e forward_lidded_smaller sweat disapprove squiggle "Well, I um, did find the cake recipes. Would you care to join me back down on the ground floor?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0170.ogg"
    e forward_lidded_smaller sweat disapprove squiggle "Bueno, eh, encontré las recetas de pasteles. ¿Te gustaría acompañarme de nuevo a la planta baja?"

# game/script.rpy:4357
translate es investigation_2_41fee791:

    # p "Why yes, of course."
    p "Sí, por supuesto."

# game/script.rpy:4365
translate es investigation_2_0f57deb1:

    # "He floats out of the room and I follow him out to the foot of the stairs."
    "Flota fuera de la habitación y yo lo sigo hasta el pie de las escaleras."

# game/script.rpy:4373
translate es investigation_2_b79d2e3b:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0171.ogg"
    # e "I initially came to find you so I could ask what flavor of cake you would like. Have you decided?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0171.ogg"
    e "Inicialmente vine a encontrarte para preguntarte qué sabor de pastel quisieras. ¿Has decidido?"

# game/script.rpy:4379
translate es investigation_2_d798c9b2:

    # p "Oh, that's right! Let me think..."
    p "¡Ah, cierto! Déjame pensar..."

# game/script.rpy:4385
translate es investigation_2_df8a608f:

    # "We walk back to the first floor hallways as I ponder my options."
    "Volvemos a los pasillos del primer piso mientras considero mis opciones."

# game/script.rpy:4407
translate es cake_choice_d044b259:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0172.ogg"
    # e closed_happy goofgrin_drool happy "An excellent choice! You have the most wonderful taste, my dear."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0172.ogg"
    e closed_happy goofgrin_drool happy "¡Excelente elección! Tienes el gusto más maravilloso, cariño."

# game/script.rpy:4411
translate es cake_choice_950b6fb6:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0173.ogg"
    # e forward_heart smug neutral "Please, let me handle the remainder. If you wish to rest, please, I encourage you to do so."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0173.ogg"
    e forward_heart smug neutral "Por favor, déjame manejar lo restante. Si deseas descansar, te animo a que lo hagas."

# game/script.rpy:4415
translate es cake_choice_9b8e5898:

    # p "Thank you, Elias. I shall take you up on that offer."
    p "Gracias, Elias. Aceptaré tu oferta."

# game/script.rpy:4419
translate es cake_choice_853f4112:

    # "Elias bows before floating off to some other part of the manor, leaving me alone again."
    "Elias se inclina antes de flotar hacia otra parte de la mansión, dejándome sola nuevamente."

# game/script.rpy:4421
translate es cake_choice_01328219:

    # p "... Okay, he's gone."
    p "... Bien, se ha ido."

# game/script.rpy:4423
translate es cake_choice_c5fd4199:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0238.ogg"
    # t "Hey [your_name], you sound really exhausted. You should find some place to sit down and rest."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0238.ogg"
    t "Hey [your_name], suenas realmente agotad@. Deberías encontrar un lugar para sentarte y descansar."

# game/script.rpy:4427
translate es cake_choice_b80f584a:

    # p "Yeah... Give me a minute, alright?"
    p "Sí... Dame un minuto, ¿vale?"

# game/script.rpy:4429
translate es cake_choice_2fd6bf22:

    # "I take a look around the hallway. It really doesn't help that all these doors look the same."
    "Miro alrededor del pasillo. Realmente no ayuda que todas estas puertas se vean iguales."

# game/script.rpy:4431
translate es cake_choice_cfc5defc:

    # "Shrugging, I pick a random door and try the knob, and to my surprise it turns."
    "Encogiendo de hombros, elijo una puerta al azar y pruebo el pomo; para mi sorpresa, gira."

# game/script.rpy:4433
translate es cake_choice_e3b051f7:

    # p "I guess I'll go in here."
    p "Supongo que entraré aquí."

# game/script.rpy:4437
translate es cake_choice_b5620dde:

    # "I'm not entirely sure what I expected, but..."
    "No estoy del todo segur@ de qué esperaba, pero..."

# game/script.rpy:4439
translate es cake_choice_1ea40780:

    # p "It's a... bathroom?"
    p "¿Es un... baño?"

# game/script.rpy:4441
translate es cake_choice_70b0fc76:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0239.ogg"
    # t "Is it at least clean?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0239.ogg"
    t "¿Al menos está limpio?"

# game/script.rpy:4445
translate es cake_choice_2390e016:

    # p "Dusty, but not moldy. I guess I can sit on the porcelain throne."
    p "Polvoriento, pero no mohoso. Supongo que puedo sentarme en el trono de porcelana."

# game/script.rpy:4447
translate es cake_choice_dcf64e3e:

    # "I sweep my [clothing] to the side and close the lid before taking a seat."
    "Aparto mi [clothing] a un lado y cierro la tapa antes de sentarme."

# game/script.rpy:4449
translate es cake_choice_9944e2d4:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0240.ogg"
    # t "So how are you feeling? You've been through a lot, and that's the understatement of the century."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0240.ogg"
    t "Entonces, ¿cómo te sientes? Has pasado por mucho, y eso es quedarse corto."

# game/script.rpy:4453
translate es cake_choice_3eaaeabd:

    # p "I'm physically okay, more mentally exhausted, really. We've got so much evidence to sort through..."
    p "Físicamente estoy bien, más mentalmente agotad@, realmente. Tenemos tanta evidencia que revisar..."

# game/script.rpy:4455
translate es cake_choice_65f5a1f9:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0241.ogg"
    # t "Maybe we should go over everything we've learned so far?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0241.ogg"
    t "¿Quizás deberíamos repasar todo lo que hemos aprendido hasta ahora?"

# game/script.rpy:4459
translate es cake_choice_95f66e70:

    # p "I don't know how much time I have, but we might as well try."
    p "No sé cuánto tiempo tengo, pero bien podríamos intentarlo."

# game/script.rpy:4461
translate es cake_choice_c21eb933:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0242.ogg"
    # t "Assume you have a little, so talk as fast as you can!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0242.ogg"
    t "Supón que tienes un poco, ¡así que habla lo más rápido que puedas!"

# game/script.rpy:4465
translate es cake_choice_f0e4d953:

    # p "Okay, okay. So."
    p "Está bien, está bien. Entonces."

# game/script.rpy:4469
translate es cake_choice_0ae0816d:

    # p "Those visions, those are some horrifying things."
    p "Esas visiones, son cosas horribles."

# game/script.rpy:4471
translate es cake_choice_89e04389:

    # p "I think they're only scary because I'm feeling what Elias has felt... Otherwise they'd just be kind of spooky."
    p "Creo que solo son aterradoras porque estoy sintiendo lo que Elias ha sentido... De otra manera solo serían algo espeluznantes."

# game/script.rpy:4473
translate es cake_choice_9882f84d:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0260.ogg"
    # t "Are you afraid you're digging too deep?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0260.ogg"
    t "¿Tienes miedo de que estés cavando demasiado profundo?"

# game/script.rpy:4477
translate es cake_choice_f249dc7e:

    # p "What? I mean, I don't think I have a choice. As far as I can tell, it's all about trying not to remind Elias of his past."
    p "¿Qué? Quiero decir, no creo tener opción. Por lo que puedo decir, se trata de no recordarle a Elias su pasado."

# game/script.rpy:4479
translate es cake_choice_2ec0efd5:

    # p "... But we'll never get anything good if we don't."
    p "... Pero nunca conseguiremos algo bueno si no lo hacemos."

# game/script.rpy:4481
translate es cake_choice_1d33d3e3:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0261.ogg"
    # t "Okay, maybe take a step back and—"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0261.ogg"
    t "Está bien, quizá da un paso atrás y—"

# game/script.rpy:4485
translate es cake_choice_7683efe2:

    # p "Relax. I'm already here, I've seen the face of death in a sundress, and I think I can save our club."
    p "Relájate. Ya estoy aquí, he visto la cara de la muerte en un vestido veraniego, y creo que puedo salvar nuestro club."

# game/script.rpy:4487
translate es cake_choice_29fc4efe:

    # p "You've known me for forever. Trust me. {i}Please{/i}."
    p "Me conoces desde siempre. Confía en mí. {i}Por favor{/i}."

# game/script.rpy:4489
translate es cake_choice_a7ed08c2:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0262.ogg"
    # t "But—"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0262.ogg"
    t "Pero—"

# game/script.rpy:4493
translate es cake_choice_fd481344:

    # p "Violet has to be at the crux of all this... or close to it. If I keep seeing visions of things we couldn't find out in our research, we should be able to put together the bigger picture."
    p "Violet tiene que estar en el núcleo de todo esto... o cerca de él. Si sigo viendo visiones de cosas que no pudimos descubrir en nuestra investigación, deberíamos poder armar el panorama completo."

# game/script.rpy:4495
translate es cake_choice_b9e8c334:

    # p "There's so much more to this story than we ever could have thought."
    p "Hay mucho más en esta historia de lo que jamás pudimos imaginar."

# game/script.rpy:4497
translate es cake_choice_6bdaa4ac:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0263.ogg"
    # t "Definitely..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0263.ogg"
    t "Definitivamente..."

# game/script.rpy:4503
translate es cake_choice_eca7cfc0:

    # p "Elias has been nothing but a complete gentleman to me. Shame about the rest of the house, but his heart seems like it's in the right place."
    p "Elias no ha sido más que un completo caballeroso conmigo. Una pena por el resto de la casa, pero su corazón parece estar en el lugar correcto."

# game/script.rpy:4505
translate es cake_choice_a6576a5e:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0243.ogg"
    # t "If you say so..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0243.ogg"
    t "Si tú lo dices..."

# game/script.rpy:4509
translate es cake_choice_d5ae331c:

    # p "He is quite impressive at making bouquets. Maybe I am too? Should we take this back to the campus?"
    p "Es bastante impresionante haciendo ramos. ¿Quizá yo también lo soy? ¿Deberíamos llevar esto de vuelta al campus?"

# game/script.rpy:4511
translate es cake_choice_7d3dfc90:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0244.ogg"
    # t "Take what? Ghostly flower arrangements?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0244.ogg"
    t "¿Llevar qué? ¿Arreglos florales fantasmales?"

# game/script.rpy:4515
translate es cake_choice_5970b77b:

    # p "Yeah. Someone's gotta be interested, and there's no flower club at the university. It's an avenue, at least."
    p "Sí. Alguien tiene que interesarse, y no hay club de flores en la universidad. Es un camino, al menos."

# game/script.rpy:4517
translate es cake_choice_eea5b430:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0245.ogg"
    # t "There has to be more that you've found. {i}Please{/i}."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0245.ogg"
    t "Debe haber más cosas que hayas encontrado. {i}Por favor{/i}."

# game/script.rpy:4521
translate es cake_choice_c4900442:

    # p "Just teasing. Of course there's more!"
    p "Solo bromeo. ¡Por supuesto que hay más!"

# game/script.rpy:4523
translate es cake_choice_bdfcfdf8:

    # p "That sighting of Violet in the dining room was a lot. Like, a lot."
    p "Esa aparición de Violet en el comedor fue mucho. Mucho de verdad."

# game/script.rpy:4525
translate es cake_choice_16015196:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0246.ogg"
    # t "I know. And I didn't even see it!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0246.ogg"
    t "Lo sé. ¡Y ni siquiera lo vi!"

# game/script.rpy:4529
translate es cake_choice_08146230:

    # p "I think, in that brief moment, I hated her."
    p "Creo que, en ese breve momento, la odié."

# game/script.rpy:4531
translate es cake_choice_13b2fca1:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0247.ogg"
    # t "Whoa. Uh."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0247.ogg"
    t "Whoa. Eh."

# game/script.rpy:4535
translate es cake_choice_f777e2d4:

    # p "Why shouldn't I? She shouldn't {i}be{/i} here. She shouldn't be haunting Elias... She's the true danger."
    p "¿Por qué no debería hacerlo? Ella no debería {i}estar{/i} aquí. No debería estar persiguiendo a Elias... Ella es el verdadero peligro."

# game/script.rpy:4537
translate es cake_choice_7a39eec1:

    # p "And truth be told, I don't know if her spirit's {i}actually{/i} here at all. She might simply be a figment of Elias' memories."
    p "Y a decir verdad, no sé si su espíritu {i}realmente{/i} está aquí. Podría ser simplemente una creación de los recuerdos de Elias."

# game/script.rpy:4539
translate es cake_choice_b4ff48f6:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0248.ogg"
    # t "So Elias is the true danger then."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0248.ogg"
    t "Entonces Elias es el verdadero peligro."

# game/script.rpy:4543
translate es cake_choice_a4457c64:

    # p "... No, that's not what I said."
    p "... No, eso no es lo que dije."

# game/script.rpy:4545
translate es cake_choice_ce583014:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0249.ogg"
    # t "... You're starting to worry me."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0249.ogg"
    t "... Me estás empezando a preocupar."

# game/script.rpy:4551
translate es cake_choice_545c319c:

    # p "What exactly did you think about what happened with the flower arrangements?"
    p "¿Qué piensas exactamente sobre lo que pasó con los arreglos florales?"

# game/script.rpy:4553
translate es cake_choice_2243cdb9:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0250.ogg"
    # t "I got to see some beautiful ghost flowers, I suppose... But Elias might not buy your story anymore."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0250.ogg"
    t "Supongo que pude ver algunas flores fantasma hermosas... Pero Elias podría no creer más tu historia."

# game/script.rpy:4557
translate es cake_choice_d788fb31:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0251.ogg"
    # t "That may be a good thing."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0251.ogg"
    t "Eso podría ser algo bueno."

# game/script.rpy:4561
translate es cake_choice_1a7ad5a5:

    # p "How would it be a good thing?"
    p "¿Cómo sería algo bueno?"

# game/script.rpy:4563
translate es cake_choice_3bfa93f6:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0252.ogg"
    # t "Easy. Marrying an actual, literal ghost has {i}got{/i} to be hazardous to your health."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0252.ogg"
    t "Fácil. Casarse con un fantasma real y literal {i}tiene{/i} que ser perjudicial para tu salud."

# game/script.rpy:4567
translate es cake_choice_d1dbca0c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0253.ogg"
    # t "Maybe you can keep it up for a while, but eventually your facade will slip."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0253.ogg"
    t "Tal vez puedas mantener la fachada un tiempo, pero eventualmente se te caerá."

# game/script.rpy:4571
translate es cake_choice_99d40ee6:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0254.ogg"
    # t "And then what? The longer you wait, the bigger the heartbreak. He... He's been waiting so long."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0254.ogg"
    t "¿Y luego qué? Mientras más esperes, mayor será el desamor. Él... Ha estado esperando tanto tiempo."

# game/script.rpy:4575
translate es cake_choice_e8d17ed9:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0255.ogg"
    # t "The best you'll get is a sad marriage where neither of you actually like each other, but if you bring it up you just end up losing what you have."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0255.ogg"
    t "Lo mejor que obtendrás es un matrimonio triste donde ninguno de los dos realmente se guste, pero si lo mencionas, solo terminarás perdiendo lo que tienes."

# game/script.rpy:4579
translate es cake_choice_73506727:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0256.ogg"
    # t "And at worst he makes sure you can never leave."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0256.ogg"
    t "Y en el peor de los casos, se asegurará de que nunca puedas irte."

# game/script.rpy:4583
translate es cake_choice_676fb7a0:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0257.ogg"
    # t "I don't want you to be stuck in that mansion, bud. Even if we get nothin' from it."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0257.ogg"
    t "No quiero que te quedes atrapado en esa mansión, amigo. Aunque no saquemos nada de ello."

# game/script.rpy:4587
translate es cake_choice_e262aada:

    # p "I don't think we'll get nothing out of it!"
    p "¡No creo que no saquemos nada de ello!"

# game/script.rpy:4589
translate es cake_choice_3a29ef38:

    # p "But what really worries me is Violet. I don't know\nwhat's going on with her... I don't know why she's here. But I want to get away from her if I can."
    p "Pero lo que realmente me preocupa es Violet. No sé\nqué le pasa... No sé por qué está aquí. Pero quiero alejarme de ella si puedo."

# game/script.rpy:4591
translate es cake_choice_0a840ce3:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0258.ogg"
    # t "Can you make it so she doesn't appear? Any rituals or anything?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0258.ogg"
    t "¿Puedes hacer que no aparezca? ¿Algún ritual o algo así?"

# game/script.rpy:4595
translate es cake_choice_b222fe61:

    # p "I think it's up to Elias, not me. It could be that she's part of his memories."
    p "Creo que depende de Elias, no de mí. Podría ser que ella forme parte de sus recuerdos."

# game/script.rpy:4597
translate es cake_choice_1bb06bac:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0259.ogg"
    # t "Ugh, I'm really starting to not like that guy..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0259.ogg"
    t "Uf, realmente estoy empezando a no gustarme ese tipo..."

# game/script.rpy:4601
translate es cake_choice_3509f878:

    # p "Then there's what happened just now."
    p "Luego está lo que pasó hace un momento."

# game/script.rpy:4605
translate es cake_choice_4247ff79:

    # p "That vision I had while looking at Archibald's ledger was really intense. God, I felt so frustrated and he wasn't even talking to me!"
    p "Esa visión que tuve mientras miraba el registro de Archibald fue realmente intensa. ¡Dios, me sentí tan frustrad@ y él ni siquiera me estaba hablando!"

# game/script.rpy:4607
translate es cake_choice_185fc18c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0267.ogg"
    # t "I still haven't found anything online about whatever mirror Elias was talking about. Did he mention how big it was? Like are we talkin' a hand mirror or a standing mirror?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0267.ogg"
    t "Todavía no he encontrado nada en línea sobre el espejo del que hablaba Elias. ¿Mencionó qué tan grande era? ¿Estamos hablando de un espejo de mano o de pie?"

# game/script.rpy:4611
translate es cake_choice_4aed412c:

    # p "I don't think he brought it up... All he said was that it belonged to his grandmother."
    p "No creo que lo haya mencionado... Todo lo que dijo fue que pertenecía a su abuela."

# game/script.rpy:4613
translate es cake_choice_bb9cf659:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0268.ogg"
    # t "Do you think it's a red herring? Though... breaking a mirror is pretty bad luck..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0268.ogg"
    t "¿Crees que es una pista falsa? Aunque... romper un espejo trae mala suerte..."

# game/script.rpy:4617
translate es cake_choice_1173e953:

    # p "Are you thinking what I'm thinking?"
    p "¿Estás pensando lo mismo que yo?"

# game/script.rpy:4619
translate es cake_choice_e66a7ace:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0269.ogg"
    # t "Maybe it's the source of the curse..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0269.ogg"
    t "Tal vez sea la fuente de la maldición..."

# game/script.rpy:4623
translate es cake_choice_18b32418:

    # p "And if Elias still has the pieces of that mirror, we can get to the bottom of this whole ordeal."
    p "Y si Elias todavía tiene los pedazos de ese espejo, podemos llegar al fondo de todo este asunto."

# game/script.rpy:4625
translate es cake_choice_d50b6f8b:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0270.ogg"
    # t "That would definitely be something we can boast about... Solving a centuries-old curse. I'm just not sure you should tackle that tonight."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0270.ogg"
    t "Eso definitivamente sería algo de lo que podríamos presumir... Resolver una maldición de siglos. Solo que no estoy seguro de que debas enfrentarlo esta noche."

# game/script.rpy:4631
translate es cake_choice_837ebcf7:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0271.ogg"
    # t "I still can't believe you managed to find his smut collection."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0271.ogg"
    t "Todavía no puedo creer que hayas logrado encontrar su colección de material sexual."

# game/script.rpy:4635
translate es cake_choice_d654ac33:

    # p "I didn't mean to, I swear! I just picked up a book at random!"
    p "¡No fue mi intención, lo juro! ¡Solo tomé un libro al azar!"

# game/script.rpy:4637
translate es cake_choice_0ed0f408:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0272.ogg"
    # t "I would have loved to see the look on his face... Hah! Though, you really didn't have to ask him his favorite sex position afterwards."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0272.ogg"
    t "Me hubiera encantado ver la expresión en su rostro... ¡Ja! Aunque realmente no tenías que preguntarle su posición sexual favorita después."

# game/script.rpy:4641
translate es cake_choice_2f2151c4:

    # p "It was already awkward, so I kinda just wanted to see what would happen, y'know?"
    p "Ya era incómodo, así que más o menos solo quería ver qué pasaría, ¿sabes?"

# game/script.rpy:4643
translate es cake_choice_b1fd962c:

    # "I end up laughing a bit too, despite myself."
    "Termino riéndome un poco también, a pesar de mí mism@."

# game/script.rpy:4645
translate es cake_choice_f09695d6:

    # p "Anyways, I wonder why he had a box full of mirror shards. It just seemed... so out of place in his room."
    p "De todos modos, me pregunto por qué tenía una caja llena de fragmentos de espejo. Simplemente parecía... tan fuera de lugar en su habitación."

# game/script.rpy:4647
translate es cake_choice_43cb49d1:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0273.ogg"
    # t "I couldn't tell you anything about it. Maybe the dude's just a weirdo?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0273.ogg"
    t "No podría decirte nada al respecto. ¿Tal vez el tipo solo es raro?"

# game/script.rpy:4651
translate es cake_choice_ee058d86:

    # p "Hm... I don't {i}think{/i} he's like that..."
    p "Hm... No {i}creo{/i} que sea así..."

# game/script.rpy:4653
translate es cake_choice_e5fa4e51:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0274.ogg"
    # t "... [your_name], are you seriously starting to feel something for Elias? Because I'm starting to think he's casting some kind of magic on you to make you feel connected to him."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0274.ogg"
    t "... [your_name], ¿realmente estás empezando a sentir algo por Elias? Porque empiezo a pensar que está lanzándote algún tipo de magia para que te sientas conectad@ a él."

# game/script.rpy:4659
translate es cake_choice_29c47d9b:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0264.ogg"
    # t "When Elias touched you again?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0264.ogg"
    t "¿Cuando Elias te tocó de nuevo?"

# game/script.rpy:4663
translate es cake_choice_e1fd8b93:

    # p "Yeah, part of my outfit got caught by the chair and I nearly tripped, but he caught me just in time."
    p "Sí, parte de mi atuendo se enganchó con la silla y casi tropiezo, pero me atrapó justo a tiempo."

# game/script.rpy:4665
translate es cake_choice_bc2fd9b7:

    # p "I had another vision. This time I saw his family mocking him. I couldn't really make out what they were all saying, but it definitely wasn't praise."
    p "Tuve otra visión. Esta vez vi a su familia burlándose de él. No pude distinguir realmente lo que decían, pero definitivamente no era elogio."

# game/script.rpy:4667
translate es cake_choice_79e8714e:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0265.ogg"
    # t "What concerns me more is that he mentioned seeing {i}me{/i}. Was he reading your mind? It almost sounded like you two were exchanging memories."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0265.ogg"
    t "Lo que más me preocupa es que mencionó ver {i}mi{/i}. ¿Estaba leyendo tu mente? Casi parecía que ustedes dos estaban intercambiando recuerdos."

# game/script.rpy:4671
translate es cake_choice_7b30694e:

    # p "I have no idea. I'm able to hold his hand without triggering any memories sometimes, but we were both stressed out at the time, so..."
    p "No tengo idea. Puedo tomar su mano sin activar recuerdos a veces, pero ambos estábamos estresad@s en ese momento, así que..."

# game/script.rpy:4673
translate es cake_choice_e448a65c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0266.ogg"
    # t "I don't like that he's capable of reading your memories, even if this time wasn't intentional. What happens if he finds out that you're faking all of this?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0266.ogg"
    t "No me gusta que pueda leer tus recuerdos, incluso si esta vez no fue intencional. ¿Qué pasaría si descubre que estás fingiendo todo esto?"

# game/script.rpy:4677
translate es cake_choice_99480782:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0275.ogg"
    # t "Honestly, and I mean it this time, I want you to leave this place."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0275.ogg"
    t "Honestamente, y lo digo en serio esta vez, quiero que dejes este lugar."

# game/script.rpy:4681
translate es cake_choice_6b17030f:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0276.ogg"
    # t "There's something very wrong going on. Nothing we read said anything like this would happen!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0276.ogg"
    t "Hay algo muy mal ocurriendo. ¡Nada de lo que leímos decía que algo así pasaría!"

# game/script.rpy:4685
translate es cake_choice_1e348239:

    # p "Taylor, calm down. I know this isn't what we expected...\nBut what {i}were{/i} we expecting, exactly? Be honest, did you think this would actually pan out?"
    p "Taylor, cálmate. Sé que esto no es lo que esperábamos...\nPero, ¿qué {i}esperábamos{/i} exactamente? Sé honest@, ¿pensaste que esto realmente resultaría?"

# game/script.rpy:4687
translate es cake_choice_db2b2653:

    # p "Three years of failure. And now we're finally here! We finally got what we wanted."
    p "Tres años de fracasos. ¡Y ahora finalmente estamos aquí! Finalmente conseguimos lo que queríamos."

# game/script.rpy:4689
translate es cake_choice_39262e85:

    # p "And we've planned so much... Hell, {i}fantasized{/i} so much about what we'd do when we finally met a restless spirit."
    p "Y hemos planeado tanto... Diablos, {i}fantaseamos{/i} tanto sobre lo que haríamos cuando finalmente nos encontráramos con un espíritu inquieto."

# game/script.rpy:4691
translate es cake_choice_a8d86008:

    # p "We'd try our best to soothe them, to help them move on, to bring them the happiness they've lost... To finish their unfinished business."
    p "Intentaríamos hacer nuestro mejor esfuerzo para calmarlos, ayudarlos a seguir adelante, traerles la felicidad que han perdido... Para finalizar sus asuntos pendientes."

# game/script.rpy:4693
translate es cake_choice_6c3244b7:

    # p "Now that we have the opportunity, shouldn't we do what we said we'd do all along?"
    p "Ahora que tenemos la oportunidad, ¿no deberíamos hacer lo que dijimos que haríamos desde el principio?"

# game/script.rpy:4695
translate es cake_choice_3c0f6cb4:

    # p "Maybe we can help him move on."
    p "Tal vez podamos ayudarle a seguir adelante."

# game/script.rpy:4697
translate es cake_choice_513e841a:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0277.ogg"
    # t "... Please, we don't know what kind of tricks he has up his sleeve. I don't want you to fall for anything he might be up to."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0277.ogg"
    t "... Por favor, no sabemos qué tipo de trucos tiene bajo la manga. No quiero que caigas en algo que pueda estar planeando."

# game/script.rpy:4701
translate es cake_choice_ef174da3:

    # p "I won't. I promise."
    p "No lo haré. Lo prometo."

# game/script.rpy:4703
translate es cake_choice_8af630a0:

    # "Am I even sure Elias is up to anything beyond trying to wed me?"
    "¿Estoy segur@ de que Elias está haciendo algo más allá de intentar casarse conmigo?"

# game/script.rpy:4705
translate es cake_choice_1debadec:

    # "And will breaking Elias' heart any further really be better than going through with all this?"
    "¿Y será realmente mejor romperle más el corazón a Elias que seguir con todo esto?"

# game/script.rpy:4707
translate es cake_choice_93432763:

    # p "The next thing to do is to pick out some jewelry, and then we're ready to go."
    p "Lo siguiente es escoger algunas joyas, y luego estaremos list@s para irnos."

# game/script.rpy:4709
translate es cake_choice_39f45b4c:

    # p "The wedding will probably be at dawn, maybe just before. I don't know for sure. Do you want me to sta—"
    p "La boda probablemente será al amanecer, quizá justo antes. No lo sé con certeza. ¿Quieres que yo empie—"

# game/script.rpy:4713
translate es cake_choice_b50a52a6:

    # "A little beep echoes in my ear."
    "Un pequeño pitido resuena en mi oído."

# game/script.rpy:4715
translate es cake_choice_27827404:

    # p "Uh."
    p "Eh."

# game/script.rpy:4717
translate es cake_choice_1a76bf8c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0278.ogg"
    # t "[your_name]?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0278.ogg"
    t "[your_name]?"

# game/script.rpy:4721
translate es cake_choice_16ba3f5b:

    # "I check my phone, and that beep means exactly what I think it means... My phone battery is almost dead."
    "Reviso mi teléfono, y ese pitido significa exactamente lo que creo... La batería de mi teléfono está casi muerta."

# game/script.rpy:4725
translate es cake_choice_1b4b4f7b:

    # p "Crap, my phone's dying."
    p "Mierda, mi teléfono se está muriendo."

# game/script.rpy:4729
translate es cake_choice_3a448231:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0279.ogg"
    # t "WHAT??"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0279.ogg"
    t "¿QUÉ??"

# game/script.rpy:4733
translate es cake_choice_b07e96e4:

    # p "Out of juice!"
    p "¡Sin batería!"

# game/script.rpy:4735
translate es cake_choice_c6460e52:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0280.ogg"
    # t "You didn't bring a portable charger?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0280.ogg"
    t "¿No trajiste un cargador portátil?"

# game/script.rpy:4739
translate es cake_choice_8a1364ee:

    # p "Why would I!? Honestly, I didn't think I'd be here that long. And I didn't have much time to plan."
    p "¿Por qué lo haría? Honestamente, no pensé que estaría aquí tanto tiempo. Y no tuve mucho tiempo para planear."

# game/script.rpy:4741
translate es cake_choice_6276d681:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0281.ogg"
    # t "I'm comin' in."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0281.ogg"
    t "Voy para allá."

# game/script.rpy:4745
translate es cake_choice_899f2020:

    # p "What? Wait, you—"
    p "¿Qué? Espera, tú—"

# game/script.rpy:4747
translate es cake_choice_f6ed29e0:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0282.ogg"
    # t "I'm not leaving you there alone in there with no contact! I'm responsible for that much!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0282.ogg"
    t "¡No te voy a dejar ahí sol@ sin contacto! ¡Soy responsable de eso!"

# game/script.rpy:4751
translate es cake_choice_771e46fe:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0283.ogg"
    # t "Stall for time, [your_name]. I'll see ya soon. Over and out."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0283.ogg"
    t "Gana tiempo, [your_name]. Te veré pronto. Cambio y fuera."

# game/script.rpy:4757
translate es cake_choice_b3e0fdab:

    # "The line goes dead."
    "La línea se corta."

# game/script.rpy:4759
translate es cake_choice_609fa6de:

    # "The pounding of my heart intensifies like a symphony reaching a crescendo."
    "El latido de mi corazón se intensifica como una sinfonía alcanzando un crescendo."

# game/script.rpy:4761
translate es cake_choice_ae6ef405:

    # "... And like an aria bursting from the melody, a voice triumphantly calls out to me."
    "... Y como un aria que estalla de la melodía, una voz me llama triunfante."

# game/script.rpy:4763
translate es cake_choice_8ce4fc5b:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0174.ogg"
    # e "My dear, can you come to the living room?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0174.ogg"
    e "Cariño, ¿puedes venir a la sala?"

# game/script.rpy:4767
translate es cake_choice_bd54988a:

    # "I have no choice but to oblige."
    "No tengo más opción que obedecer."

# game/script.rpy:4773
translate es cake_choice_0c1f125b:

    # "As I step through the corridors, each creak of my footfalls is as thunderous as a waterfall."
    "Mientras avanzo por los pasillos, cada crujido de mis pasos es tan atronador como una cascada."

# game/script.rpy:4777
translate es cake_choice_0fc4cbd2:

    # "My phone vibrates one last time... A final warning before embracing its inevitable death."
    "Mi teléfono vibra una última vez... Una advertencia final antes de abrazar su inevitable muerte."

# game/script.rpy:4779
translate es cake_choice_a43a17f9:

    # "I arrive at the door and enter the living room... where Elias awaits."
    "Llego a la puerta y entro en la sala... donde Elias espera."

# game/script.rpy:4785
translate es cake_choice_45e7127c:

    # "At this point, there's no hiding my stress. I'm not that good of an actor, and Elias would see right through me."
    "En este punto, no puedo ocultar mi estrés. No soy tan buen@ actuando, y Elias lo notaría enseguida."

# game/script.rpy:4791
translate es cake_choice_0d299377:

    # "Still, I do my best to compose myself, and step into the living room. Elias is waiting for me, just as he said he would be."
    "Aun así, hago mi mejor esfuerzo por recomponerme y entro en la sala. Elias me espera, tal como dijo que lo haría."

# game/script.rpy:4795
translate es cake_choice_41e0ba1a:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0175.ogg"
    # e comical_surprised ugh concerned "Oh! My dear, you look paler than me!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0175.ogg"
    e comical_surprised ugh concerned "¡Oh! Cariño, ¡te ves más palid@ que yo!"

# game/script.rpy:4799
translate es cake_choice_d222cc98:

    # p "Yeah... I probably do."
    p "Sí... probablemente sí."

# game/script.rpy:4801
translate es cake_choice_02aee5b7:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0176.ogg"
    # e forward_lidded_regular frown_disapprove angry "What on earth happened!?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0176.ogg"
    e forward_lidded_regular frown_disapprove angry "¿Qué demonios pasó!?"

# game/script.rpy:4805
translate es cake_choice_5991d94f:

    # p "I... I lost contact with someone very important. Just now."
    p "Yo... Perdí contacto con alguien muy importante. Justo ahora."

# game/script.rpy:4809
translate es cake_choice_5c280b5f:

    # p "Have you ever been contacted by a spirit medium? That's something like what I've been doing, but that contact has been cut short..."
    p "¿Alguna vez has sido contactado por un médium? Eso es algo parecido a lo que he estado haciendo, pero ese contacto se interrumpió..."

# game/script.rpy:4811
translate es cake_choice_0826dc71:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0177.ogg"
    # e forward_lidded_smaller oh_sad angry "You've been talking with someone else?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0177.ogg"
    e forward_lidded_smaller oh_sad angry "¿Has estado hablando con alguien más?"

# game/script.rpy:4815
translate es cake_choice_567721bd:

    # p "I have. ... For my own safety. When I came to this manor today, I didn't know what to expect!"
    p "Sí... Por mi propia seguridad. Cuando llegué a esta mansión hoy, ¡no sabía qué esperar!"

# game/script.rpy:4817
translate es cake_choice_3303a26b:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0178.ogg"
    # e forward_lidded_regular oh_sad sad "I thought you expected me."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0178.ogg"
    e forward_lidded_regular oh_sad sad "Pensé que me esperabas."

# game/script.rpy:4821
translate es cake_choice_bc3486fd:

    # p "I {i}hoped{/i} for you, Elias. But until I came here, how could I know what was true?"
    p "{i}Esperaba{/i} por ti, Elias. Pero hasta que llegué aquí, ¿cómo podría saber qué era verdad?"

# game/script.rpy:4825
translate es cake_choice_afdc3cd9:

    # p "Perhaps I'd arrive to an empty estate moments from collapse without anyone to greet me. Just another false rumor about a haunted mansion."
    p "Tal vez llegaría a una mansión vacía a punto de derrumbarse sin nadie que me recibiera. Solo otro rumor falso sobre una mansión embrujada."

# game/script.rpy:4827
translate es cake_choice_9030400f:

    # p "Or maybe you wouldn't be as friendly and courteous as all the whispers implied. Maybe you wouldn't be the one lingering in this mansion at all."
    p "O tal vez no serías tan amigable y cortés como implicaban todos los rumores. Tal vez no serías tú quien rondara por esta mansión en absoluto."

# game/script.rpy:4829
translate es cake_choice_035bdedc:

    # p "... Or so many other possibilities."
    p "... O tantas otras posibilidades."

# game/script.rpy:4833
translate es cake_choice_2680ab66:

    # p "How many ghosts have you met in your lifetime, Elias?"
    p "¿Cuántos fantasmas has conocido en tu vida, Elias?"

# game/script.rpy:4835
translate es cake_choice_9b923eb2:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0179.ogg"
    # e up_regular neutral ah_sad "A fair question! Well, I have faint memories of catching specters out of the corner of my eye..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0179.ogg"
    e up_regular neutral ah_sad "¡Una buena pregunta! Bueno, tengo vagos recuerdos de atrapar espectros desde el rabillo del ojo..."

# game/script.rpy:4839
translate es cake_choice_6127e8cd:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0180.ogg"
    # e up_left pucker "Unexplained disturbances and whatnot, but I have not conferred with any ghosts like the two of us have chatted. Certainly not in life."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0180.ogg"
    e up_left pucker "Perturbaciones inexplicables y cosas por el estilo, pero no he conversado con ningún fantasma como lo hemos hecho nosotros. Ciertamente, no en vida."

# game/script.rpy:4843
translate es cake_choice_3a88aca4:

    # p "Exactly. So you understand my mortal caution."
    p "Exactamente. Así que entiendes mi cautela mortal."

# game/script.rpy:4847
translate es cake_choice_8a5438ff:

    # "Elias pouts."
    "Elias hace un puchero."

# game/script.rpy:4849
translate es cake_choice_46756ff2:

    # p "My friend, my... medium, was the one guiding me through this manor safely."
    p "Mi amigo, mi... médium, fue quien me guió por esta mansión de manera segura."

# game/script.rpy:4851
translate es cake_choice_215061ff:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0181.ogg"
    # e closed_sad oh_annoyed concerned "And... did you just meet this friend today, or—"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0181.ogg"
    e closed_sad oh_annoyed concerned "Y... ¿conociste a este amigo hoy, o..."

# game/script.rpy:4855
translate es cake_choice_5a36c45e:

    # p "— I've known him for a long time. He was the one who told me about this manor in the first place."
    p "— Lo conozco desde hace mucho tiempo. Fue él quien me habló de esta mansión en primer lugar."

# game/script.rpy:4859
translate es cake_choice_d6c0743f:

    # p "Listen, Elias... I've met {i}zero{/i} ghosts until you. But not for lack of trying."
    p "Escucha, Elias... Hasta conocerte, no había visto {i}cero{/i} fantasmas. Pero no por falta de intentos."

# game/script.rpy:4863
translate es cake_choice_27dbe098:

    # p "Both myself and Taylor — that's uh, my friend — have spent the better part of the past three years searching for the paranormal."
    p "Tanto Taylor —que es, eh, mi amigo— como yo hemos pasado la mayor parte de los últimos tres años buscando lo paranormal."

# game/script.rpy:4865
translate es cake_choice_fa6a781a:

    # p "And that's what led me to you. I don't know if I would be here if I hadn't spent that time looking for so long."
    p "Y eso fue lo que me llevó hasta ti. No sé si estaría aquí si no hubiera pasado tanto tiempo buscando."

# game/script.rpy:4872
translate es cake_choice_a20cefa7:

    # "..."
    "..."

# game/script.rpy:4874
translate es cake_choice_b2808510:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0182.ogg"
    # e closed_happy grin_teeth blush "Marvelous. My dear, how wonderful it is that you finally found me!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0182.ogg"
    e closed_happy grin_teeth blush "¡Maravilloso! ¡Cariño, qué maravilloso es que finalmente me hayas encontrado!"

# game/script.rpy:4878
translate es cake_choice_88693dcb:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0183.ogg"
    # e forward_lidded_regular squiggle sad -blush "Though, would you have sought the hand of any other ghosts you may have met?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0183.ogg"
    e forward_lidded_regular squiggle sad -blush "Aunque, ¿habrías buscado la compañía de cualquier otro fantasma que pudieras haber conocido?"

# game/script.rpy:4882
translate es cake_choice_df7cf18c:

    # "A guilty sigh emanates from my lips, permeating the air."
    "Un suspiro culpable emana de mis labios, permeando el aire."

# game/script.rpy:4884
translate es cake_choice_5b20800c:

    # p "If they were willing to court me, I wouldn't automatically say no..."
    p "Si estuvieran dispuestos a cortejarme, no diría automáticamente que no..."

# game/script.rpy:4886
translate es cake_choice_75126f87:

    # p "But I imagine — based on what I've read — that none of the ghosts I otherwise might have run into around here would be interested in such things..."
    p "Pero imagino —basándome en lo que he leído— que ninguno de los fantasmas con los que podría toparme por aquí estaría interesado en tales cosas..."

# game/script.rpy:4888
translate es cake_choice_19ef7d54:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0184.ogg"
    # e left_regular neutral ah_sad "And as for your friend... How exactly has he served as a medium?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0184.ogg"
    e left_regular neutral ah_sad "Y en cuanto a tu amigo... ¿Exactamente cómo ha servido como médium?"

# game/script.rpy:4894
translate es cake_choice_d3d5216c:

    # p "Well, um, this earpiece is my method of communicating discreetly."
    p "Bueno, eh, este auricular es mi método para comunicarme discretamente."

# game/script.rpy:4896
translate es cake_choice_b6a2e576:

    # "I take the bit of plastic out of my ear and hold it out for Elias to observe. Whether he has any knowledge of such modern things or not, I have no clue."
    "Saco el pedazo de plástico de mi oído y lo sostengo para que Elias lo observe. Si sabe algo de estas cosas modernas o no, no tengo ni idea."

# game/script.rpy:4900
translate es cake_choice_2f53e8bb:

    # p "But sadly, it's stopped working and needs to be charged. I don't think you're able to help here, either."
    p "Pero lamentablemente, ha dejado de funcionar y necesita cargarse. Tampoco creo que puedas ayudar aquí."

# game/script.rpy:4902
translate es cake_choice_308d4df2:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0185.ogg"
    # e closed_sad tch concerned "So, to contact him again..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0185.ogg"
    e closed_sad tch concerned "Entonces, para contactarlo de nuevo..."

# game/script.rpy:4906
translate es cake_choice_7397ba5c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0186.ogg"
    # e angry forward_lidded_small frown_disapprove "You'd have to leave?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0186.ogg"
    e angry forward_lidded_small frown_disapprove "¿Tendrías que irte?"

# game/script.rpy:4910
translate es cake_choice_7ef16e52:

    # p "... Actually, he's coming here. Now that the link between us is broken, he's not going to let me out of his sight..."
    p "... En realidad, él viene aquí. Ahora que el vínculo entre nosotros está roto, no me dejará salir de su vista..."

# game/script.rpy:4912
translate es cake_choice_4978fe7f:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0187.ogg"
    # e forward_small blush oh_annoyed happy "Oh, is that so? I..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0187.ogg"
    e forward_small blush oh_annoyed happy "¿Oh, es así? Yo..."

# game/script.rpy:4916
translate es cake_choice_7fdce548:

    # "Is Elias... blushing?"
    "¿Elias... se está sonrojando?"

# game/script.rpy:4918
translate es cake_choice_3d06f406:

    # "He's not suddenly getting jealous of Taylor, is he?"
    "¿No estará poniéndose celoso de Taylor, verdad?"

# game/script.rpy:4920
translate es cake_choice_fb12714c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0188.ogg"
    # e up_regular pucker "Well. He's heard about the wedding, yes? {i}Our{/i} wedding?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0188.ogg"
    e up_regular pucker "Bueno. Ha oído hablar de la boda, ¿verdad? ¿{i}Nuestra{/i} boda?"

# game/script.rpy:4924
translate es cake_choice_3b88c420:

    # p "Yes."
    p "Sí."

# game/script.rpy:4926
translate es cake_choice_fa2bbf5c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0189.ogg"
    # e forward_regular neutral "Well, I suppose a wedding without guests isn't much of a wedding."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0189.ogg"
    e forward_regular neutral "Bueno, supongo que una boda sin invitados no es mucha boda."

# game/script.rpy:4930
translate es cake_choice_eda11c42:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0190.ogg"
    # e grin_straight happy closed_happy "Everything is just about in order for the ceremony, anyway! And I hope your friend realizes how safe you are with me by now."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0190.ogg"
    e grin_straight happy closed_happy "¡De todos modos, todo está casi listo para la ceremonia! Y espero que tu amigo ya se dé cuenta de lo segura que estás conmigo."

# game/script.rpy:4934
translate es cake_choice_1b6e253e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0191.ogg"
    # e forward_regular grin_teeth "He can wait outside for a little while we finish our preparations."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0191.ogg"
    e forward_regular grin_teeth "Puede esperar afuera un poco mientras terminamos nuestros preparativos."

# game/script.rpy:4938
translate es cake_choice_26418c26:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0192.ogg"
    # e forward_heart grin_tilted "Shall we go ahead and place the final touches on this affair?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0192.ogg"
    e forward_heart grin_tilted "¿Procedemos a dar los toques finales a este asunto?"

# game/script.rpy:4942
translate es cake_choice_c4116b20:

    # p "... We shall, dear."
    p "... Sí, querido."

# game/script.rpy:4946
translate es cake_choice_e33b5edd:

    # "He offers me his arm, and I take it. I have no fucking idea what's about to happen."
    "Me ofrece su brazo, y lo tomo. No tengo ni idea de lo que va a suceder."

# game/script.rpy:4948
translate es cake_choice_27f989b1:

    # "Can Taylor even get inside? Will he spill the beans about my facade?"
    "¿Podrá Taylor siquiera entrar? ¿Revelará mi fachada?"

# game/script.rpy:4952
translate es cake_choice_1b18b878:

    # "Will I be able to escape before I marry a ghost?"
    "¿Podré escapar antes de casarme con un fantasma?"

# game/script.rpy:4954
translate es cake_choice_4a775de4:

    # "... Do I {i}want{/i} to escape?"
    "... ¿{i}Quiero{/i} escapar?"

# game/script.rpy:4956
translate es cake_choice_d933e406:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0193.ogg"
    # e forward_heart grin_teeth "Now then... shall we? It is time to show you my precious family jewels!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0193.ogg"
    e forward_heart grin_teeth "Ahora entonces... ¿procedemos? ¡Es hora de mostrarte mis preciadas joyas familiares!"

# game/script.rpy:4965
translate es cake_choice_b3bfca22:

    # "Elias and I make our way up the staircase as I softly grip his ethereal arm. I watch as his free hand grips the dark mahogany railing."
    "Elias y yo subimos la escalera mientras agarro suavemente su brazo etéreo. Observo cómo su mano libre se aferra a la barandilla de caoba oscura."

# game/script.rpy:4969
translate es cake_choice_d9e7c4af:

    # "The stairs creak, a little too loud. Leaning closer to Elias, my hold on him tightens."
    "Las escaleras crujen, un poco demasiado fuerte. Acercándome a Elias, aprieto mi agarre sobre él."

# game/script.rpy:4971
translate es cake_choice_5e17d406:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0194.ogg"
    # e "Do not fret, my dear. These stairs are safe as long as you stay by my side."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0194.ogg"
    e "No te preocupes, cariño. Estas escaleras son seguras mientras estés a mi lado."

# game/script.rpy:4975
translate es cake_choice_6f5080c0:

    # "I give him an uncertain smile, trying not to remember the state of the decrepit stairs when I first entered the mansion. They now look elegant, lined with soft, gold-trimmed carpeting."
    "Le doy una sonrisa incierta, tratando de no recordar el estado de las escaleras deterioradas cuando entré por primera vez en la mansión. Ahora lucen elegantes, con alfombra suave y ribete dorado."

# game/script.rpy:4983
translate es cake_choice_5f66040e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0195.ogg"
    # e "Careful, now."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0195.ogg"
    e "Con cuidado, ahora."

# game/script.rpy:4987
translate es cake_choice_bd2ccb67:

    # " Elias places his hand atop mine as we walk down the hallway. He wears a faint, complacent smile. "
    "Elias coloca su mano sobre la mía mientras caminamos por el pasillo. Lleva una leve sonrisa complacida."

# game/script.rpy:4989
translate es cake_choice_06874eb5:

    # p "... Is it tiring?"
    p "... ¿Es cansador?"

# game/script.rpy:4991
translate es cake_choice_ade590bb:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0196.ogg"
    # e forward_regular happy -blush oh_annoyed "Hmm?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0196.ogg"
    e forward_regular happy -blush oh_annoyed "¿Hmm?"

# game/script.rpy:4995
translate es cake_choice_17fead2e:

    # p "Making the mansion..."
    p "Haciendo la mansión..."

# game/script.rpy:4997
translate es cake_choice_e1d14426:

    # "I pause, not sure how I should phrase the question. Not all of it is exactly hospitable. "
    "Hago una pausa, sin saber cómo formular la pregunta. No toda es exactamente acogedora."

# game/script.rpy:4999
translate es cake_choice_3d6850d4:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0197.ogg"
    # e forward_heart smug neutral "You mean, making it look like a ghost of its former glory?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0197.ogg"
    e forward_heart smug neutral "¿Te refieres a hacer que luzca como un fantasma de su antigua gloria?"

# game/script.rpy:5003
translate es cake_choice_38662044:

    # "He chuckles at his little pun. With a gentle pat of my hand, he sighs."
    "Se ríe de su pequeño juego de palabras. Con una suave palmada en mi mano, suspira."

# game/script.rpy:5005
translate es cake_choice_b6ae5f01:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0198.ogg"
    # e closed_sad normal sad "Admittedly, yes. It's quite tiring. But if it makes you comfortable, then I shall keep doing it. It also brings back... many memories."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0198.ogg"
    e closed_sad normal sad "Admito que sí. Es bastante cansador. Pero si te hace sentir cómoda, entonces seguiré haciéndolo. También trae... muchos recuerdos."

# game/script.rpy:5011
translate es cake_choice_f4a0f3e8:

    # "The smile on his face drifts into wistfulness. For a moment, he looks almost sad. I regret bringing it up. My grip on his arm loosens, and I give him a smile back."
    "La sonrisa en su rostro se torna melancólica. Por un momento, parece casi triste. Lamento haberlo mencionado. Suelto su brazo y le devuelvo la sonrisa."

# game/script.rpy:5013
translate es cake_choice_bc452fff:

    # p "I think you've done an excellent job, Elias. With everything."
    p "Creo que has hecho un trabajo excelente, Elias. Con todo."

# game/script.rpy:5015
translate es cake_choice_c6f8528e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0198-5.ogg"
    # e forward_heart ah_sad neutral "I appreciate your kind words, my dear."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0198-5.ogg"
    e forward_heart ah_sad neutral "Aprecio tus amables palabras, cariño."

# game/script.rpy:5025
translate es cake_choice_7fcf0687:

    # "We're back at his bedroom."
    "Estamos de vuelta en su habitación."

# game/script.rpy:5029
translate es cake_choice_1c4a4c2f:

    # "He leads me to a door, then opens it. Inside is a bedroom similar to the one I awoke in; elegant and ornate, if not a bit barren."
    "Me guía hasta una puerta, luego la abre. Dentro hay un dormitorio similar al que desperté; elegante y ornamentado, aunque un poco vacío."

# game/script.rpy:5031
translate es cake_choice_39409689:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0199.ogg"
    # e @ closed_sad ah_sad "Just a moment, my dear."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0199.ogg"
    e @ closed_sad ah_sad "Un momento, cariño."

# game/script.rpy:5035
translate es cake_choice_2c3e7f9c:

    # "He lets go of my arm, making his way to the vanity. Instead of reaching for one of the drawers, he presses his hand against the wall, causing the vanity to lower and reveal a hidden compartment."
    "Suelta mi brazo y se dirige al tocador. En lugar de abrir un cajón, presiona su mano contra la pared, haciendo que el tocador baje y revele un compartimento oculto."

# game/script.rpy:5041
translate es cake_choice_5fdd05a5:

    # "I knew this mansion had at least one secret passage!"
    "¡Sabía que esta mansión tenía al menos un pasaje secreto!"

# game/script.rpy:5049
translate es cake_choice_72c5fb25:

    # "Huh, I wonder how many other secrets this place holds?"
    "Huh, me pregunto cuántos otros secretos guarda este lugar."

# game/script.rpy:5053
translate es cake_choice_d74f2dbc:

    # "Elias sifts through the drawers inside the compartment, eventually pulling out an unassuming dark wooden box. He slowly opens it, revealing a ring, necklace, and a pair of earrings. "
    "Elias rebusca en los cajones dentro del compartimento, sacando finalmente una caja de madera oscura y sencilla. La abre lentamente, revelando un anillo, un collar y un par de pendientes."

# game/script.rpy:5055
translate es cake_choice_6ab5f0d3:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0200.ogg"
    # e happy closed_happy grin_straight "Aah, here we are, then!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0200.ogg"
    e happy closed_happy grin_straight "¡Ah, aquí estamos, entonces!"

# game/script.rpy:5059
translate es cake_choice_d0101bbe:

    # "My eyes light up with wonder as the jewelry sparkles, even without any light shining on it."
    "Mis ojos se iluminan de asombro mientras las joyas brillan, incluso sin luz directa."

# game/script.rpy:5065
translate es cake_choice_edfac935:

    # "The ring is a gold band with a large diamond at the center, a beautiful classic for a reason. Just the sheer size of the diamond alone catches the eye."
    "El anillo es una banda de oro con un gran diamante en el centro, un clásico hermoso por una razón. Solo el tamaño del diamante llama la atención."

# game/script.rpy:5067
translate es cake_choice_69bc4fe2:

    # "Meanwhile the necklace is a string of pearls with a ruby amulet on it, and so very dazzling to gaze upon. It's like looking at the very definition of opulence."
    "Mientras tanto, el collar es un hilo de perlas con un amuleto de rubí, y es deslumbrante de mirar. Es como contemplar la misma definición de opulencia."

# game/script.rpy:5069
translate es cake_choice_864808f7:

    # "And lastly, the earrings are a drop pair with a Victorian\nLove Knot at the base with an opal centerpiece and a yellow-tinted green sapphire at the bottom."
    "Y finalmente, los pendientes son de tipo colgante con un Nudo de Amor\nVictoriano en la base, con un ópalo en el centro y un zafiro verde amarillento en la parte inferior."

# game/script.rpy:5071
translate es cake_choice_18858aa9:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0201.ogg"
    # e @ forward_heart grin_teeth "Do not hesitate, dear. Choose whichever your heart desires."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0201.ogg"
    e @ forward_heart grin_teeth "No dudes, cariño. Elige el que tu corazón desee."

# game/script.rpy:5075
translate es cake_choice_c01457f9:

    # p "They're all so gorgeous! I can't possibly choose."
    p "¡Son todos tan hermosos! No podría elegir."

# game/script.rpy:5079
translate es cake_choice_cd48ddc8:

    # "Nevertheless I reach out, gravitating towards the..."
    "Aun así, extiendo la mano, inclinándome hacia el..."

# game/script.rpy:5090
translate es cake_choice_6d5798e4:

    # "I pick up the ring, inspecting it closer. The name \"Gallagher\" is engraved in the inner band with fancy cursive lettering."
    "Tomo el anillo, inspeccionándolo más de cerca. El nombre  \"Gallagher \" está grabado en la banda interior con letra cursiva elegante."

# game/script.rpy:5092
translate es cake_choice_e5503422:

    # "Elias gently takes it from me and slips it over my finger. It slides on easily, without being too loose or too tight."
    "Elias lo toma suavemente de mí y me lo coloca en el dedo. Se desliza fácilmente, sin quedar demasiado flojo ni apretado."

# game/script.rpy:5094
translate es cake_choice_043e0f15:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0202.ogg"
    # e forward_heart @ lipbite_small "A perfect fit. Like it was made for you!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0202.ogg"
    e forward_heart @ lipbite_small "Un ajuste perfecto. ¡Como si hubiera sido hecho para ti!"

# game/script.rpy:5098
translate es cake_choice_cc6cf2be:

    # p "It's quite gorgeous... Is there a story behind this ring?"
    p "Es bastante hermoso... ¿Hay alguna historia detrás de este anillo?"

# game/script.rpy:5102
translate es cake_choice_e9249f65:

    # "A bright smile blooms on Elias' face as he kisses my hand, the diamond sparkling on my finger."
    "Una brillante sonrisa florece en el rostro de Elias mientras me besa la mano, el diamante brillando en mi dedo."

# game/script.rpy:5104
translate es cake_choice_f97fa1d5:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0203.ogg"
    # e normal forward_lidded_regular "My grandfather held a high post as a military officer, being the personal guard to several members of the royal family in England."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0203.ogg"
    e normal forward_lidded_regular "Mi abuelo ocupó un alto cargo como oficial militar, siendo guardia personal de varios miembros de la familia real en Inglaterra."

# game/script.rpy:5108
translate es cake_choice_03a398f9:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0204.ogg"
    # e smug closed_sad "He was humble and full of wit, and thus could predict the enemy's movements far in advance."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0204.ogg"
    e smug closed_sad "Era humilde y lleno de ingenio, y por eso podía predecir los movimientos del enemigo con mucha anticipación."

# game/script.rpy:5112
translate es cake_choice_f46d105c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0205.ogg"
    # e forward_regular grin_tilted "Why, during his time he actually thwarted an assassination attempt!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0205.ogg"
    e forward_regular grin_tilted "¡Durante su tiempo incluso frustró un intento de asesinato!"

# game/script.rpy:5116
translate es cake_choice_cca89d89:

    # "My eyes widen."
    "Mis ojos se abren ampliamente."

# game/script.rpy:5118
translate es cake_choice_65c7a98c:

    # p "Oh my! That's quite the life he must have lived."
    p "¡Oh, cielos! Qué vida tan extraordinaria debió haber vivido."

# game/script.rpy:5120
translate es cake_choice_e1e83c54:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0206.ogg"
    # e closed_happy grin_teeth "Indeed. They offered him a gift for stopping the attempted regicide... The deed to a gem mine. It was quite successful, and on top of that he managed to increase the productivity quite a bit."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0206.ogg"
    e closed_happy grin_teeth "Así es. Le ofrecieron un regalo por detener el intento de regicidio... La propiedad de una mina de gemas. Fue muy exitosa, y además logró aumentar la productividad considerablemente."

# game/script.rpy:5124
translate es cake_choice_fa1621eb:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0207.ogg"
    # e forward_lidded_regular lipbite_big "That's how he himself rose to aristocracy."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0207.ogg"
    e forward_lidded_regular lipbite_big "Así fue como él mismo ascendió a la aristocracia."

# game/script.rpy:5128
translate es cake_choice_c9597f78:

    # "Elias' smile softens, eyes sparkling as he regales the tale. "
    "La sonrisa de Elias se suaviza, con los ojos brillando mientras relata la historia."

# game/script.rpy:5130
translate es cake_choice_89177523:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0208.ogg"
    # e forward_heart normal "When a civil war broke out, he fled to America with my grandmother, my father, and only a few belongings. It wasn't enough to maintain their previous lifestyle... at least not immediately."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0208.ogg"
    e forward_heart normal "Cuando estalló una guerra civil, huyó a América con mi abuela, mi padre y solo unas pocas pertenencias. No fue suficiente para mantener su estilo de vida anterior... al menos no de inmediato."

# game/script.rpy:5134
translate es cake_choice_fb2525ec:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0209.ogg"
    # e smug closed_sad neutral "Yet regardless of how much they struggled,\nhe still refused to sell the jewels."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0209.ogg"
    e smug closed_sad neutral "Sin embargo, a pesar de las dificultades, \nél se negó a vender las joyas."

# game/script.rpy:5138
translate es cake_choice_69ca03db:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0210.ogg"
    # e forward_lidded_regular "They represented everything he had been through... His dedication and hope despite the hardships."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0210.ogg"
    e forward_lidded_regular "Representaban todo lo que había vivido... Su dedicación y esperanza a pesar de las adversidades."

# game/script.rpy:5142
translate es cake_choice_959bbcf4:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0211.ogg" 
    # e grin_teeth "That determination inspired my father to start a business of his own. Eventually, he became a cornmeal baron beyond compare."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0211.ogg" 
    e grin_teeth "Esa determinación inspiró a mi padre a iniciar su propio negocio. Eventualmente, se convirtió en un barón del maíz sin igual."

# game/script.rpy:5148
translate es cake_choice_6ea1dc3d:

    # "Elias lets out an awkward chuckle, looking away in embarrassment."
    "Elias suelta una risa incómoda, mirando hacia otro lado avergonzado."

# game/script.rpy:5150
translate es cake_choice_893a90eb:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0212.ogg"
    # e closed_sad sad ugh "I suppose I pale in relation. I never amounted to anything when compared to the great deeds my grandfather, father, and siblings accomplished in their lifetimes."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0212.ogg"
    e closed_sad sad ugh "Supongo que palidezco en comparación. Nunca logré nada comparado con las grandes hazañas que mi abuelo, padre y hermanos lograron en su vida."

# game/script.rpy:5156
translate es cake_choice_01c352ae:

    # p "Nonsense!"
    p "¡Tonterías!"

# game/script.rpy:5158
translate es cake_choice_fa03269c:

    # "I squeeze his hand compassionately."
    "Aprieto su mano con compasión."

# game/script.rpy:5160
translate es cake_choice_f1e38dc3:

    # p "You grew up kind, dear Elias. Hopeful and determined, just like your grandfather."
    p "Creciste siendo amable, querido Elias. Esperanzado y decidido, igual que tu abuelo."

# game/script.rpy:5162
translate es cake_choice_c7ee4074:

    # p "It doesn't matter that it didn't apply to business... It certainly applied to your heart."
    p "No importa que no se aplicara a los negocios... Sin duda se aplicó a tu corazón."

# game/script.rpy:5166
translate es cake_choice_3ae5fedb:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0213.ogg"
    # e left_lidded oh_sad sad "My dear..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0213.ogg"
    e left_lidded oh_sad sad "Cariño..."

# game/script.rpy:5170
translate es cake_choice_ebdc984d:

    # "Elias looks past me, biting his lip."
    "Elias mira más allá de mí, mordiéndose el labio."

# game/script.rpy:5174
translate es cake_choice_e3cc1500:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0214.ogg"
    # e right_lidded ah_sad "I must confess something to you. I doubt that it will affect you now, but..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0214.ogg"
    e right_lidded ah_sad "Debo confesarte algo. Dudo que te afecte ahora, pero..."

# game/script.rpy:5178
translate es cake_choice_78d6f964:

    # "I brace myself... I have no idea what he plans to tell me."
    "Me preparo... No tengo idea de lo que planea decirme."

# game/script.rpy:5180
translate es cake_choice_370b0286:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0215.ogg"
    # e closed_sad concerned unsure "[your_name], I adore you, but my mere existence is a blight."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0215.ogg"
    e closed_sad concerned unsure "[your_name], te adoro, pero mi mera existencia es una maldición."

# game/script.rpy:5184
translate es cake_choice_08085f32:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0216.ogg"
    # e sad sweat upset_open "My polite mannerisms and lavish clothing are merely a thin veneer over the fact that I am weak, hideous, and undeserving of my status."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0216.ogg"
    e sad sweat upset_open "Mis modales y mi ropa lujosa son apenas una delgada capa sobre el hecho de que soy débil, horrendo e indigno de mi estatus."

# game/script.rpy:5192
translate es cake_choice_87e18479:

    # p "Elias, don't say such awful things about yourself! You've never had the tools to succeed in a world that measures your worth by your productivity."
    p "¡Elias, no digas cosas tan horribles sobre ti! Nunca tuviste las herramientas para triunfar en un mundo que mide tu valor por tu productividad."

# game/script.rpy:5194
translate es cake_choice_7977da20:

    # p "Without even considering the barriers that hold you back, you were thrown into the meat grinder without emotional support or physical ability to meet the challenge head on."
    p "Sin siquiera considerar las barreras que te detienen, fuiste lanzado al molinillo sin apoyo emocional ni habilidad física para enfrentar el desafío directamente."

# game/script.rpy:5198
translate es cake_choice_885938b5:

    # "I take a breath to steady myself."
    "Respiro para calmarme."

# game/script.rpy:5200
translate es cake_choice_900d401f:

    # p "This system was not made with people like you in mind, so how could you be expected to succeed when you are pitted against people who don't face the same struggles?"
    p "Este sistema no fue hecho pensando en personas como tú, entonces ¿cómo se podría esperar que tuvieras éxito cuando te enfrentas a personas que no enfrentan las mismas dificultades?"

# game/script.rpy:5202
translate es cake_choice_eea3d387:

    # p "And despite past neglect, you have always been hopeful. {i}That{/i} is far more admirable in my eyes—"
    p "Y a pesar del abandono pasado, siempre has tenido esperanza. {i}Eso{/i} es mucho más admirable a mis ojos—"

# game/script.rpy:5204
translate es cake_choice_6e6f83bc:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0217.ogg"
    # e closed_sad sad oh_sad "You are far too kind, [your_name].\nI appreciate your words greatly, however..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0217.ogg"
    e closed_sad sad oh_sad "Eres demasiado amable, [your_name].\nAprecio mucho tus palabras, sin embargo..."

# game/script.rpy:5217
translate es cake_choice_7cf2576d:

    # "Elias grips me tighter, as if afraid I might run off."
    "Elias me aprieta más fuerte, como si temiera que pudiera escapar."

# game/script.rpy:5219
translate es cake_choice_6d8b035b:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0218.ogg"
    # e forward_lidded_small frown_small "The truth is... I was congenitally malformed."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0218.ogg"
    e forward_lidded_small frown_small "La verdad es... nací con malformaciones congénitas."

# game/script.rpy:5223
translate es cake_choice_7be8a5fe:

    # p "Malformed?"
    p "¿Malformaciones?"

# game/script.rpy:5227
translate es cake_choice_7678e863:

    # "I took another look at Elias, squinting. At a glance, I could see nothing amiss. He seemed to have all of his limbs, fingers, ears, eyes and nose. His clothing betrayed no alterations in form or function."
    "Miro de nuevo a Elias, entrecerrando los ojos. A simple vista, no podía ver nada fuera de lugar. Parecía tener todos sus miembros, dedos, orejas, ojos y nariz. Su ropa no mostraba alteraciones en forma ni función."

# game/script.rpy:5229
translate es cake_choice_55e50854:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0219.ogg"
    # e closed_sad ah_sad "It's not immediately apparent, thanks to years of learning to adapt around my condition. But, it's true. I..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0219.ogg"
    e closed_sad ah_sad "No es inmediatamente evidente, gracias a los años aprendiendo a adaptarme a mi condición. Pero es cierto. Yo..."

# game/script.rpy:5233
translate es cake_choice_ec3c7809:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0220.ogg"
    # e forward_lidded_smaller oh_disapprove "My feet are malformed —{i}were{/i} malformed at birth — and so, in life, I had difficulty walking. Compounding that was a general sense of malaise that never improved over time."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0220.ogg"
    e forward_lidded_smaller oh_disapprove "Mis pies están malformados —{i}estaban{/i} malformados al nacer— y, en vida, tenía dificultad para caminar. A eso se sumaba un malestar general que nunca mejoró con el tiempo."

# game/script.rpy:5239
translate es cake_choice_dc7f8d37:

    # "Elias pauses, gaze never leaving mine yet looking past me all the same."
    "Elias hace una pausa, sin apartar la mirada de la mía, aunque a la vez parece mirar más allá de mí."

# game/script.rpy:5241
translate es cake_choice_9dbc8c37:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0221.ogg"
    # e oh_sad "The family doctor had diagnosed the malaise as what was commonly known as a nervous disorder at the time, a condition which had then only recently been christened as Multiple Sclerosis."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0221.ogg"
    e oh_sad "El médico de familia había diagnosticado el malestar como lo que en ese entonces se conocía comúnmente como un trastorno nervioso, una condición que recién había sido bautizada como Esclerosis Múltiple."

# game/script.rpy:5245
translate es cake_choice_97dbfd52:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0222.ogg"
    # e closed_sad angry upset_open "Being that both my congenital deformity and acquired nervous disorder are incurable, my continued existence proved to be a great burden that only grew over time."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0222.ogg"
    e closed_sad angry upset_open "Dado que tanto mi deformidad congénita como el trastorno nervioso adquirido eran incurables, mi existencia continuada resultaba ser una gran carga que solo crecía con el tiempo."

# game/script.rpy:5253
translate es cake_choice_83e83c72:

    # p "I'm so sorry..."
    p "Lo siento mucho..."

# game/script.rpy:5255
translate es cake_choice_7d0f9638:

    # "My apology feels so inadequate, but I don't know what else to say. What am I even apologizing for? My gaze turns to the side as I think of something better to say."
    "Mi disculpa se siente tan insuficiente, pero no sé qué más decir. ¿Por qué estoy siquiera disculpándome? Giro la mirada a un lado mientras pienso en algo mejor que decir."

# game/script.rpy:5257
translate es cake_choice_750374b8:

    # "On its own, being ill is nothing to be sorry for, it's not within anyone's control. But when the systems and people that should have provided support fail a person with an incurable condition..."
    "Por sí mismo, estar enfermo no es algo por lo que disculparse, no está bajo el control de nadie. Pero cuando los sistemas y personas que deberían brindar apoyo fallan a alguien con una condición incurable..."

# game/script.rpy:5259
translate es cake_choice_655e3d6e:

    # "It truly is regrettable."
    "Realmente es lamentable."

# game/script.rpy:5263
translate es cake_choice_bdf97092:

    # "Elias was confined to bed even though the condition itself could have been managed with proper support."
    "Elias estuvo confinado a la cama aunque la condición en sí podría haberse manejado con el apoyo adecuado."

# game/script.rpy:5265
translate es cake_choice_f2b92297:

    # "Because his siblings had never needed that kind of support, that alone was enough to condemn Elias to an isolated life of hardship."
    "Como sus hermanos nunca necesitaron ese tipo de apoyo, eso por sí solo condenó a Elias a una vida aislada de dificultades."

# game/script.rpy:5267
translate es cake_choice_a6c89b6c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0223.ogg"
    # e right_lidded unsure "My birth itself was difficult and caused my mother quite a lot of grief. I don't blame her for any resentment left over from that."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0223.ogg"
    e right_lidded unsure "Mi nacimiento mismo fue difícil y causó bastante sufrimiento a mi madre. No le reprocho ningún resentimiento que haya quedado de eso."

# game/script.rpy:5271
translate es cake_choice_433b7d0c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0224.ogg"
    # e forward_lidded_small squiggle "But, it wasn't all bad, I consider it a blessing that my condition could be easily obscured, so I wouldn't bring further shame to the family name."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0224.ogg"
    e forward_lidded_small squiggle "Pero, no todo fue malo; considero una bendición que mi condición pudiera ocultarse fácilmente, para no traer más vergüenza al apellido familiar."

# game/script.rpy:5277
translate es cake_choice_7e535d43:

    # "We both glance down to where his feet would otherwise be, now replaced by a ghostly, translucent tail."
    "Ambos miramos hacia abajo, donde de otro modo estarían sus pies, ahora reemplazados por una cola fantasmal y translúcida."

# game/script.rpy:5279
translate es cake_choice_9d624f36:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0225.ogg"
    # e unsure forward_lidded_regular "Tell me, [your_name]... several decades have passed since my death. Surely both science and medicine have marched forward during that time."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0225.ogg"
    e unsure forward_lidded_regular "Dime, [your_name]... han pasado varias décadas desde mi muerte. Seguramente la ciencia y la medicina han avanzado en ese tiempo."

# game/script.rpy:5283
translate es cake_choice_8c0acb9b:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0226.ogg"
    # e oh_sad "Are there cures now for the conditions I had in life? I hate to consider that anyone may still be suffering from these afflictions."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0226.ogg"
    e oh_sad "¿Existen ahora curas para las condiciones que tuve en vida? Me horroriza pensar que alguien aún pueda sufrir estas aflicciones."

# game/script.rpy:5289
translate es cake_choice_fe869e23:

    # p "I... I'm afraid that doctors still haven't found a cure for Multiple Sclerosis. We know a lot more about it now though!"
    p "Yo... me temo que los médicos aún no han encontrado cura para la Esclerosis Múltiple. ¡Pero ahora sabemos mucho más sobre ella!"

# game/script.rpy:5293
translate es cake_choice_347ab349:

    # p "Some think it's an autoimmune disorder, and we can manage the symptoms. Some researchers even believe they've pinpointed the cause, though that is still to be seen."
    p "Algunos creen que es un trastorno autoinmune, y podemos manejar los síntomas. Algunos investigadores incluso creen haber identificado la causa, aunque aún está por verse."

# game/script.rpy:5297
translate es cake_choice_43ab0a56:

    # p "And then surgeons can provide prosthetics — artificial limbs, that is. Vast strides have been made for prosthetics since the Great War. It's an option if people can afford it."
    p "Y luego los cirujanos pueden proporcionar prótesis — es decir, miembros artificiales. Se han logrado enormes avances en prótesis desde la Gran Guerra. Es una opción si la gente puede costearlo."

# game/script.rpy:5299
translate es cake_choice_c529833b:

    # "I manage a genuine smile at him."
    "Le ofrezco una sonrisa genuina."

# game/script.rpy:5301
translate es cake_choice_d0a640d1:

    # p "There are whole practices dedicated to learning how to live with and use a new limb, fitting prosthetics for individual patients, therapies for regaining physical strength and social integration."
    p "Existen prácticas completas dedicadas a aprender a vivir y usar un nuevo miembro, a adaptar prótesis a pacientes individuales, terapias para recuperar fuerza física e integración social."

# game/script.rpy:5303
translate es cake_choice_895c3306:

    # p "There is so much to be hopeful for now."
    p "Ahora hay mucho por lo que tener esperanza."

# game/script.rpy:5309
translate es cake_choice_87af318b:

    # "Elias closes his eyes, bowing his head."
    "Elias cierra los ojos, inclinando la cabeza."

# game/script.rpy:5311
translate es cake_choice_7f149911:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0227.ogg"
    # e frown_small "I see... That is a small comfort, I suppose."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0227.ogg"
    e frown_small "Ya veo... Supongo que es un pequeño consuelo."

# game/script.rpy:5315
translate es cake_choice_3c5bb8ec:

    # p "Being disabled does not make your life something to be ashamed of, Elias. You did the best you could with what you had, and..."
    p "Ser discapacitado no hace que tu vida sea algo de lo que avergonzarse, Elias. Hiciste lo mejor que pudiste con lo que tenías, y..."

# game/script.rpy:5319
translate es cake_choice_d3f032c9:

    # p "... And I still intend to wed you, my dear."
    p "... Y aún tengo la intención de casarme contigo, cariño."

# game/script.rpy:5334
translate es cake_choice_f09df6a6:

    # "Elias takes in a breath, regaining his composure while loosening the grip on my hand."
    "Elias respira hondo, recobrando la compostura mientras afloja su agarre sobre mi mano."

# game/script.rpy:5338
translate es cake_choice_0712396c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0228.ogg"
    # e forward_lidded_regular frown_small sad "Thank you, [your_name]. Your kindness shines a light in the dark cloud of my thoughts."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0228.ogg"
    e forward_lidded_regular frown_small sad "Gracias, [your_name]. Tu bondad ilumina la oscura nube de mis pensamientos."

# game/script.rpy:5342
translate es cake_choice_f97eae9e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0229.ogg"
    # e closed_sad happy normal "Let us dispel such unpleasantness now. Shall we take our leave for the ceremony?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0229.ogg"
    e closed_sad happy normal "Disipemos ahora tal desagrado. ¿Tomamos nuestro camino hacia la ceremonia?"

# game/script.rpy:5346
translate es cake_choice_95b6c82b:

    # "I do my best to nod and smile, the weight of his words still heavy in my heart. My arm wraps around his."
    "Hago lo posible por asentir y sonreír, con el peso de sus palabras aún pesado en mi corazón. Mi brazo se rodea del suyo."

# game/script.rpy:5348
translate es cake_choice_1dd2ca10:

    # p "... We shall."
    p "... Así lo haremos."

# game/script.rpy:5355
translate es cake_choice_b04ea197:

    # "The necklace is heavy in my hands as I gently pick it up. Boy, bet I could pay off all my student loans and then some with this thing."
    "El collar pesa en mis manos mientras lo tomo suavemente. Vaya, seguro podría pagar todos mis préstamos estudiantiles y algo más con esto."

# game/script.rpy:5357
translate es cake_choice_2df04744:

    # "I study it closer. It looks almost... familiar."
    "Lo examino más de cerca. Parece casi... familiar."

# game/script.rpy:5359
translate es cake_choice_c9056d57:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0230.ogg"
    # e closed_happy normal "Do you like it?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0230.ogg"
    e closed_happy normal "¿Te gusta?"

# game/script.rpy:5363
translate es cake_choice_af4fb896:

    # p "I do but, I think... I've seen this before. Maybe from an old picture?"
    p "Sí, pero creo... que ya lo he visto antes. Tal vez en una foto antigua."

# game/script.rpy:5367
translate es cake_choice_da324755:

    # "Elias tilts his head."
    "Elias inclina la cabeza."

# game/script.rpy:5369
translate es cake_choice_82d1f708:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0231.ogg"
    # e @ grin_teeth "It was one of my mother's favorite pieces in this collection. It's also the most expensive."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0231.ogg"
    e @ grin_teeth "Era una de las piezas favoritas de mi madre en esta colección. También es la más cara."

# game/script.rpy:5373
translate es cake_choice_9f1d16c3:

    # "As he says this, it suddenly becomes even more heavy in my hands."
    "Al decir esto, de repente se vuelve aún más pesado en mis manos."

# game/script.rpy:5375
translate es cake_choice_4a924ad0:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0232.ogg"
    # e forward_heart @ grin_teeth "Here, allow me."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0232.ogg"
    e forward_heart @ grin_teeth "Aquí, permíteme."

# game/script.rpy:5379
translate es cake_choice_62dff436:

    # "Elias takes the necklace and moves behind me."
    "Elias toma el collar y se coloca detrás de mí."

# game/script.rpy:5381
translate es cake_choice_d5cd212b:

    # p "Could you tell me more about yourself, Elias? I'm curious to know as much as I can about my groom."
    p "¿Podrías contarme más sobre ti, Elias? Tengo curiosidad por conocer todo lo posible sobre mi prometido."

# game/script.rpy:5383
translate es cake_choice_7881612c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0233.ogg"
    # e grin_straight blush happy "Of course."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0233.ogg"
    e grin_straight blush happy "Por supuesto."

# game/script.rpy:5389
translate es cake_choice_107c4714:

    # "His hands are cold against my skin as he slides the jewelry around my neck. He clasps it shut, hands lingering for a moment on my skin."
    "Sus manos están frías contra mi piel mientras desliza la joya alrededor de mi cuello. Lo cierra, dejando sus manos un momento sobre mi piel."

# game/script.rpy:5393
translate es cake_choice_598be8e0:

    # "He gives a tired sigh before speaking, a hint of melancholy lingering on his lips."
    "Suspira cansado antes de hablar, un matiz de melancolía en sus labios."

# game/script.rpy:5395
translate es cake_choice_075bcc9c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0234.ogg"
    # e ah_sad "I must confess that I was born quite sickly, and my birth came with so many complications that it nearly killed my mother. Even after that ordeal, there was nothing the doctors could do to help my weak constitution."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0234.ogg"
    e ah_sad "Debo confesar que nací bastante enfermizo, y mi nacimiento tuvo tantas complicaciones que casi mata a mi madre. Incluso después de esa prueba, los médicos no pudieron ayudar a mi débil constitución."

# game/script.rpy:5399
translate es cake_choice_104279dc:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0235.ogg"
    # e oh_disapprove left_small "I suppose that's why my father and siblings treated me the way they did. I was seen as a nuisance, a problem. I don't entirely blame them."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0235.ogg"
    e oh_disapprove left_small "Supongo que por eso mi padre y mis hermanos me trataron como lo hicieron. Me veían como una molestia, un problema. No los culpo del todo."

# game/script.rpy:5403
translate es cake_choice_ade83570:

    # p "I'm sorry..."
    p "Lo siento..."

# game/script.rpy:5405
translate es cake_choice_706c1419:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0236.ogg"
    # e right_lidded oh_sad "It is far and away in the past now, so enough about that."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0236.ogg"
    e right_lidded oh_sad "Eso ya queda muy atrás, así que basta de eso."

# game/script.rpy:5411
translate es cake_choice_726a044a:

    # "Elias moves back around to look at me, a cold, ghostly hand trailing along my cheek. The sadness from his voice has all but disappeared. "
    "Elias retrocede para mirarme, una fría mano fantasmal recorriendo mi mejilla. La tristeza en su voz ha desaparecido casi por completo."

# game/script.rpy:5413
translate es cake_choice_b7d14641:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0237.ogg"
    # e forward_regular happy blush lipbite_big "Marvelous! The necklace fits you perfectly."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0237.ogg"
    e forward_regular happy blush lipbite_big "¡Maravilloso! El collar te queda perfectamente."

# game/script.rpy:5419
translate es cake_choice_b0f4803b:

    # "I angle my head up to get a clear view of it in the mirror. It certainly is gorgeous, but I know that I can get more information out of Elias if I play my cards right."
    "Inclino la cabeza para verlo claramente en el espejo. Ciertamente es hermoso, pero sé que puedo sacar más información de Elias si juego bien mis cartas."

# game/script.rpy:5421
translate es cake_choice_0f962547:

    # p "I'm certain this necklace must bestow infinite beauty upon its wearer. Surely you've seen others don it before?"
    p "Estoy segura de que este collar debe otorgar belleza infinita a quien lo porte. Seguro que has visto a otros usarlo antes, ¿verdad?"

# game/script.rpy:5423
translate es cake_choice_e1e0ce4d:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0238.ogg"
    # e left_regular grin_straight -blush "As mentioned, this was my mother's favorite piece! It graced her neck quite frequently."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0238.ogg"
    e left_regular grin_straight -blush "Como mencioné, ¡era la pieza favorita de mi madre! Con frecuencia adornaba su cuello."

# game/script.rpy:5427
translate es cake_choice_b2410a55:

    # p "And what of your previous bride-to-be? Did she not wear this as well?"
    p "¿Y tu prometida anterior? ¿No lo usaba también?"

# game/script.rpy:5429
translate es cake_choice_029d449c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0239.ogg"
    # e forward_small unsure "My... My previous bride...?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0239.ogg"
    e forward_small unsure "Mi... mi prometida anterior...?"

# game/script.rpy:5433
translate es cake_choice_8bc6984e:

    # "The smile slips from his lips, and his eyes go hazy. I brace myself for another vision."
    "La sonrisa desaparece de sus labios y sus ojos se vuelven nebulosos. Me preparo para otra visión."

# game/script.rpy:5437
translate es cake_choice_1786af67:

    # "I feel bad... I know it's unpleasant for Elias as much as it is for me, but he's a key witness to the mystery of this manor. His whole life and death, as a matter of fact."
    "Me siento mal... Sé que es desagradable para Elias tanto como para mí, pero es un testigo clave del misterio de esta mansión. Su vida y muerte, de hecho."

# game/script.rpy:5441
translate es cake_choice_39758cd2:

    # "The silence stretches on for what feels like forever. Elias' face is completely blank, devoid of any emotion."
    "El silencio se prolonga lo que parece una eternidad. El rostro de Elias está completamente vacío, sin emoción alguna."

# game/script.rpy:5443
translate es cake_choice_983ec79d:

    # p "Elias, dearest? I meant no offense—"
    p "¿Elias, querido? No quise ofender—"

# game/script.rpy:5447
translate es cake_choice_8436fc62:

    # "Elias grips my shoulders, his fingers phasing through my skin, causing a shiver."
    "Elias agarra mis hombros, sus dedos atravesando mi piel, provocando un escalofrío."

# game/script.rpy:5449
translate es cake_choice_c0fd013c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0240.ogg"
    # e closed_sad tch sad sweat "Her name was Violet. Violet Dupont, the sister of our groundskeeper. We never wed because she betrayed me the day before our wedding."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0240.ogg"
    e closed_sad tch sad sweat "Su nombre era Violet. Violet Dupont, la hermana de nuestro cuidador. Nunca nos casamos porque me traicionó el día antes de nuestra boda."

# game/script.rpy:5453
translate es cake_choice_6027c406:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0241.ogg"
    # e left_lidded upset_open angry "I suppose she and Gerard were desperate. I should have been on my guard when they continued to ask me about the location of the family jewels, day after day."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0241.ogg"
    e left_lidded upset_open angry "Supongo que ella y Gerard estaban desesperados. Debí haber estado alerta cuando seguían preguntándome sobre la ubicación de las joyas familiares, día tras día."

# game/script.rpy:5457
translate es cake_choice_19dfcf87:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0242.ogg"
    # e right_lidded grinding -sweat "I thought the necklace, the grandest piece in the collection, would have been enough to hold her interest. I had promised to share the rest of them with her after our... consummation."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0242.ogg"
    e right_lidded grinding -sweat "Pensé que el collar, la pieza más grandiosa de la colección, sería suficiente para mantener su interés. Había prometido compartir el resto con ella después de nuestra... consumación."

# game/script.rpy:5461
translate es cake_choice_44541492:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0243.ogg"
    # e frown_disapprove closed_sad "But before I could even cry out for help, Gerard held me down while Violet..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0243.ogg"
    e frown_disapprove closed_sad "Pero antes de que pudiera siquiera pedir ayuda, Gerard me sujetó mientras Violet..."

# game/script.rpy:5469
translate es cake_choice_99396084:

    # "I put my hand over Elias' in an attempt to show him that I don't need to hear anything else."
    "Pongo mi mano sobre la de Elias para mostrarle que no necesito escuchar nada más."

# game/script.rpy:5471
translate es cake_choice_4c01b2ea:

    # p "Forgive me, Elias. We don't need to speak of her anymore."
    p "Perdóname, Elias. No necesitamos hablar más de ella."

# game/script.rpy:5473
translate es cake_choice_a69e553d:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0244.ogg"
    # e forward_small neutral oh_disapprove "I..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0244.ogg"
    e forward_small neutral oh_disapprove "Yo..."

# game/script.rpy:5477
translate es cake_choice_445c2b8e:

    # "Elias' grip on my shoulders eases, and he gives me a sad smile."
    "Elias afloja su agarre sobre mis hombros y me regala una sonrisa triste."

# game/script.rpy:5479
translate es cake_choice_e2a581cb:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0245.ogg"
    # e forward_lidded_smaller sad squiggle sweat "No, you needn't apologize whatsoever. There's no need for me to reminisce and you shouldn't have to compare yourself to her."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0245.ogg"
    e forward_lidded_smaller sad squiggle sweat "No, no necesitas disculparte en absoluto. No hay necesidad de que rememoremos, y no deberías compararte con ella."

# game/script.rpy:5483
translate es cake_choice_ad81fef0:

    # "{i}Well yeah, I don't want to be compared to your murderer...{/i} At least... that's what I'd like to say."
    "{i}Bueno, sí, no quiero ser comparad@ con tu asesina...{/i} Al menos... eso es lo que me gustaría decir."

# game/script.rpy:5487
translate es cake_choice_a37d29c2:

    # "And I want to stop, but I need to know the truth straight from the horse's mouth. "
    "Y quiero parar, pero necesito conocer la verdad directamente de la fuente."

# game/script.rpy:5489
translate es cake_choice_277ef650:

    # p "Tell me about the things that brought joy to your life. You have a fine eye for beauty, Elias. I'm sure there were other items you held precious and dear."
    p "Cuéntame sobre las cosas que trajeron alegría a tu vida. Tienes buen ojo para la belleza, Elias. Estoy segura de que había otros objetos que considerabas preciosos y queridos."

# game/script.rpy:5491
translate es cake_choice_3e88c282:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0246.ogg"
    # e forward_regular -sad smug -sweat "You've seen the greenhouse already, so you can imagine its splendor in full bloom. I quite liked reading on a bench there when my energy permitted."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0246.ogg"
    e forward_regular -sad smug -sweat "Ya has visto el invernadero, así que puedes imaginar su esplendor en plena floración. Me gustaba leer en un banco allí cuando mi energía lo permitía."

# game/script.rpy:5495
translate es cake_choice_d269bcae:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0247.ogg"
    # e happy normal "It was difficult to visit in a consistent manner however, so I often had flowers brought up so that I could enjoy the fragrant, floral bouquets in the comfort of my room."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0247.ogg"
    e happy normal "Sin embargo, era difícil visitarlo de manera constante, así que a menudo traía flores para poder disfrutar de los fragantes ramos en la comodidad de mi habitación."

# game/script.rpy:5503
translate es cake_choice_6d5d1c73:

    # "Elias leaves my side momentarily to grab an ornate box from the vanity."
    "Elias se aleja momentáneamente para tomar una caja ornamentada del tocador."

# game/script.rpy:5505
translate es cake_choice_f5b4eaca:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0248.ogg"
    # e closed_happy grin_tilted "Aside from the flowers, there was also a family heirloom that belonged to my grandmother. It was an antique silver mirror, and a very charming one at that. At least..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0248.ogg"
    e closed_happy grin_tilted "Aparte de las flores, también había una reliquia familiar que pertenecía a mi abuela. Era un espejo antiguo de plata, y muy encantador. Al menos..."

# game/script.rpy:5509
translate es cake_choice_b08f198a:

    # "I lean forward as he opens the box, and I peer into its contents."
    "Me inclino mientras él abre la caja y observo su contenido."

# game/script.rpy:5517
translate es cake_choice_1494d360:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0249.ogg"
    # e closed_sad sad oh_sad "That was... before it shattered."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0249.ogg"
    e closed_sad sad oh_sad "Eso fue... antes de que se rompiera."

# game/script.rpy:5523
translate es cake_choice_304264bf:

    # "Elias {i}does{/i} still have the mirror pieces!"
    "¡Elias {i}sí{/i} conserva los pedazos del espejo!"

# game/script.rpy:5527
translate es cake_choice_e496d9b3:

    # "It's the same shards of glass I found while investigating his room before."
    "Son los mismos fragmentos de vidrio que encontré al investigar su habitación antes."

# game/script.rpy:5531
translate es cake_choice_1202edb6:

    # "In the box sits several shards of glass, reflecting jagged images of Elias and myself."
    "En la caja hay varios fragmentos de vidrio, reflejando imágenes quebradas de Elias y de mí."

# game/script.rpy:5533
translate es cake_choice_3df5c2d8:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0250.ogg"
    # e left_lidded ah_sad "I liked it quite a lot, and ended up taking it out of the attic in my early childhood. I used to look into it and imagine myself as some sort of fair prince."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0250.ogg"
    e left_lidded ah_sad "Me gustaba mucho, y acabé sacándolo del ático en mi infancia temprana. Solía mirarlo e imaginarme como algún tipo de príncipe justo."

# game/script.rpy:5537
translate es cake_choice_35890250:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0251.ogg"
    # e right_lidded unsure "It was innocent daydreaming. But alas, my six older siblings would often mock my love of the mirror... and with such a weak constitution and gentle demeanor, there was little I could do."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0251.ogg"
    e right_lidded unsure "Era un sueño inocente. Pero, lamentablemente, mis seis hermanos mayores solían burlarse de mi amor por el espejo... y con una constitución débil y carácter gentil, poco podía hacer."

# game/script.rpy:5541
translate es cake_choice_e1d390ae:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0252.ogg"
    # e forward_lidded_smaller squiggle sweat "When six people who aren't very fond of you get physical, well... you can imagine what might happen. The mirror was shattered, and I was the one blamed."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0252.ogg"
    e forward_lidded_smaller squiggle sweat "Cuando seis personas que no te aprecian físicamente se ponen agresivas, bueno... puedes imaginar lo que puede pasar. El espejo se rompió, y a mí me culparon."

# game/script.rpy:5549
translate es cake_choice_d8ec613c:

    # "He gently closes the box and pauses. "
    "Cierra suavemente la caja y hace una pausa."

# game/script.rpy:5551
translate es cake_choice_037408b7:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0253.ogg"
    # e frown_small left_small "Grandmother didn't seem to mind that it broke, but I cried for days. Maybe it was sentimentality, guilt, or fear... but whatever the case, I simply could not let it go."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0253.ogg"
    e frown_small left_small "A la abuela no le importó que se rompiera, pero yo lloré durante días. Tal vez era sentimentalismo, culpa o miedo... pero fuera lo que fuera, simplemente no podía dejarlo ir."

# game/script.rpy:5555
translate es cake_choice_b537d5f1:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0254.ogg"
    # e forward_lidded_small ah_sad concerned "I forbade any of the maids or butlers to toss out the shards. The mirror was meant to be a wedding gift, and I was determined to have it fixed one day."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0254.ogg"
    e forward_lidded_small ah_sad concerned "Prohibí a cualquier sirviente desechar los fragmentos. El espejo estaba destinado a ser un regalo de bodas, y estaba decidido a que algún día se reparara."

# game/script.rpy:5559
translate es cake_choice_89e8fbe6:

    # p "It seems like that day never came..."
    p "Parece que ese día nunca llegó..."

# game/script.rpy:5561
translate es cake_choice_e4598140:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0255.ogg"
    # e closed_sad oh_sad sad "Yes... it was one of my greatest regrets when I died, silly as it sounds."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0255.ogg"
    e closed_sad oh_sad sad "Sí... fue uno de mis mayores arrepentimientos cuando morí, aunque suene tonto."

# game/script.rpy:5567
translate es cake_choice_9ede9a22:

    # p "I don't think it's silly at all. That mirror was important to you, and you've held onto it all this time. I think it's admirable."
    p "No me parece tonto en absoluto. Ese espejo era importante para ti, y lo has conservado todo este tiempo. Creo que es admirable."

# game/script.rpy:5569
translate es cake_choice_30691704:

    # "Not to mention, that mirror could very likely be the source of the Gallagher curse! But does Elias know that?"
    "Sin mencionar que ese espejo muy probablemente podría ser la fuente de la maldición Gallagher. ¿Pero Elias lo sabe?"

# game/script.rpy:5573
translate es cake_choice_48f3baaf:

    # p "The world needs more men like you, Elias. I don't think you're silly for having emotions."
    p "El mundo necesita más hombres como tú, Elias. No creo que seas tonto por tener emociones."

# game/script.rpy:5575
translate es cake_choice_c7456835:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0256.ogg"
    # e forward_lidded_regular normal usual "Thank you for understanding, [your_name]."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0256.ogg"
    e forward_lidded_regular normal usual "Gracias por comprender, [your_name]."

# game/script.rpy:5583
translate es cake_choice_f8d3a844:

    # "The melancholy atmosphere in the room fades\nas he smiles warmly at me."
    "La atmósfera melancólica en la habitación se desvanece\nmientras él me sonríe cálidamente."

# game/script.rpy:5585
translate es cake_choice_3efc2f11:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0257.ogg"
    # e forward_heart grin_straight blush happy "I am quite eager for our union. I think it'll be something glorious. I've always wanted a grand wedding, and to think I'll be marrying someone as lovely as you..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0257.ogg"
    e forward_heart grin_straight blush happy "Estoy muy ansioso por nuestra unión. Creo que será algo glorioso. Siempre quise una boda grandiosa, y pensar que me casaré con alguien tan encantador como tú..."

# game/script.rpy:5589
translate es cake_choice_45599852:

    # p "Well... you are too kind, Elias."
    p "Bueno... eres demasiado amable, Elias."

# game/script.rpy:5591
translate es cake_choice_8f78d60b:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0258.ogg"
    # e closed_happy grin_teeth "Come on, follow me outside. I have much to show you."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0258.ogg"
    e closed_happy grin_teeth "Vamos, sígueme afuera. Tengo mucho que mostrarte."

# game/script.rpy:5600
translate es cake_choice_099a0ddb:

    # "I pick up the earrings. They're delicate yet ornate. I sigh softly, taking my time to inspect them closer... but despite my attempts to focus on the jewelry, I hear Taylor's warnings echo in my head over and over."
    "Recojo los pendientes. Son delicados pero ornamentados. Suspiro suavemente, tomándome mi tiempo para inspeccionarlos de cerca... pero a pesar de mis intentos de concentrarme en las joyas, escucho las advertencias de Taylor resonando en mi cabeza una y otra vez."

# game/script.rpy:5604
translate es cake_choice_c46be3e8:

    # "It's actually discomforting, not having heard his voice for so long while I'm stuck in this mansion. I should have asked him to come sooner."
    "En realidad es incómodo, no haber escuchado su voz durante tanto tiempo mientras estoy atrapada en esta mansión. Debería haberle pedido que viniera antes."

# game/script.rpy:5606
translate es cake_choice_00d6d541:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0259.ogg"
    # e pout "Are they not to your liking? If you'd prefer something else, surely I can—"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0259.ogg"
    e pout "¿No son de tu agrado? Si prefieres otra cosa, seguramente puedo—"

# game/script.rpy:5610
translate es cake_choice_9036a236:

    # p "Oh, that's not it at all! The earrings are gorgeous."
    p "¡Oh, para nada! Los pendientes son preciosos."

# game/script.rpy:5614
translate es cake_choice_ec691c7f:

    # "I pause, giving Elias a sheepish smile. My act is starting to slip without Taylor's commentary to ground me."
    "Hago una pausa, dándole a Elias una sonrisa tímida. Mi actuación empieza a resbalar sin el comentario de Taylor que me mantenga en tierra."

# game/script.rpy:5616
translate es cake_choice_c23f2f72:

    # "He said to stall for time. I {i}need{/i} to stall for time."
    "Dijo que debía ganar tiempo. Yo {i}necesito{/i} ganar tiempo."

# game/script.rpy:5618
translate es cake_choice_1dee2eb2:

    # p "I'm just a touch worried about how safe it is to wear these. The mansion itself is decaying, and if the jewelry has rusted anywhere, it may irritate my skin."
    p "Solo estoy un poco preocupada por lo seguro que es llevarlos puestos. La mansión misma se está deteriorando, y si las joyas se han oxidado en algún lugar, podrían irritar mi piel."

# game/script.rpy:5622
translate es cake_choice_0d462efc:

    # "Elias chuckles lightly. He motions for me to put on the earrings."
    "Elias se ríe suavemente. Me hace un gesto para que me ponga los pendientes."

# game/script.rpy:5624
translate es cake_choice_8cdf4f02:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0260.ogg"
    # e forward_heart grin_tilted "It's entirely safe. I have kept them in a secure location, and check on them frequently. You have nothing to fear."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0260.ogg"
    e forward_heart grin_tilted "Es totalmente seguro. Los he mantenido en un lugar seguro y los reviso con frecuencia. No tienes nada que temer."

# game/script.rpy:5630
translate es cake_choice_ad668682:

    # "\"The earrings could be cursed too! Once you put them on, they'll never come off!! Or maybe Elias will take over your body!!!\""
    "\"¡Los pendientes podrían estar malditos también! ¡Una vez que te los pongas, nunca se quitarán! ¡O quizá Elias tomará el control de tu cuerpo!\""

# game/script.rpy:5632
translate es cake_choice_2b17a246:

    # "... Or at least I think that's what Taylor would say if he heard that."
    "... O al menos eso creo que diría Taylor si escuchara eso."

# game/script.rpy:5636
translate es cake_choice_515ce4f1:

    # "I nearly snort at the thought, but stop myself before I do. Well, better not decline Elias' wishes. I carefully slip them on."
    "Casi suelto una risita ante la idea, pero me detengo antes de hacerlo. Bueno, mejor no rechazar los deseos de Elias. Me los pongo con cuidado."

# game/script.rpy:5638
translate es cake_choice_733f21a5:

    # "Nothing happens."
    "No pasa nada."

# game/script.rpy:5640
translate es cake_choice_0807bde7:

    # "See, Taylor? I'm perfectly fine."
    "¿Ves, Taylor? Estoy perfectamente bien."

# game/script.rpy:5642
translate es cake_choice_79b1b512:

    # p "Thank you for allowing me to borrow the earrings, Elias. They must be very precious to you."
    p "Gracias por permitirme tomar prestados los pendientes, Elias. Deben ser muy valiosos para ti."

# game/script.rpy:5646
translate es cake_choice_e7003d87:

    # "A slight blush flushes on Elias' cheeks."
    "Un leve rubor colorea las mejillas de Elias."

# game/script.rpy:5648
translate es cake_choice_2cabe978:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0261.ogg"
    # e closed_happy happy @ lipbite_small "Please, do keep them on for our ceremony... and beyond. Once we are wed, everything in my name will be yours."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0261.ogg"
    e closed_happy happy @ lipbite_small "Por favor, sigue usándolos para nuestra ceremonia... y más allá. Una vez casados, todo lo que esté a mi nombre será tuyo."

# game/script.rpy:5652
translate es cake_choice_8a75d171:

    # p "Everything..."
    p "Todo..."

# game/script.rpy:5654
translate es cake_choice_d01fa124:

    # "Elias really is serious about marrying me. I'm actually going to marry a dead man, aren't I? This isn't a joke."
    "Elias realmente está serio acerca de casarse conmigo. ¿De verdad voy a casarme con un hombre muerto, verdad? Esto no es un juego."

# game/script.rpy:5656
translate es cake_choice_00d8f613:

    # p "You're far too kind, Elias."
    p "Eres demasiado amable, Elias."

# game/script.rpy:5660
translate es cake_choice_04b30700:

    # "Elias smiles back genuinely. I want to scream, but I hold my tongue. I'm too young to get married, damn it!"
    "Elias me sonríe genuinamente. Quiero gritar, pero me contengo. ¡Soy demasiado joven para casarme, maldita sea!"

# game/script.rpy:5662
translate es cake_choice_7a7938d9:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0262.ogg"
    # e grin_teeth "Shall we make our way outside? Everything is prepared for the ceremony."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0262.ogg"
    e grin_teeth "¿Salimos afuera? Todo está preparado para la ceremonia."

# game/script.rpy:5666
translate es cake_choice_9c50eb04:

    # p "... Of course."
    p "... Por supuesto."

# game/script.rpy:5668
translate es cake_choice_4096eb60:

    # "I think I'll settle for screaming inside my brain."
    "Creo que me conformaré con gritar dentro de mi cabeza."

# game/script.rpy:5674
translate es cake_choice_f4002051:

    # "We exit his bedroom together and go down the stairs one last time; my new accessory adding weight to my every step."
    "Salimos de su habitación juntos y bajamos las escaleras por última vez; mi nuevo accesorio añade peso a cada uno de mis pasos."

# game/script.rpy:5682
translate es cake_choice_05945547:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0263.ogg"
    # e "Soon we shall be wed, my darling [your_name], and we'll have all of eternity together. Are you excited?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0263.ogg"
    e "Pronto estaremos casados, mi querido [your_name], y tendremos toda la eternidad juntos. ¿Estás emocionad@?"

# game/script.rpy:5688
translate es cake_choice_2401b994:

    # "Elias sure seems to be."
    "Elias ciertamente lo parece."

# game/script.rpy:5690
translate es cake_choice_300701d2:

    # p "I..."
    p "Yo..."

# game/script.rpy:5692
translate es cake_choice_0d07996c:

    # "I don't know how to answer that; whether I should be sincere and tell him the truth, or continue the charade."
    "No sé cómo responder; si debería ser sincera y decirle la verdad, o continuar con la farsa."

# game/script.rpy:5696
translate es cake_choice_117de144:

    # "The truth behind the so-called Gallagher curse wasn't some smaller business exacting revenge on the family, {i}or{/i} Elias pulling puppet strings in order to make himself the sole heir."
    "La verdad detrás de la llamada maldición Gallagher no era algún negocio menor cobrando venganza sobre la familia, {i}ni{/i} Elias moviendo los hilos para convertirse en el único heredero."

# game/script.rpy:5698
translate es cake_choice_f2e6856b:

    # "No, the Gallagher bloodline probably met its end because that antique mirror shattered when Elias was a child. He said that mirror was meant to be a wedding gift..."
    "No, la línea de sangre Gallagher probablemente terminó porque aquel espejo antiguo se rompió cuando Elias era niño. Dijo que ese espejo debía ser un regalo de bodas..."

# game/script.rpy:5700
translate es cake_choice_a669f206:

    # "Has the curse ended, or will I die too?"
    "¿Ha terminado la maldición, o moriré yo también?"

# game/script.rpy:5702
translate es cake_choice_a8a8c47f:

    # "The thought makes me shudder."
    "El pensamiento me hace estremecer."

# game/script.rpy:5706
translate es cake_choice_8f85e47c:

    # "At the very least, I can confidently say that there's\nno way Elias is capable of expressing malice towards others. He's too sweet, too naive almost."
    "Al menos, puedo decir con seguridad que no hay manera de que \nElias sea capaz de mostrar malicia hacia otros. Es demasiado dulce, casi ingenuo."

# game/script.rpy:5708
translate es cake_choice_c4702a4f:

    # "Elias deserved better. {i}Deserves{/i} better. But... {i}I{/i}\nam not the one he deserves. These feelings I have for him can only be described as pity."
    "Elias merecía algo mejor. {i}Merece{/i} algo mejor. Pero... {i}yo{/i}\nno soy quien él merece. Estos sentimientos que tengo hacia él solo pueden describirse como lástima."

# game/script.rpy:5710
translate es cake_choice_51814968:

    # "I can't love him the way he wants me to. The way he {i}needs{/i} me to."
    "No puedo amarlo como él quiere que lo haga. Como él {i}necesita{/i} que lo haga."

# game/script.rpy:5712
translate es cake_choice_9d7dac21:

    # "Not today, at least."
    "Al menos no hoy."

# game/script.rpy:5714
translate es cake_choice_93c9db4d:

    # "It's too soon for me to mean those three words he desperately needs to hear."
    "Es demasiado pronto para que diga esas tres palabras que él desesperadamente necesita escuchar."

# game/script.rpy:5716
translate es cake_choice_47625416:

    # "An insincere declaration of love to Elias Gallagher would surely be a sin worse than murder."
    "Una declaración insincera de amor a Elias Gallagher sería seguramente un pecado peor que el asesinato."

# game/script.rpy:5720
translate es cake_choice_1b74920c:

    # "Taylor is coming, but Elias is only interested in me. Even if Elias is kind, I don't know what he'll do if his second attempt at marriage fails."
    "Taylor viene, pero Elias solo está interesad@ en mí. Incluso si Elias es amable, no sé qué hará si su segundo intento de matrimonio falla."

# game/script.rpy:5722
translate es cake_choice_843361b7:

    # "This whole night Taylor has been on edge. I can't really blame him. I've worried my best friend ever since Elias entered the picture. And yet..."
    "Toda la noche Taylor ha estado tenso. No puedo culparlo realmente. He estado preocupándome por mi mejor amigo desde que Elias apareció en escena. Y aun así..."

# game/script.rpy:5724
translate es cake_choice_50f4605e:

    # "Why am I so worried about Taylor when {i}I'm{/i} the one who's probably in more danger?"
    "¿Por qué estoy tan preocupad@ por Taylor cuando {i}yo{/i} soy quien probablemente esté en más peligro?"

# game/script.rpy:5728
translate es cake_choice_d26d63d5:

    # "I've spent the whole night here, but I have more questions than I have answers. So many loose ends and no way to tie them..."
    "He pasado toda la noche aquí, pero tengo más preguntas que respuestas. Tantos cabos sueltos y ninguna manera de atarlos..."

# game/script.rpy:5730
translate es cake_choice_614d66fb:

    # "And yet, I'm about to tie the knot with a man I barely know while I have no idea if the other one will reach me in time."
    "Y sin embargo, estoy a punto de casarme con un hombre que apenas conozco mientras no tengo idea si el otro llegará a tiempo."

# game/script.rpy:5732
translate es cake_choice_af84eacf:

    # "I'm... so screwed."
    "Estoy... completamente jodid@."

# game/script.rpy:5734
translate es cake_choice_572d380f:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0264.ogg"
    # e forward_lidded_regular sad frown_small "[your_name], my love? What's on your mind?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0264.ogg"
    e forward_lidded_regular sad frown_small "[your_name], mi amor? ¿Qué tienes en mente?"

# game/script.rpy:5738
translate es cake_choice_dd811985:

    # p "Nothing! Uh, I mean—"
    p "¡Nada! Uh, quiero decir—"

# game/script.rpy:5740
translate es cake_choice_c5685f77:

    # "Hah, I really am a bad actor in the end."
    "Ja, realmente soy un@ mal actor al final."

# game/script.rpy:5742
translate es cake_choice_6ebcfbc2:

    # p "... With everything that has happened... is about to happen... I must be feeling the entire range of human emotion right now, my beloved. Nervous, excited..."
    p "... Con todo lo que ha pasado... está a punto de pasar... debo estar sintiendo todo el rango de emociones humanas ahora mismo, cariño. Nervios, emoción..."

# game/script.rpy:5746
translate es cake_choice_8a72fea5:

    # "And so, so full of dread."
    "Y tanto, tanto miedo."

# game/script.rpy:5748
translate es cake_choice_a20cefa7_1:

    # "..."
    "..."

# game/script.rpy:5756
translate es cake_choice_f4fb97a4:

    # "We return to the foyer, where this whole night began. Elias glides along the floor while I do my best to keep up with him, trying not to arouse suspicion."
    "Regresamos al vestíbulo, donde toda esta noche comenzó. Elias se desliza por el piso mientras hago mi mejor esfuerzo para seguirle el paso, tratando de no despertar sospechas."

# game/script.rpy:5758
translate es cake_choice_4fa72176:

    # "He places his hands on the door behind the steps, then turns to me."
    "Coloca sus manos en la puerta detrás de los escalones, luego se gira hacia mí."

# game/script.rpy:5760
translate es cake_choice_66ce8f88:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0265.ogg"
    # e grin_teeth happy "Are you ready, my love? I have worked tirelessly to prepare the old ballroom for our ceremony, and while we may not have any guests, I do hope that you will be pleased."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0265.ogg"
    e grin_teeth happy "¿Estás list@, mi amor? He trabajado incansablemente para preparar el antiguo salón de baile para nuestra ceremonia, y aunque no tengamos invitados, espero que te complazca."

# game/script.rpy:5766
translate es cake_choice_fc8119ff:

    # "My voice is hoarse, so the words get lost in my throat. All I can do is smile and nod."
    "Mi voz está ronca, así que las palabras se pierden en mi garganta. Todo lo que puedo hacer es sonreír y asentir."

# game/script.rpy:5768
translate es cake_choice_4a3414b9:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0266.ogg"
    # e closed_happy grin_tilted "Excellent. Then, without further ado..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0266.ogg"
    e closed_happy grin_tilted "Excelente. Entonces, sin más demora..."

# game/script.rpy:5772
translate es cake_choice_cf82d588:

    # "The doors to the ballroom open wide, and Elias bids me through."
    "Las puertas del salón de baile se abren de par en par, y Elias me invita a pasar."

# game/script.rpy:5778
translate es cake_choice_617bef6d:

    # "I walk down a tattered red carpet, through the dim cavernous room, towards the center where extravagant dishes, aged bottles of wine, crystal glasses, silver cutlery, and finally our bouquet, await us."
    "Camino por una alfombra roja raída, a través de la habitación cavernosa y tenue, hacia el centro donde nos esperan platos extravagantes, botellas de vino añejas, copas de cristal, cubiertos de plata y finalmente nuestro ramo."

# game/script.rpy:5784
translate es cake_choice_f237495b:

    # "No one is watching, and yet with each step I take I hear the echoes of whispers, murmurs, cheers, and sobs whenever my foot lifts from the floor."
    "Nadie observa, y sin embargo con cada paso que doy escucho ecos de susurros, murmullos, vítores y sollozos cada vez que levanto el pie del suelo."

# game/script.rpy:5786
translate es cake_choice_b8b6acd4:

    # "Are these... memories of previous weddings Elias has attended, now recreated for his own? I wonder who will officiate? Elias must have some memory of a minister ready as well..."
    "¿Son estos... recuerdos de bodas previas a las que Elias ha asistido, ahora recreados para él mismo? Me pregunto quién oficiará. Elias debe tener algún recuerdo de un ministro listo también..."

# game/script.rpy:5788
translate es cake_choice_febebd05:

    # "I turn my head back and peer at the door, waiting for my groom."
    "Vuelvo la cabeza y miro hacia la puerta, esperando a mi prometido."

# game/script.rpy:5794
translate es cake_choice_49b17f34:

    # "As he floats in, the noises grow more raucous, and the lights bloom into a pale blue glow. My gaze is fixed on Elias."
    "Mientras él flota hacia adentro, los ruidos se vuelven más estruendosos, y las luces se tiñen de un resplandor azul pálido. Mi mirada está fija en Elias."

# game/script.rpy:5798
translate es cake_choice_00ec5ea8:

    # "An eternity passes in a single second as he reaches the altar, beaming with endless pride."
    "Una eternidad pasa en un solo segundo mientras llega al altar, irradiando un orgullo sin fin."

# game/script.rpy:5800
translate es cake_choice_fe1b661e:

    # "It's time."
    "Es hora."

# game/script.rpy:5806
translate es cake_choice_8e10f832:

    # "The crowd hushes down to a murmur before coalescing into a single echoing voice."
    "La multitud guarda silencio hasta convertirse en un murmullo antes de unirse en una sola voz resonante."

# game/script.rpy:5810
translate es cake_choice_91a585d2:

    # voice "audio/voice/" + persistent.lang_voice + "/Minister_0001.ogg"
    # o "Welcome, all."
    voice "audio/voice/" + persistent.lang_voice + "/Minister_0001.ogg"
    o "Bienvenidos todos."

# game/script.rpy:5814
translate es cake_choice_e11ee1e3:

    # voice "audio/voice/" + persistent.lang_voice + "/Minister_0002.ogg"
    # o "Family and friends, thank you all for coming today to partake in this joyous occasion."
    voice "audio/voice/" + persistent.lang_voice + "/Minister_0002.ogg"
    o "Familia y amigos, gracias a todos por venir hoy a participar en esta alegre ocasión."

# game/script.rpy:5820
translate es cake_choice_d46df1b0:

    # voice "audio/voice/" + persistent.lang_voice + "/Minister_0003.ogg"
    # o "Today we are gathered together to unite Elias Gallagher with his beloved [your_name]."
    voice "audio/voice/" + persistent.lang_voice + "/Minister_0003.ogg"
    o "Hoy nos reunimos para unir a Elias Gallagher con su querid@ [your_name]."

# game/script.rpy:5826
translate es cake_choice_b4a3e063:

    # "I still can't take my eyes off my groom..."
    "Todavía no puedo apartar mis ojos de mi prometido..."

# game/script.rpy:5828
translate es cake_choice_df7aab9e:

    # voice "audio/voice/" + persistent.lang_voice + "/Minister_0004.ogg"
    # o "Long has he suffered, and now long shall he be overflowing with joy!"
    voice "audio/voice/" + persistent.lang_voice + "/Minister_0004.ogg"
    o "Ha sufrido mucho, y ahora será colmado de alegría por mucho tiempo."

# game/script.rpy:5834
translate es cake_choice_56c8f28c:

    # voice "audio/voice/" + persistent.lang_voice + "/Minister_0005.ogg"
    # o "Let the memories of betrayal, of murder, of waiting; be washed away like leaves in a flood."
    voice "audio/voice/" + persistent.lang_voice + "/Minister_0005.ogg"
    o "Que los recuerdos de traición, asesinato y espera sean arrastrados como hojas en una inundación."

# game/script.rpy:5840
translate es cake_choice_0a32d722:

    # voice "audio/voice/" + persistent.lang_voice + "/Minister_0006.ogg"
    # o "Love has triumphed!"
    voice "audio/voice/" + persistent.lang_voice + "/Minister_0006.ogg"
    o "¡El amor ha triunfado!"

# game/script.rpy:5844
translate es cake_choice_61bcfb5d:

    # "Oh god, if this is what Elias is thinking..."
    "Oh dios, si esto es lo que Elias está pensando..."

# game/script.rpy:5848
translate es cake_choice_3471c1d3:

    # voice "audio/voice/" + persistent.lang_voice + "/Minister_0007.ogg"
    # o "Do you, Elias Gallagher, take {0}him{/0}{1}her{/1}{2}them{/2} to be your lawfully wedded spouse; to live together in matrimony, to love {0}him{/0}{1}her{/1}{2}them{/2}, comfort {0}him{/0}{1}her{/1}{2}them{/2}, honor and keep {0}him{/0}{1}her{/1}{2}them{/2}..."
    voice "audio/voice/" + persistent.lang_voice + "/Minister_0007.ogg"
    o "¿Aceptas, Elias Gallagher, a {0}él{/0}{1}ella{/1}{2}elle{/2} como tu legítim@ espos@; para vivir juntos en matrimonio, amar a {0}él{/0}{1}ella{/1}{2}elle{/2}, confortar a {0}él{/0}{1}ella{/1}{2}elle{/2}, honrar y cuidar a {0}él{/0}{1}ella{/1}{2}elle{/2}..."

# game/script.rpy:5854
translate es cake_choice_4e7e8992:

    # voice "audio/voice/" + persistent.lang_voice + "/Minister_0008.ogg"
    # o "In sickness and in health, in sorrow and in joy, to have and to hold, from this day forward, now and for all time?"
    voice "audio/voice/" + persistent.lang_voice + "/Minister_0008.ogg"
    o "En la enfermedad y en la salud, en la tristeza y en la alegría, tener y sostener, desde este día en adelante, ahora y por siempre?"

# game/script.rpy:5858
translate es cake_choice_d71411cb:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0267.ogg"
    # e @ grin_teeth "I do."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0267.ogg"
    e @ grin_teeth "Sí, lo hago."

# game/script.rpy:5862
translate es cake_choice_8f22502a:

    # voice "audio/voice/" + persistent.lang_voice + "/Minister_0009.ogg"
    # o "Do you, [your_name], take Elias Gallagher to be your lawfully wedded husband; to live together in matrimony, to love him, comfort him, honor and keep him..."
    voice "audio/voice/" + persistent.lang_voice + "/Minister_0009.ogg"
    o "¿Aceptas, [your_name], a Elias Gallagher como tu legítimo esposo; para vivir juntos en matrimonio, amarlo, confortarlo, honrarlo y cuidarlo..."

# game/script.rpy:5866
translate es cake_choice_fd4013c9:

    # voice "audio/voice/" + persistent.lang_voice + "/Minister_0010.ogg"
    # o "In sickness and in health, in sorrow and in joy, to have and to hold, from this day forward, now and for all time?"
    voice "audio/voice/" + persistent.lang_voice + "/Minister_0010.ogg"
    o "En la enfermedad y en la salud, en la tristeza y en la alegría, tener y sostener, desde este día en adelante, ahora y por siempre?"

# game/script.rpy:5870
translate es cake_choice_1964896b:

    # p "... I..."
    p "... Yo..."

# game/script.rpy:5872
translate es cake_choice_e557e861:

    # p "I... d—"
    p "Yo... a—"

# game/script.rpy:5878
translate es cake_choice_09d11646:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0284.ogg"
    # t "{b}{i}STOP!!{/i}{/b}"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0284.ogg"
    t "{b}{i}¡ALTO!!{/i}{/b}"

# game/script.rpy:5887
translate es cake_choice_f3c97a6f:

    # "The slamming of ancient doors against the walls drown out all the memories in the ballroom, and the illusions disappear without a trace."
    "El golpe de las antiguas puertas contra las paredes ahoga todos los recuerdos en el salón, y las ilusiones desaparecen sin dejar rastro."

# game/script.rpy:5889
translate es cake_choice_7abbffdc:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0268.ogg"
    # e tch forward_lidded_smaller angry "Who—"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0268.ogg"
    e tch forward_lidded_smaller angry "¿Quién—"

# game/script.rpy:5904
translate es cake_choice_60d6a80f:

    # p "Taylor!"
    p "¡Taylor!"

# game/script.rpy:5908
translate es cake_choice_90a4cae7:

    # "Aside from the angry echoing of footsteps, there's only me, Elias, and a very, very sweaty Taylor in this otherwise empty sanctuary."
    "Aparte del eco enojado de los pasos, solo estamos yo, Elias y un Taylor muy, muy sudoroso en este santuario vacío."

# game/script.rpy:5916
translate es cake_choice_70b5dabe:

    # "I have never been so happy to smell his attempts to mask the scent of sweat with overpowering cheap cologne."
    "Nunca había estado tan feliz de oler sus intentos de enmascarar el sudor con colonia barata y demasiado fuerte."

# game/script.rpy:5918
translate es cake_choice_a7b9309a:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0285.ogg"
    # t yell right_half furrowed "That's... *huff* That's right! This has to stop! [your_name], you should have told Elias the truth ages ago!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0285.ogg"
    t yell right_half furrowed "Eso... jadeo ¡Eso es! ¡Esto tiene que parar! [your_name], ¡debiste decirle la verdad a Elias hace muchísimo tiempo!"

# game/script.rpy:5922
translate es cake_choice_9fd2ca43:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0286.ogg"
    # t forward_regular neutral sad "... {i}I{/i} should have told you the truth ages ago..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0286.ogg"
    t forward_regular neutral sad "... {i}Debí{/i} decirte la verdad hace muchísimo tiempo..."

# game/script.rpy:5926
translate es cake_choice_f8930358:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0269.ogg"
    # e forward_lidded_smaller tch "My dear, is this the spirit medium you were talking to?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0269.ogg"
    e forward_lidded_smaller tch "cariño, ¿es este el médium con el que estabas hablando?"

# game/script.rpy:5932
translate es cake_choice_39ebc54c:

    # p "It is. His name is Taylor. Taylor Potts. And—"
    p "Lo es. Se llama Taylor. Taylor Potts. Y—"

# game/script.rpy:5934
translate es cake_choice_4e0c111e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0270.ogg"
    # e right_lidded frown_disapprove angry "Taylor, why do you interrupt our ceremony? Speak now or forever hold your peace!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0270.ogg"
    e right_lidded frown_disapprove angry "Taylor, ¿por qué interrumpes nuestra ceremonia? ¡Habla ahora o calla para siempre!"

# game/script.rpy:5942
translate es cake_choice_0c04bf6f:

    # "Elias' eyes flash with frustration."
    "Los ojos de Elias brillan con frustración."

# game/script.rpy:5944
translate es cake_choice_b7e111e6:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0287.ogg"
    # t furrowed yell "Oh, have I got some words for you, Gallagher! All of this..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0287.ogg"
    t furrowed yell "¡Oh, tengo algunas palabras para ti, Gallagher! Todo esto..."

# game/script.rpy:5950
translate es cake_choice_818536fb:

    # "Taylor gestures wildly around the empty floor and tables."
    "Taylor gesticula salvajemente alrededor del piso y las mesas vacías."

# game/script.rpy:5956
translate es cake_choice_ed1ece28:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0288.ogg"
    # t "All of this is for nothing! This was a dumb attempt to find a ghost and now I've put my best friend in extreme danger."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0288.ogg"
    t "¡Todo esto es en vano! Este fue un intento estúpido de encontrar un fantasma y ahora he puesto a mi mejor amigo en un peligro extremo."

# game/script.rpy:5960
translate es cake_choice_e0b52d68:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0289.ogg"
    # t forward_half upset unamused "[your_name] didn't actually believe anyone was here. In my heart, I didn't believe it either. I was desperate."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0289.ogg"
    t forward_half upset unamused "[your_name] en realidad no creía que hubiera alguien aquí. En mi corazón, yo tampoco lo creía. Estaba desesperado."

# game/script.rpy:5968
translate es cake_choice_bc562ec4:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0290.ogg"
    # t "But we did our homework and read that you were obsessed with romance— the idea of it, at least!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0290.ogg"
    t "¡Pero hicimos nuestra tarea y leímos que estabas obsesionad@ con el romance— al menos con la idea de él!"

# game/script.rpy:5972
translate es cake_choice_bbecfda0:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0291.ogg"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0291.ogg"

# game/script.rpy:5978
translate es cake_choice_47357739:

    # t "[your_name] isn't actually in love with you, and has never been engaged to anyone before this. We went shopping for fancy clothes to trick you into appearing!"
    t ""

# game/script.rpy:5982
translate es cake_choice_7b455218:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0292.ogg"
    # t right_half ugh "So stop all of this. We're too young for marriage! We're both just college students, for goodness' sake! We have our whole lives ahead of us!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0292.ogg"
    t right_half ugh "¡Así que para con todo esto! ¡Somos demasiado jóvenes para casarnos! ¡Somos solo estudiantes universitarios, por Dios! ¡Tenemos toda nuestra vida por delante!"

# game/script.rpy:5990
translate es cake_choice_20772f3a:

    # "Taylor's arms drop to his sides as he takes in a shaky breath."
    "Los brazos de Taylor caen a sus costados mientras respira temblorosamente."

# game/script.rpy:5992
translate es cake_choice_105e8b02:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0293.ogg"
    # t upset right_half "... Elias, you should be mad at me. I set [your_name] up to do all this. [your_name],I should have been the one here, not you."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0293.ogg"
    t upset right_half "... Elias, deberías estar enojado conmigo. Puse a [your_name] en esta situación. [your_name], yo debí haber estado aquí, no tú."

# game/script.rpy:6001
translate es cake_choice_43461289:

    # "I look between both of the men standing in front of me. Taylor is out of breath while Elias can't find the words."
    "Miro entre los dos hombres que están frente a mí. Taylor está sin aliento mientras que Elias no encuentra las palabras."

# game/script.rpy:6007
translate es cake_choice_1c1f1f34:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0294.ogg"
    # t "... I think we should let OHSIC disband. [your_name], we need to go home. It's over."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0294.ogg"
    t "... Creo que deberíamos disolver OHSIC. [your_name], necesitamos ir a casa. Se acabó."

# game/script.rpy:6011
translate es cake_choice_50a3cfb5:

    # p "What? But..."
    p "¿Qué? Pero..."

# game/script.rpy:6019
translate es cake_choice_b3654a73:

    # p "Taylor, don't make decisions for me..."
    p "Taylor, no tomes decisiones por mí..."

# game/script.rpy:6021
translate es cake_choice_328329bc:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0271.ogg"
    # e right_lidded pout concerned "My dear is right. [your_name] has been perfectly able to choose what {0}he{/0}{1}she{/1}{2}they{/2} {0}likes{/0}{1}likes{/1}{2}like{/2}. I've provided plenty of opportunities, and—"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0271.ogg"
    e right_lidded pout concerned "cariño tiene razón. [your_name] ha sido perfectamente capaz de elegir lo que {0}le{/0}{1}le{/1}{2}les{/2} {0}gusta{/0}{1}gusta{/1}{2}gusta{/2}. He proporcionado muchas oportunidades, y—"

# game/script.rpy:6027
translate es cake_choice_763e122b:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0295.ogg"
    # t hmph furrowed right_half "Yeah, and [your_name] was playing you."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0295.ogg"
    t hmph furrowed right_half "Sí, y [your_name] te estaba jugando."

# game/script.rpy:6033
translate es cake_choice_e9cb4fa0:

    # "Taylor's previous fervor gets a second wind at the sound of Elias' voice, and he puffs his chest."
    "El fervor previo de Taylor recibe un segundo aire al escuchar la voz de Elias, y él infla el pecho."

# game/script.rpy:6035
translate es cake_choice_da242a7c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0296.ogg"
    # t right_regular neutral tch "Our goal was to prove you exist. Now we have, and I regret it."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0296.ogg"
    t right_regular neutral tch "Nuestro objetivo era demostrar que existes. Ahora lo hemos hecho, y me arrepiento."

# game/script.rpy:6039
translate es cake_choice_04961f36:

    # p "Taylor—"
    p "Taylor—"

# game/script.rpy:6043
translate es cake_choice_5cf9274f:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0297.ogg"
    # t yell furrowed "Besides, do you even realize what rushing into marriage does to people? What if it turns out that you two don't even {i}like{/i} each other, or can't even stand being in the same room tomorrow!?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0297.ogg"
    t yell furrowed "Además, ¿te das cuenta de lo que hace apresurarse al matrimonio a las personas? ¿Y si resulta que ustedes dos ni siquiera se {i}gustan{/i}, o no pueden soportar estar en la misma habitación mañana!?"

# game/script.rpy:6051
translate es cake_choice_5e37ffaa:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0298.ogg"
    # t "I don't know about you Elias, there's only so many tabloids that we can salvage all the way back from like a hundred years ago, but have you ever had to watch your parents fight with each other behind closed doors!?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0298.ogg"
    t "No sé tú, Elias, solo hay tantos tabloides que podemos rescatar desde hace como cien años, ¡pero alguna vez tuviste que ver a tus padres pelear a puerta cerrada!?"

# game/script.rpy:6059
translate es cake_choice_34b8b91c:

    # "Elias cocks a brow in confusion. All I can do is stand there and listen, trembling."
    "Elias arquea una ceja confundido. Todo lo que puedo hacer es quedarme allí, temblando, escuchando."

# game/script.rpy:6061
translate es cake_choice_90ec4a23:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0299.ogg"
    # t upset furrowed "Rushed, unhappy marriages lead to DIVORCE! Maybe your parents got along fine, maybe they didn't. But if this was a regular wedding between you and [your_name], you'd be waving a red flag for the whole state to see."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0299.ogg"
    t upset furrowed "Matrimonios apresurados e infelices llevan al DIVORCIO! Tal vez tus padres se llevaban bien, tal vez no. Pero si esta fuera una boda normal entre tú y [your_name], estarías ondeando una bandera roja para que todo el estado la vea."

# game/script.rpy:6069
translate es cake_choice_cd24db7f:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0300.ogg"
    # t "Mom and dad tried so hard to pretend that things were okay when I was growing up, but I wasn't stupid. I saw the exhaustion on their faces... I heard what they said to each other..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0300.ogg"
    t "Mamá y papá hicieron todo lo posible por fingir que todo estaba bien mientras crecía, pero no era estupido. Vi el agotamiento en sus rostros... Escuché lo que se decían..."

# game/script.rpy:6075
translate es cake_choice_e3bae773:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0301.ogg"
    # t forward_half ah unamused "No one... deserves that..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0301.ogg"
    t forward_half ah unamused "Nadie... merece eso..."

# game/script.rpy:6079
translate es cake_choice_e3d8c9fb:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0272.ogg"
    # e squiggle forward_lidded_small "I..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0272.ogg"
    e squiggle forward_lidded_small "Yo..."

# game/script.rpy:6085
translate es cake_choice_aeb00eb3:

    # p "I'm sorry, Taylor. I didn't..."
    p "Lo siento, Taylor. No..."

# game/script.rpy:6087
translate es cake_choice_c9066f24:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0302.ogg"
    # t sad "Besides, after all this, I realized..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0302.ogg"
    t sad "Además, después de todo esto, me di cuenta..."

# game/script.rpy:6091
translate es cake_choice_2eb0d6d0:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0303.ogg"
    # t oh furrowed up_half blush "... I'm jealous!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0303.ogg"
    t oh furrowed up_half blush "... ¡Estoy celoso!"

# game/script.rpy:6099
translate es cake_choice_8019e6d6:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0273.ogg"
    # e "... Oh! All this time..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0273.ogg"
    e "... ¡Oh! Todo este tiempo..."

# game/script.rpy:6105
translate es cake_choice_01c0b2b9:

    # p "... Wait, jealous of who?"
    p "... Espera, ¿celoso de quién?"

# game/script.rpy:6107
translate es cake_choice_cc42f0c6:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0274.ogg"
    # e forward_lidded_regular angry unsure -sweat "Me, I assume. There's a rival suitor vying for your affections."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0274.ogg"
    e forward_lidded_regular angry unsure -sweat "De mí, supongo. Hay un rival que compite por tu afecto."

# game/script.rpy:6111
translate es cake_choice_f6c531af:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0304.ogg"
    # t forward_regular normal raised "It's true. [your_name], I think you're great and I really, {i}really{/i} like you."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0304.ogg"
    t forward_regular normal raised "Es verdad. [your_name], creo que eres genial y realmente, {i}realmente{/i} me gustas."

# game/script.rpy:6118
translate es cake_choice_ae214f58:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0305.ogg"
    # t "I've wanted to tell you that for some time. Since about the day we met, to be honest."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0305.ogg"
    t "He querido decirte eso desde hace tiempo. Desde el día en que nos conocimos, para ser honesto."

# game/script.rpy:6126
translate es cake_choice_5b43e583:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0306.ogg"
    # t "But you were such a good friend! A kind friend who supported me in everything I did."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0306.ogg"
    t "¡Pero eras tan buen amig@! Un@ amig@ amable que me apoyaba en todo lo que hacía."

# game/script.rpy:6134
translate es cake_choice_546ea003:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0307.ogg"
    # t "I... I was scared to lose that. I was scared to make everything too big."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0307.ogg"
    t "Yo... Tenía miedo de perder eso. Tenía miedo de que todo se hiciera demasiado grande."

# game/script.rpy:6138
translate es cake_choice_f54a098c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0308.ogg"
    # t forward_half frown "But I guess I found a different way to make everything too big tonight, huh?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0308.ogg"
    t forward_half frown "Pero supongo que encontré una forma diferente de hacer que todo sea demasiado grande esta noche, ¿eh?"

# game/script.rpy:6142
translate es cake_choice_d9e14514:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0275.ogg"
    # e closed_sad ah_sad "What a charming and sad story, Taylor."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0275.ogg"
    e closed_sad ah_sad "Qué historia tan encantadora y triste, Taylor."

# game/script.rpy:6148
translate es cake_choice_5a1fbb83:

    # "Much to my surprise, Elias' voice drips with empathy. His words are genuine."
    "Para mi sorpresa, la voz de Elias gotea empatía. Sus palabras son genuinas."

# game/script.rpy:6150
translate es cake_choice_f8816046:

    # p "Elias? You're..."
    p "¿Elias? Tú..."

# game/script.rpy:6152
translate es cake_choice_eb687a90:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0276.ogg"
    # e forward_heart blush sad unsure "How could I not be moved?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0276.ogg"
    e forward_heart blush sad unsure "¿Cómo no iba a emocionarme?"

# game/script.rpy:6160
translate es cake_choice_e9f31f73:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0277.ogg"
    # e "But my dear [your_name], I need you to tell me the truth."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0277.ogg"
    e "Pero cariño [your_name], necesito que me digas la verdad."

# game/script.rpy:6166
translate es cake_choice_df50181f:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0278.ogg"
    # e concerned forward_lidded_regular frown_small "What did {i}you{/i} come here for?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0278.ogg"
    e concerned forward_lidded_regular frown_small "¿Por qué {i}viniste{/i} aquí?"

# game/script.rpy:6172
translate es cake_choice_246383e8:

    # p "I came here to help Taylor find a ghost. Our ghost hunting group was in danger of closing, and we decided to investigate this place."
    p "Vine para ayudar a Taylor a encontrar un fantasma. Nuestro grupo de caza de fantasmas estaba en peligro de cerrar, y decidimos investigar este lugar."

# game/script.rpy:6176
translate es cake_choice_b23c4f26:

    # p "We... knew people broke into this place pretty often, and no one ever actually claimed to {i}see{/i} any ghosts... so we decided to do what we could to make you appear..."
    p "Sabíamos... que la gente entraba a este lugar con frecuencia, y nadie jamás afirmó {i}haber visto{/i} fantasmas... así que decidimos hacer lo que pudiéramos para que aparecieras..."

# game/script.rpy:6182
translate es cake_choice_ac2c33b4:

    # p "Nothing I told you about the previous wedding was true. I wasn't left at the altar. I was never even {i}at{/i} the altar. I am just an ordinary university student trying to help a friend."
    p "Nada de lo que te dije sobre la boda anterior era cierto. No me dejaron en el altar. Ni siquiera estuve {i}en{/i} el altar. Solo soy un@ estudiante universitar@ ordinari@ tratando de ayudar a un amigo."

# game/script.rpy:6190
translate es cake_choice_aa839f53:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0279.ogg"
    # e "... I see."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0279.ogg"
    e "... Entiendo."

# game/script.rpy:6194
translate es cake_choice_833f9a0f:

    # "There it is, the truth is out. I suppose it had to happen sometime."
    "Ahí está, la verdad salió. Supongo que tenía que pasar en algún momento."

# game/script.rpy:6201
translate es cake_choice_fc2c7802:

    # "If Elias could sink into the center of the earth, he probably would. The only thing keeping him afloat is some sense of decorum."
    "Si Elias pudiera hundirse en el centro de la tierra, probablemente lo haría. Lo único que lo mantiene a flote es un cierto sentido del decoro."

# game/script.rpy:6208
translate es cake_choice_d4957d0c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0280.ogg"
    # e "But not all of this was a lie, was it?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0280.ogg"
    e "Pero no todo esto era mentira, ¿verdad?"

# game/script.rpy:6218
translate es cake_choice_6f350ee1:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0281.ogg"
    # e "Your demeanor changed as we spent time together."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0281.ogg"
    e "Tu comportamiento cambió mientras pasábamos tiempo juntos."

# game/script.rpy:6222
translate es cake_choice_a484ec54:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0282.ogg"
    # e sweat closed_sad frown_disapprove "You got to know me. You learned about the real me. And I think your heart opened."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0282.ogg"
    e sweat closed_sad frown_disapprove "Me conociste. Aprendiste sobre mi yo real. Y creo que tu corazón se abrió."

# game/script.rpy:6230
translate es cake_choice_d59c4c0c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0309.ogg"
    # t "Oh no. Come on, don't do this. I get that you're lonely, but you're completely missing the point here!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0309.ogg"
    t "Oh no. Vamos, no hagas esto. Entiendo que estés sol@, ¡pero estás perdiendo completamente el punto!"

# game/script.rpy:6240
translate es cake_choice_683173e5:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0283.ogg"
    # e "Taylor, please. Where we go from here... is up to [your_name] to decide."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0283.ogg"
    e "Taylor, por favor. Lo que hagamos a partir de ahora... depende de que [your_name] decida."

# game/script.rpy:6248
translate es cake_choice_300701d2_1:

    # p "I..."
    p "Yo..."

# game/script.rpy:6255
translate es cake_choice_51c83187:

    # p "Elias, first I have a question for you."
    p "Elias, primero tengo una pregunta para ti."

# game/script.rpy:6257
translate es cake_choice_5f2bd739:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0284.ogg"
    # e forward_regular neutral oh_sad -sweat "Then I shall do my best to answer."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0284.ogg"
    e forward_regular neutral oh_sad -sweat "Entonces haré mi mejor esfuerzo para responder."

# game/script.rpy:6265
translate es cake_choice_03f7b917:

    # p "Do you know what caused the curse behind the death of your family?"
    p "¿Sabes qué causó la maldición detrás de la muerte de tu familia?"

# game/script.rpy:6267
translate es cake_choice_f1d7078a:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0285.ogg"
    # e closed_sad sad unsure "... I... do not, no."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0285.ogg"
    e closed_sad sad unsure "... Yo... no, no lo sé."

# game/script.rpy:6275
translate es cake_choice_19590de7:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0286.ogg"
    # e "None of the deaths were connected, at least not to my knowledge, and contrary to popular belief I did not orchestrate those accidents. I'm not a cruel person, and I hope you can at least attest to that after tonight."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0286.ogg"
    e "Ninguna de las muertes estaba conectada, al menos que yo sepa, y contrario a la creencia popular no orquesté esos accidentes. No soy una persona cruel, y espero que al menos puedas dar fe de eso después de esta noche."

# game/script.rpy:6281
translate es cake_choice_2cc54711:

    # p "I never said that you were, Elias. But Taylor and I had some theories."
    p "Nunca dije que lo fueras, Elias. Pero Taylor y yo teníamos algunas teorías."

# game/script.rpy:6283
translate es cake_choice_4bf4f92f:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0310.ogg"
    # t forward_small oh "We did?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0310.ogg"
    t forward_small oh "¿Sí?"

# game/script.rpy:6291
translate es cake_choice_9637edc2:

    # "I elbow him in the side and roll my eyes."
    "Le doy un codazo y pongo los ojos en blanco."

# game/script.rpy:6293
translate es cake_choice_d6670a24:

    # p "Elias, I saw glimpses into your past tonight. Wisps of memories that allowed me to feel your emotions."
    p "Elias, esta noche vi destellos de tu pasado. Retazos de recuerdos que me permitieron sentir tus emociones."

# game/script.rpy:6295
translate es cake_choice_f4a09925:

    # e forward_small "..."
    e forward_small "..."

# game/script.rpy:6299
translate es cake_choice_d422dc6f:

    # p "And two things stood out to me. The first was Violet, and how uneasy you felt whenever she was around. Memories involving her would leave me disoriented and scared for my life."
    p "Y dos cosas destacaron para mí. La primera fue Violet, y lo incómodo que te sentías cada vez que estaba cerca. Los recuerdos con ella me dejaban desorientad@ y temiendo por mi vida."

# game/script.rpy:6301
translate es cake_choice_4a56cc1d:

    # p "The second was you yourself, talking about the shattered mirror with your father."
    p "La segunda fuiste tú mismo, hablando sobre el espejo roto con tu padre."

# game/script.rpy:6307
translate es cake_choice_c6d06b4a:

    # "At the mention of the mirror, both of the men fix their posture."
    "Al mencionar el espejo, ambos hombres enderezan la postura."

# game/script.rpy:6309
translate es cake_choice_cc0461b1:

    # p "I felt your frustration, like I was suffocating. I hated it."
    p "Sentí tu frustración, como si me estuviera asfixiando. Lo odié."

# game/script.rpy:6315
translate es cake_choice_7c74eca4:

    # p "Breaking a mirror is bad luck in a lot of cultures. When you showed me the shards in your room, you told me that all of your siblings blamed you for shattering it."
    p "Romper un espejo trae mala suerte en muchas culturas. Cuando me mostraste los fragmentos en tu habitación, dijiste que todos tus hermanos te culparon por romperlo."

# game/script.rpy:6321
translate es cake_choice_6f43a096:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0287.ogg"
    # e "Yes... I was simply admiring myself in the mirror's reflection when they came to snatch it out of my hands. I tried to keep it safe as it belonged to my grandmother, but..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0287.ogg"
    e "Sí... Solo estaba admirándome en el reflejo del espejo cuando vinieron a arrebatármelo. Traté de mantenerlo a salvo ya que pertenecía a mi abuela, pero..."

# game/script.rpy:6325
translate es cake_choice_2c617de0:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0311.ogg"
    # t right_regular unamused tch "Six versus one isn't very fair. And your parents probably didn't side with you on this, did they?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0311.ogg"
    t right_regular unamused tch "Seis contra uno no es muy justo. Y probablemente tus padres no se pusieron de tu lado, ¿verdad?"

# game/script.rpy:6333
translate es cake_choice_f746978a:

    # "Elias shakes his head, the gears turning in his brain."
    "Elias niega con la cabeza, pensando intensamente."

# game/script.rpy:6335
translate es cake_choice_dcf151a9:

    # p "In addition, that mirror was meant to be a wedding gift, wasn't it? It was never gifted to any of your siblings' spouses because it was broken, and your father didn't bother to repair it."
    p "Además, ese espejo debía ser un regalo de bodas, ¿no? Nunca se lo dieron a los esposos de tus hermanos porque estaba roto, y tu padre no se molestó en repararlo."

# game/script.rpy:6341
translate es cake_choice_a0b8f8a8:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0288.ogg"
    # e closed_sad sad "So then... the curse..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0288.ogg"
    e closed_sad sad "Entonces... la maldición..."

# game/script.rpy:6345
translate es cake_choice_283f21fe:

    # p "I think your strong feelings towards that mirror inadvertently caused your family to become cursed."
    p "Creo que tus fuertes sentimientos hacia ese espejo provocaron inadvertidamente que tu familia quedara maldita."

# game/script.rpy:6347
translate es cake_choice_8a145958:

    # p "... That uh, that does make sense, right Taylor?"
    p "... Eso, eh, tiene sentido, ¿verdad Taylor?"

# game/script.rpy:6349
translate es cake_choice_694ed438:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0312.ogg"
    # t up_regular ah raised "I um... Yeah, yeah, I guess that's enough of an explanation as any."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0312.ogg"
    t up_regular ah raised "Yo, um... Sí, sí, supongo que esa explicación es suficiente."

# game/script.rpy:6357
translate es cake_choice_37f25629:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0289.ogg"
    # e "Then even my own death at the hands of the Duponts was part of the curse's doing, just as I thought..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0289.ogg"
    e "Entonces incluso mi propia muerte a manos de los Dupont fue parte de la maldición, como pensé..."

# game/script.rpy:6365
translate es cake_choice_e4e9febe:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0313.ogg"
    # t "Actually, if we go by [your_name]'s explanation, I don't think Violet Dupont jamming a dagger into your neck was because of the curse."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0313.ogg"
    t "En realidad, si vamos por la explicación de [your_name], no creo que Violet Dupont clavando una daga en tu cuello fuera por la maldición."

# game/script.rpy:6373
translate es cake_choice_523452aa:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0314.ogg"
    # t "You two technically weren't even married yet, and that whole stabbity-stab thing was a textbook example of premeditated murder. You know, the opposite of a fatal {i}accident{/i}?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0314.ogg"
    t "Técnicamente ustedes dos ni siquiera estaban casados aún, y todo ese asunto de apuñalar fue un ejemplo clásico de asesinato premeditado. Ya sabes, lo opuesto a un {i}accidente{/i} fatal."

# game/script.rpy:6381
translate es cake_choice_227003ee:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0315.ogg"
    # t "You were so desperate for love that you ignored your gut instinct about something feeling {i}off{/i} with Violet the entire time."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0315.ogg"
    t "Estabas tan desesperado por amor que ignoraste tu instinto sobre que algo se sentía {i}mal{/i} con Violet todo el tiempo."

# game/script.rpy:6391
translate es cake_choice_baf63886:

    # "Elias looks down at his hands, then at the floor, despondent and on the brink of tears."
    "Elias mira sus manos, luego al suelo, desanimado y al borde de las lágrimas."

# game/script.rpy:6393
translate es cake_choice_2165662c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0290.ogg"
    # e closed_sad oh_disapprove "I... I see. So if I were to carry on with the wedding and marry [your_name], then {0}he{/0}{1}she{/1}{2}they{/2} too would die of the curse."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0290.ogg"
    e closed_sad oh_disapprove "Yo... Entiendo. Entonces, si continuara con la boda y me casara con [your_name], entonces {0}él{/0}{1}ella{/1}{2}elle{/2} también moriría por la maldición."

# game/script.rpy:6397
translate es cake_choice_19550922:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0291.ogg"
    # e forward_lidded_smaller ugh "If that's the case, then I'll never have my wedding... even in death..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0291.ogg"
    e forward_lidded_smaller ugh "Si ese es el caso, nunca tendré mi boda... ni siquiera en la muerte..."

# game/script.rpy:6407
translate es cake_choice_19ce49c4:

    # "The room is silent as Elias reaches this realization. I feel so bad, but I don't want to die for his sake."
    "La habitación está en silencio mientras Elias llega a esa realización. Me siento tan mal, pero no quiero morir por su bien."

# game/script.rpy:6409
translate es cake_choice_1197c0f4:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0316.ogg"
    # t right_half raised @ oho "... Hang on, I think I have an idea."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0316.ogg"
    t right_half raised @ oho "... Espera, creo que tengo una idea."

# game/script.rpy:6413
translate es cake_choice_697f94c6:

    # p "About what?"
    p "¿Sobre qué?"

# game/script.rpy:6419
translate es cake_choice_1520db8b:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0317.ogg"
    # t "If we're right about the mirror needing to fulfill its purpose as a wedding gift, then all Elias needs to do is {i}give{/i} you the mirror after the ceremony."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0317.ogg"
    t "Si estamos en lo cierto sobre que el espejo necesita cumplir su propósito como regalo de bodas, entonces todo lo que Elias necesita hacer es {i}darte{/i} el espejo después de la ceremonia."

# game/script.rpy:6427
translate es cake_choice_3337bfc7:

    # p "... I'm sorry?"
    p "... ¿Perdón?"

# game/script.rpy:6429
translate es cake_choice_e3bfcec9:

    # "I gawk at Taylor and his sudden change of heart. I thought he didn't want me to marry Elias?"
    "Miro a Taylor con asombro por su repentino cambio de actitud. Pensé que no quería que me casara con Elias."

# game/script.rpy:6435
translate es cake_choice_0681abf2:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0318.ogg"
    # t "Elias, I'm really sorry for shouting at you when I burst in. I was venting about a lot of personal stuff that doesn't remotely involve you, and... you didn't deserve that."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0318.ogg"
    t "Elias, lamento mucho haberte gritado cuando irrumpí. Estaba desahogándome sobre muchas cosas personales que no te involucraban, y... no te lo merecías."

# game/script.rpy:6439
translate es cake_choice_f6c7200c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0319.ogg"
    # t forward_half ah "And [your_name], I never should have forced your hand into doing the field mission for me. At the very least, I should have come sooner to provide backup."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0319.ogg"
    t forward_half ah "Y [your_name], nunca debí haberte obligado a hacer la misión de campo por mí. Al menos, debí haber venido antes para dar apoyo."

# game/script.rpy:6443
translate es cake_choice_426694fb:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0320.ogg"
    # t forward_regular raised ugh -sweat "But if you two trust me on this, and you're willing to try, everyone can have their happy ending. At least... I'm like... 95%% sure this will work."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0320.ogg"
    t forward_regular raised ugh -sweat "Pero si confían en mí sobre esto, y están dispuestos a intentar, todos pueden tener su final feliz. Al menos... estoy como... 95%% seguro de que esto funcionará."

# game/script.rpy:6447
translate es cake_choice_50b59919:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0292.ogg"
    # e forward_small upset_open happy "But weren't you opposed to our union?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0292.ogg"
    e forward_small upset_open happy "¿Pero no estabas en contra de nuestra unión?"

# game/script.rpy:6455
translate es cake_choice_643e1d45:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0321.ogg"
    # t "Maybe [your_name] did get to know you better tonight. I shouldn't tell {0}him{/0}{1}her{/1}{2}them{/2} what decision to make."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0321.ogg"
    t "Tal vez [your_name] realmente te conoció mejor esta noche. No debo decirle a {0}él{/0}{1}ella{/1}{2}elle{/2} qué decisión tomar."

# game/script.rpy:6459
translate es cake_choice_98244d6c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0322.ogg"
    # t forward_regular normal -unamused "So, as you said, let {0}him{/0}{1}her{/1}{2}them{/2} decide."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0322.ogg"
    t forward_regular normal -unamused "Así que, como dijiste, dejemos que {0}él{/0}{1}ella{/1}{2}elle{/2} decida."

# game/script.rpy:6467
translate es cake_choice_3aa6fded:

    # "They both look at me expectantly."
    "Ambos me miran expectantes."

# game/script.rpy:6469
translate es cake_choice_182850f0:

    # p "Elias, I love you as much as I could ever love a friend."
    p "Elias, te amo tanto como podría amar a un amigo."

# game/script.rpy:6475
translate es cake_choice_f6fcd9d4:

    # p "It may not be the love you crave, but if you'll still have me... if it helps to break the curse... to finally free your soul... I will accept your hand."
    p "Puede que no sea el amor que anhelas, pero si aún me aceptas... si ayuda a romper la maldición... a liberar finalmente tu alma... aceptaré tu mano."

# game/script.rpy:6477
translate es cake_choice_b9d17760:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0293.ogg"
    # e @ ah_sad "I..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0293.ogg"
    e @ ah_sad "Yo..."

# game/script.rpy:6481
translate es cake_choice_e8ddc74f:

    # "My groom's face alights with a sad smile."
    "El rostro de mi prometido se ilumina con una sonrisa triste."

# game/script.rpy:6489
translate es cake_choice_8ccaeb42:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0294.ogg"
    # e "Yes, I suppose your hand in marriage is all that I had asked of you when we first met, [your_name]. And so, I graciously accept this arrangement."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0294.ogg"
    e "Sí, supongo que tu mano en matrimonio es todo lo que pedí cuando nos conocimos, [your_name]. Y así, acepto gustosamente este acuerdo."

# game/script.rpy:6497
translate es cake_choice_a22d0d79:

    # "We both turn to face Taylor."
    "Ambos nos volvemos para mirar a Taylor."

# game/script.rpy:6499
translate es cake_choice_55f33bba:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0323.ogg"
    # t "Do you, [your_name], take Elias Gallagher to be your lawfully wedded husband; to live together in matrimony, to love him, comfort him, honor and keep him..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0323.ogg"
    t "¿Aceptas, [your_name], a Elias Gallagher como tu legítimo esposo; para vivir juntos en matrimonio, amarlo, confortarlo, honrarlo y cuidarlo..."

# game/script.rpy:6507
translate es cake_choice_96ddc4eb:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0324.ogg"
    # t "In sickness and in health, in sorrow and in joy, to have and to hold, from this day forward, as long as you both shall exist on this plane of existence?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0324.ogg"
    t "En la enfermedad y en la salud, en la tristeza y en la alegría, tener y sostener, desde este día en adelante, mientras ambos existan en este plano de existencia?"

# game/script.rpy:6511
translate es cake_choice_7988a01b:

    # p "I do."
    p "Sí, lo hago."

# game/script.rpy:6517
translate es cake_choice_2c1b71f9:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0325.ogg"
    # t "And do you, Elias, take [your_name] to be your lawfully wedded... yadda yadda, et cetera et cetera, as long as you both shall exist on this plane of existence?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0325.ogg"
    t "Y tú, Elias, ¿aceptas a [your_name] como tu legítim@... yadda yadda, etcétera, mientras ambos existan en este plano de existencia?"

# game/script.rpy:6523
translate es cake_choice_b8ed1dd8:

    # "Elias shoots Taylor a disappointed look for ruining the mood, sighing."
    "Elias lanza a Taylor una mirada decepcionada por arruinar el momento, suspirando."

# game/script.rpy:6529
translate es cake_choice_de24c76f:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0295.ogg"
    # e "... I do."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0295.ogg"
    e "... Sí, quiero."

# game/script.rpy:6533
translate es cake_choice_57cf9c71:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0326.ogg"
    # t "By the authority vested in me as the official President of the Occult History & Sciences Investigation Club, I now pronounce you married!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0326.ogg"
    t "Por la autoridad que me confiere ser el Presidente oficial del Club de Investigación de Historia y Ciencias Ocultas, ¡ahora los declaro casados!"

# game/script.rpy:6543
translate es cake_choice_c416cb8d:

    # "Taylor erupts into an applause that echoes throughout the ballroom, accentuated by leftover spirits Elias has summoned while the man himself kisses me swiftly on the cheek."
    "Taylor estalla en aplausos que resuenan por todo el salón, acentuados por los espíritus residuales que Elias ha convocado mientras el propio hombre me da un rápido beso en la mejilla."

# game/script.rpy:6545
translate es cake_choice_a2e87150:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0296.ogg"
    # e "And now, [your_name], all that I possessed in my mortal years belongs to you."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0296.ogg"
    e "Y ahora, [your_name], todo lo que poseí en mis años mortales te pertenece."

# game/script.rpy:6549
translate es cake_choice_857cdba5:

    # p "It uh, it does?"
    p "¿Eh, en serio?"

# game/script.rpy:6551
translate es cake_choice_bb5cd326:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0297.ogg"
    # e "Yes. Please come with me to the study. Quickly now."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0297.ogg"
    e "Sí. Por favor, acompáñame al estudio. Rápido ahora."

# game/script.rpy:6559
translate es cake_choice_248a4d4e:

    # "We all collectively exit the ballroom and follow Elias' lead to the study. Taylor lags behind a bit, but I pull on his sleeve before he falls behind and gets lost wandering the halls of the manor."
    "Todos salimos colectivamente del salón y seguimos a Elias hacia el estudio. Taylor se queda un poco atrás, pero tiro de su manga antes de que se pierda vagando por los pasillos de la mansión."

# game/script.rpy:6568
translate es cake_choice_df97b7f6:

    # "Elias pulls out a paper from the drawer and clasps his hands together, causing it to glow with a ghostly light."
    "Elias saca un papel del cajón y junta las manos, haciendo que brille con una luz fantasmal."

# game/script.rpy:6572
translate es cake_choice_c0c77029:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0298.ogg"
    # e forward_regular normal happy "Here we are! My will, freshly written. With this, the mirror has been transferred into your possession, my beloved [your_name]."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0298.ogg"
    e forward_regular normal happy "¡Aquí estamos! Mi testamento, recién escrito. Con esto, el espejo ha sido transferido a tu posesión, mi amado/a [your_name]."

# game/script.rpy:6578
translate es cake_choice_26774eda:

    # "Taylor and I scan the document."
    "Taylor y yo revisamos el documento."

# game/script.rpy:6580
translate es cake_choice_0aba6020:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0327.ogg"
    # t ah forward_regular furrowed "\"I, Elias Gallagher, former head of the Gallagher estate... hereby leave all my material possessions, including the Gallagher family jewels... and the manor itself to my beloved partner...\""
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0327.ogg"
    t ah forward_regular furrowed "\"Yo, Elias Gallagher, exjefe de la finca Gallagher... por la presente dejo todas mis posesiones materiales, incluyendo las joyas de la familia Gallagher... y la mansión misma a mi amado compañero...\""

# game/script.rpy:6584
translate es cake_choice_5891bc6c:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0328.ogg"
    # t smirk raised "I mean, a will written by a ghost would never hold up in court, but for the sake of breaking the curse I {i}think{/i} this should work?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0328.ogg"
    t smirk raised "Quiero decir, un testamento escrito por un fantasma nunca tendría validez en un tribunal, pero para romper la maldición creo que {i}esto{/i} debería funcionar."

# game/script.rpy:6588
translate es cake_choice_2bf45a23:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0299.ogg"
    # e grin_teeth "It will."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0299.ogg"
    e grin_teeth "Lo hará."

# game/script.rpy:6599
translate es cake_choice_9d07a927:

    # "Elias floats away from us with a complacent smile on his face."
    "Elias se aleja flotando de nosotros con una sonrisa satisfecha en el rostro."

# game/script.rpy:6601
translate es cake_choice_6061afca:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0300.ogg"
    # e forward_lidded_regular oh_annoyed neutral "My wish for a wedding of my own has finally been fulfilled. And now, it is time for me to depart from this world."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0300.ogg"
    e forward_lidded_regular oh_annoyed neutral "Mi deseo de tener una boda propia finalmente se ha cumplido. Y ahora, es hora de que me despida de este mundo."

# game/script.rpy:6605
translate es cake_choice_a7ed5556:

    # p "Are you sure? But we just met! I never got the chance to really get to know you, and..."
    p "¿Estás seguro? ¡Pero recién nos conocimos! Nunca tuve la oportunidad de conocerte realmente, y..."

# game/script.rpy:6609
translate es cake_choice_b2def1a8:

    # "He holds a hand up to stop me."
    "Él levanta una mano para detenerme."

# game/script.rpy:6615
translate es cake_choice_a3629d02:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0301.ogg"
    # e "[your_name]... I am an ancient relic of decades long since passed; a memory of a life tethered to this land. But now that I am married to you, I am free."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0301.ogg"
    e "[your_name]... Soy una reliquia antigua de décadas ya pasadas; un recuerdo de una vida atada a esta tierra. Pero ahora que estoy casado contigo, soy libre."

# game/script.rpy:6623
translate es cake_choice_baa23b04:

    # "Elias casts a sideway glance at Taylor."
    "Elias dirige una mirada de reojo a Taylor."

# game/script.rpy:6625
translate es cake_choice_a768baf8:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0302.ogg"
    # e frown_disapprove angry "Mr. Taylor Potts."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0302.ogg"
    e frown_disapprove angry "Sr. Taylor Potts."

# game/script.rpy:6633
translate es cake_choice_130d8cfb:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0329.ogg"
    # t "Y-yeah?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0329.ogg"
    t "S-sí?"

# game/script.rpy:6641
translate es cake_choice_e93310f4:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0303.ogg"
    # e "Take good care of [your_name] in my stead. If you make {0}him{/0}{1}her{/1}{2}them{/2} sad..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0303.ogg"
    e "Cuida bien de [your_name] en mi lugar. Si haces que {0}él{/0}{1}ella{/1}{2}elle{/2} se sienta triste..."

# game/script.rpy:6647
translate es cake_choice_91d8e97e:

    # "Elias' lips break into a sly smile."
    "Los labios de Elias se curvan en una sonrisa astuta."

# game/script.rpy:6649
translate es cake_choice_09c21a45:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0304.ogg"
    # e grin_teeth left_lidded "... I may come back to haunt you."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0304.ogg"
    e grin_teeth left_lidded "... podría volver para perseguirte."

# game/script.rpy:6658
translate es cake_choice_17ef70fb:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0330.ogg"
    # t "I plan on it! The uh, taking care of [your_name], part.\n... Please don't haunt me."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0330.ogg"
    t "¡Eso planeo! La parte de, eh, cuidar de [your_name].\n... Por favor, no me persigas."

# game/script.rpy:6666
translate es cake_choice_7f2a8314:

    # "Elias chuckles."
    "Elias se ríe."

# game/script.rpy:6672
translate es cake_choice_288c993d:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0305.ogg"
    # e lipbite_small "Very well."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0305.ogg"
    e lipbite_small "Muy bien."

# game/script.rpy:6683
translate es cake_choice_35ee7cb0:

    # "Elias takes my hand one last time."
    "Elias toma mi mano por última vez."

# game/script.rpy:6685
translate es cake_choice_7b5d05ec:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0306.ogg"
    # e "Live and prosper where I could not."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0306.ogg"
    e "Vive y prospera donde yo no pude."

# game/script.rpy:6691
translate es cake_choice_8d7b91d0:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0307.ogg"
    # e "Farewell my love, may we meet again in heaven."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0307.ogg"
    e "Adiós, mi amor, que nos encontremos nuevamente en el cielo."

# game/script.rpy:6703
translate es cake_choice_a308bdcf:

    # p "Goodbye, Elias Gallagher. Thank you for everything."
    p "Adiós, Elias Gallagher. Gracias por todo."

# game/script.rpy:6710
translate es cake_choice_5884619c:

    # "With a final bow, Elias slowly fades from the room."
    "Con una última reverencia, Elias desaparece lentamente de la habitación."

# game/script.rpy:6718
translate es cake_choice_1bb01731:

    # t "..."
    t "..."

# game/script.rpy:6722
translate es cake_choice_c8ea8a4a:

    # p "..."
    p "..."

# game/script.rpy:6724
translate es cake_choice_08efd5ff:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0331.ogg"
    # t raised oh "So uh, is your last name really gonna be Gallagher now?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0331.ogg"
    t raised oh "Entonces, eh, ¿tu apellido será realmente Gallagher ahora?"

# game/script.rpy:6728
translate es cake_choice_f55d213b:

    # p "Taylor, why do you always kill the mood?"
    p "Taylor, ¿por qué siempre arruinas el ambiente?"

# game/script.rpy:6732
translate es cake_choice_29c67345:

    # "After a full 24 hours of uninterrupted sleep, Taylor looked up whether my surname actually was legally going to be Gallagher now."
    "Después de un sueño ininterrumpido de 24 horas, Taylor investigó si mi apellido legalmente iba a ser Gallagher ahora."

# game/script.rpy:6734
translate es cake_choice_d936d87e:

    # "Turns out that if both spouses don't sign a marriage certificate, you can't be legally wed... Not in this day and age. So the last name thing doesn't actually matter in the long run."
    "Resulta que si ambos cónyuges no firman el certificado de matrimonio, no se puede estar legalmente casado... No en estos tiempos. Así que lo del apellido realmente no importa a largo plazo."

# game/script.rpy:6736
translate es cake_choice_5c863a31:

    # "Hopefully Elias wasn't going to be too mad about that."
    "Espero que Elias no se enoje demasiado por eso."

# game/script.rpy:6738
translate es cake_choice_09d26c12:

    # "After doctoring the will a bit, we laid claim to the fortunes left in the Gallagher Mansion. And as it turns out, they kept more than just the family jewels in there..."
    "Después de modificar un poco el testamento, reclamamos las fortunas dejadas en la Mansión Gallagher. Y resulta que no solo guardaban las joyas familiares allí..."

# game/script.rpy:6744
translate es cake_choice_c75f1968:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0332.ogg"
    # t "Holy cannoli, we're rich!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0332.ogg"
    t "¡Santo cielo, somos ricos!"

# game/script.rpy:6750
translate es cake_choice_0129e4ae:

    # p "{i}I'm{/i} rich, and I'm just redistributing the wealth to you."
    p "{i}Soy{/i} rico, y solo estoy redistribuyendo la riqueza hacia ti."

# game/script.rpy:6754
translate es cake_choice_455da291:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0333.ogg"
    # t "Who cares about the details? We can repair the entire mansion and like, actually live in it! And then we don't have to pay rent!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0333.ogg"
    t "¿Quién se preocupa por los detalles? ¡Podemos reparar toda la mansión y realmente vivir en ella! ¡Y además no tendríamos que pagar renta!"

# game/script.rpy:6760
translate es cake_choice_1fb33f8c:

    # p "That's... very true, actually. Damn, maybe I should marry more ghosts to inherit their estates."
    p "Eso... es muy cierto, en realidad. Maldición, tal vez debería casarme con más fantasmas para heredar sus propiedades."

# game/script.rpy:6764
translate es cake_choice_26ec330b:

    # "While we were so caught up in legal matters that we forgot to recruit members for the OHSIC, Taylor and I would go on to clear Elias' name of any wrongdoing in the local legends. It only felt right after all he did for us."
    "Mientras estábamos tan concentrados en asuntos legales que olvidamos reclutar miembros para el OHSIC, Taylor y yo nos encargamos de limpiar el nombre de Elias de cualquier mala reputación en las leyendas locales. Solo se sentía correcto después de todo lo que hizo por nosotros."

# game/script.rpy:6766
translate es cake_choice_83685d08:

    # "And so we spent a small fraction of my new fortune repairing the mansion and the antique mirror to its former glory, and spent the rest of our college days rent-free."
    "Y así, gastamos una pequeña fracción de mi nueva fortuna reparando la mansión y el espejo antiguo a su antigua gloria, y pasamos el resto de nuestros días universitarios sin pagar renta."

# game/script.rpy:6770
translate es cake_choice_bb340053:

    # centered "{size=+150}{font=gui/font/Awugh.otf}Ending A\nFor The Truth{/font}{/size}" with dissolve
    centered "{size=+150}{font=gui/font/Awugh.otf}Final A\nPor La Verdad{/font}{/size}" with dissolve

# game/script.rpy:6790
translate es cake_choice_f021d5ea:

    # p "... Thank you, Elias, for giving me a choice."
    p "... Gracias, Elias, por darme una elección."

# game/script.rpy:6792
translate es cake_choice_28c6467d:

    # p "I ask for your forgiveness. I can't say that I didn't mean to deceive you, but I regret it."
    p "Te pido perdón. No puedo decir que no quise engañarte, pero lo lamento."

# game/script.rpy:6798
translate es cake_choice_cbe59168:

    # p "Although I don't regret meeting you. I only wish it could have happened under better circumstances."
    p "Aunque no lamento haberte conocido. Solo deseo que hubiera ocurrido en mejores circunstancias."

# game/script.rpy:6804
translate es cake_choice_ece25f10:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0308.ogg"
    # e "I can't say that it doesn't hurt. I'm not sure if I will ever see you in the same way again."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0308.ogg"
    e "No puedo decir que no duela. No estoy seguro de si alguna vez volveré a verte de la misma manera."

# game/script.rpy:6808
translate es cake_choice_5ccc8d90:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0309.ogg"
    # e forward_lidded_regular ah_sad "And yet, I am glad we met as well."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0309.ogg"
    e forward_lidded_regular ah_sad "Y, sin embargo, me alegra que nos hayamos conocido."

# game/script.rpy:6816
translate es cake_choice_3529efac:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0310.ogg"
    # e "This day... It was perhaps the best day of my life... and death."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0310.ogg"
    e "Este día... Quizás fue el mejor día de mi vida... y de mi muerte."

# game/script.rpy:6824
translate es cake_choice_cf0d4bbf:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0311.ogg"
    # e "I hate that it must end this way."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0311.ogg"
    e "Odio que deba terminar así."

# game/script.rpy:6828
translate es cake_choice_78b0fd5e:

    # p "Must it?"
    p "¿Debe?"

# game/script.rpy:6836
translate es cake_choice_3c9faa6e:

    # p "You were also correct when you said I got to truly know you. And you've been nothing but kind and loving towards me this whole time."
    p "También tenías razón cuando dijiste que llegué a conocerte verdaderamente. Y has sido nada más que amable y amoroso conmigo todo este tiempo."

# game/script.rpy:6842
translate es cake_choice_d231e846:

    # p "I... I do want to be with you, Elias."
    p "Yo... sí quiero estar contigo, Elias."

# game/script.rpy:6844
translate es cake_choice_126f3f8d:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0312.ogg"
    # e blush @ upset_open "What?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0312.ogg"
    e blush @ upset_open "¿Qué?"

# game/script.rpy:6850
translate es cake_choice_2792a35d:

    # p "If you'll still have me."
    p "Si aún me aceptas."

# game/script.rpy:6856
translate es cake_choice_52125479:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0313.ogg"
    # e "I..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0313.ogg"
    e "Yo..."

# game/script.rpy:6862
translate es cake_choice_4f7e71eb:

    # "I could never comprehend the thousands of emotions that must be beating through Elias' heart."
    "Nunca podría comprender las miles de emociones que deben latir en el corazón de Elias."

# game/script.rpy:6866
translate es cake_choice_63b015a6:

    # "Taylor is trying to say something, but I can't hear him."
    "Taylor intenta decir algo, pero no puedo escucharlo."

# game/script.rpy:6868
translate es cake_choice_bd7ce92e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0314.ogg"
    # e "[your_name]..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0314.ogg"
    e "[your_name]..."

# game/script.rpy:6893
translate es cake_choice_9c7b8e1c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0315.ogg"
    # e "I want our happiness to thrive."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0315.ogg"
    e "Quiero que nuestra felicidad prospere."

# game/script.rpy:6901
translate es cake_choice_17409d32:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0316.ogg"
    # e "[your_name], will you learn to love me, in joy and despair, until the end of time and beyond?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0316.ogg"
    e "[your_name], ¿aprenderás a amarme, en la alegría y la desesperación, hasta el fin de los tiempos y más allá?"

# game/script.rpy:6909
translate es cake_choice_037a2fc6:

    # p "I will. I do."
    p "Sí. Lo haré."

# game/script.rpy:6913
translate es cake_choice_2f393852:

    # "I'm trying not to stumble over my words, but I think I managed to choke them out correctly."
    "Estoy tratando de no trabarme con mis palabras, pero creo que logré decirlas correctamente."

# game/script.rpy:6919
translate es cake_choice_a7101067:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0317.ogg"
    # e "... Then we are wed."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0317.ogg"
    e "... Entonces estamos casados."

# game/script.rpy:6928
translate es cake_choice_3388a976:

    # "Elias takes my hand, fingers tracing the ring he slipped on my finger."
    "Elias toma mi mano, sus dedos recorriendo el anillo que deslizó en mi dedo."

# game/script.rpy:6934
translate es cake_choice_119081e2:

    # "He holds me close."
    "Me abraza con fuerza."

# game/script.rpy:6942
translate es cake_choice_f0fad8b7:

    # "He kisses my lips, and I nearly faint again."
    "Me besa en los labios, y casi me desmayo nuevamente."

# game/script.rpy:6948
translate es cake_choice_26760f03:

    # "But once this kiss is over, I'm awake, alive, staring deeply into my husband's eyes."
    "Pero una vez que este beso termina, estoy despierta, viva, mirando profundamente los ojos de mi esposo."

# game/script.rpy:6957
translate es cake_choice_2ca7bfeb:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0318.ogg"
    # e "It is done, my love."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0318.ogg"
    e "Está hecho, mi amor."

# game/script.rpy:6965
translate es cake_choice_83e6897b:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0319.ogg"
    # e "Now, shall we elope on our honeymoon?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0319.ogg"
    e "Ahora, ¿nos fugamos en nuestra luna de miel?"

# game/script.rpy:6973
translate es cake_choice_93370c59:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0320.ogg"
    # e "Taylor, my dear medium, I ask you to help us see the world."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0320.ogg"
    e "Taylor, mi querido médium, te pido que nos ayudes a ver el mundo."

# game/script.rpy:7000
translate es cake_choice_d2072091:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0334.ogg"
    # t "I... Uh..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0334.ogg"
    t "Yo... Eh..."

# game/script.rpy:7004
translate es cake_choice_22c2f417:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0321.ogg"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0321.ogg"

# game/script.rpy:7010
translate es cake_choice_816b1b9b:

    # e "We can revolutionize your ghost club! We can change humanity!"
    e ""

# game/script.rpy:7016
translate es cake_choice_88866261:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0322.ogg"
    # e "And I know [your_name] appreciates all that you've done for {0}him{/0}{1}her{/1}{2}them{/2}."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0322.ogg"
    e "Y sé que [your_name] aprecia todo lo que has hecho por {0}él{/0}{1}ella{/1}{2}elle{/2}."

# game/script.rpy:7022
translate es cake_choice_a07f1a61:

    # p "It's true."
    p "Es cierto."

# game/script.rpy:7026
translate es cake_choice_c356f889:

    # "I turn to face Taylor, who's extremely interested in the floor all of a sudden; a crimson blush tinging his cheeks."
    "Me giro para mirar a Taylor, quien de repente está extremadamente interesado en el suelo; un rubor carmesí tiñe sus mejillas."

# game/script.rpy:7028
translate es cake_choice_fbaafb6e:

    # p "Taylor... Maybe I would have dated you if you had asked me. I think it's too late now."
    p "Taylor... Tal vez te habría salido conmigo si me lo hubieras pedido. Creo que ahora es demasiado tarde."

# game/script.rpy:7032
translate es cake_choice_88d4b3e6:

    # p "But you've always been a good friend, and I have always cherished you. If I didn't, I'd never have come to this mansion."
    p "Pero siempre has sido un buen amigo, y siempre te he apreciado. Si no lo hubiera hecho, nunca habría venido a esta mansión."

# game/script.rpy:7038
translate es cake_choice_b6299235:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0335.ogg"
    # t "... I shouldn't have said anything."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0335.ogg"
    t "... No debería haber dicho nada."

# game/script.rpy:7046
translate es cake_choice_84bddba8:

    # p "No, you should have. You care for me so much."
    p "No, deberías haberlo hecho. Te preocupas mucho por mí."

# game/script.rpy:7052
translate es cake_choice_b7fa35a8:

    # p "I love you, Taylor. I hope you can understand how."
    p "Te amo, Taylor. Espero que puedas entender cómo."

# game/script.rpy:7064
translate es cake_choice_764ee5c9:

    # "I put a hand on his shoulder and lean it to give him a peck on the cheek."
    "Pongo una mano en su hombro y me inclino para darle un beso en la mejilla."

# game/script.rpy:7076
translate es cake_choice_01a168c0:

    # p "But I want to love Elias Gallagher too, and I'm ready to spend the rest of my life with him."
    p "Pero también quiero amar a Elias Gallagher, y estoy lista para pasar el resto de mi vida con él."

# game/script.rpy:7082
translate es cake_choice_7e4023be:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0336.ogg"
    # t "... I don't want to be a third wheel. I'll go."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0336.ogg"
    t "... No quiero ser la tercera rueda. Me iré."

# game/script.rpy:7094
translate es cake_choice_0d573fd1:

    # p "You're not! You know what? You... and Elias... spend an hour getting to know each other. I'll take some time to myself. I could use a break."
    p "¡No lo eres! ¿Sabes qué? Tú... y Elias... pasen una hora conociéndose. Yo me tomaré un tiempo para mí. Necesito un descanso."

# game/script.rpy:7100
translate es cake_choice_3a8b492e:

    # p "You're gonna change the world, Taylor. I just know it."
    p "Vas a cambiar el mundo, Taylor. Lo sé."

# game/script.rpy:7106
translate es cake_choice_c9ec35cb:

    # "I wave to them both, and step out of the ballroom."
    "Les hago una señal a ambos y salgo del salón de baile."

# game/script.rpy:7112
translate es cake_choice_ba412113:

    # "Wow. I kissed a ghost, and married a ghost,\nand fell in love with a ghost..."
    "Wow. Besé a un fantasma, y me casé con un fantasma,\ny me enamoré de un fantasma..."

# game/script.rpy:7114
translate es cake_choice_674a2ee1:

    # "And not twelve hours ago I thought I was getting all gussied up for nothing."
    "Y hace apenas doce horas pensaba que me estaba arreglando para nada."

# game/script.rpy:7116
translate es cake_choice_e7e96257:

    # "I rub Elias' ring, enjoying its embrace on my finger. It shines in the dim light as if it were a candle."
    "Froto el anillo de Elias, disfrutando de su abrazo en mi dedo. Brilla en la luz tenue como si fuera una vela."

# game/script.rpy:7118
translate es cake_choice_1d64cd64:

    # "So, do I own this mansion now? Or partly own it? I guess so. We'll have to start thinking about repairs."
    "Entonces, ¿soy dueña de esta mansión ahora? ¿O parcialmente? Supongo que sí. Tendremos que empezar a pensar en reparaciones."

# game/script.rpy:7120
translate es cake_choice_605735b8:

    # "But this isn't the world. This doesn't have to be the world!"
    "Pero este no es el mundo. ¡Esto no tiene que ser el mundo!"

# game/script.rpy:7122
translate es cake_choice_6c231e8d:

    # "I walk through the halls, down the foyer,\nand step right out the front door."
    "Camino por los pasillos, bajando por el vestíbulo,\ny salgo por la puerta principal."

# game/script.rpy:7128
translate es cake_choice_38ffda1a:

    # "And the world is ready to greet me. I'm ready to greet it."
    "Y el mundo está listo para recibirme. Yo estoy lista para recibirlo."

# game/script.rpy:7132
translate es cake_choice_a9efead1:

    # "The morning sun is beginning to peek over the horizon. I watch with contentment as it climbs into the sky, ready to light up the world around it."
    "El sol de la mañana comienza a asomarse sobre el horizonte. Observo con satisfacción cómo asciende al cielo, listo para iluminar el mundo a mi alrededor."

# game/script.rpy:7134
translate es cake_choice_5ccca9e1:

    # "Soon, Elias and Taylor find me waiting for them outside."
    "Pronto, Elias y Taylor me encuentran esperándolos afuera."

# game/script.rpy:7142
translate es cake_choice_ab1effe7:

    # p "Everything hashed out?"
    p "¿Todo arreglado?"

# game/script.rpy:7144
translate es cake_choice_313f411f:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0323.ogg"
    # e forward_regular oh_sad happy "Hashed?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0323.ogg"
    e forward_regular oh_sad happy "¿Hasheado?"

# game/script.rpy:7148
translate es cake_choice_da80d4e9:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0337.ogg"
    # t grin_open raised "Yeah, we've gotten to know each other. And we've come up with an idea."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0337.ogg"
    t grin_open raised "Sí, nos hemos llegado a conocer. Y se nos ocurrió una idea."

# game/script.rpy:7152
translate es cake_choice_4577fbc2:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0324.ogg"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0324.ogg"

# game/script.rpy:7158
translate es cake_choice_ce0e2f06:

    # e "Yes! I'm not particularly excited by the prospect of becoming a freak show to gawk at... But my flowers, those are another thing."
    e ""

# game/script.rpy:7164
translate es cake_choice_2e418ac7:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0338.ogg"
    # t "Ready to start a spectral florist's shop?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0338.ogg"
    t "¿Listos para abrir una florería espectral?"

# game/script.rpy:7172
translate es cake_choice_6b70f6eb:

    # p "Oh, absolutely!"
    p "¡Oh, absolutamente!"

# game/script.rpy:7178
translate es cake_choice_0c40d6c7:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0325.ogg"
    # e "What shall we call it? Gallagher's Spectral Exotic Flowers and Bouquets?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0325.ogg"
    e "¿Cómo la llamaremos? ¿Gallagher's Flores y Ramos Exóticos Espectrales?"

# game/script.rpy:7186
translate es cake_choice_1567e755:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0339.ogg"
    # t "Hey, I get to have my name in there too! We're business partners now, after all!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0339.ogg"
    t "¡Oye, yo también puedo poner mi nombre! ¡Después de todo, ahora somos socios!"

# game/script.rpy:7190
translate es cake_choice_bcfa849d:

    # "I let the two boys bicker, and rest my head on Elias' ethereal shoulder."
    "Dejo que los dos chicos discutan y apoyo mi cabeza en el hombro etéreo de Elias."

# game/script.rpy:7196
translate es cake_choice_10672f65:

    # "It's going to take some adjustment, but I can't help feeling as though everything is as it should be."
    "Va a tomar un poco de ajuste, pero no puedo evitar sentir que todo está como debería estar."

# game/script.rpy:7206
translate es cake_choice_24904f72:

    # centered "{size=+150}{font=gui/font/Awugh.otf}Ending B\nFor Love{/font}{/size}" with dissolve
    centered "{size=+150}{font=gui/font/Awugh.otf}Final B\nPor Amor{/font}{/size}" with dissolve

# game/script.rpy:7228
translate es cake_choice_094327c9:

    # p "I can't do this. I can't marry you, Elias."
    p "No puedo hacer esto. No puedo casarme contigo, Elias."

# game/script.rpy:7234
translate es cake_choice_04fa52b4:

    # p "You're very kind, but I've only gotten to know you for one night. That's not nearly enough time for me to declare my eternal, undying love to you."
    p "Eres muy amable, pero solo te he conocido una noche. Eso no es tiempo suficiente para declarar mi amor eterno e inmortal hacia ti."

# game/script.rpy:7242
translate es cake_choice_399d876a:

    # p "But Taylor on the other hand... I've known him for years. He's my bestie, even if he's kinda obnoxious..."
    p "Pero Taylor, por otro lado... Lo conozco desde hace años. Es mi mejor amigo, aunque sea un poco molesto..."

# game/script.rpy:7244
translate es cake_choice_e72a2d69:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0340.ogg"
    # t blush ugh "Hey!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0340.ogg"
    t blush ugh "¡Oye!"

# game/script.rpy:7248
translate es cake_choice_e709546e:

    # p "Or an immature pervert..."
    p "O un pervertido inmaduro..."

# game/script.rpy:7254
translate es cake_choice_8ecd3a36:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0341.ogg"
    # t "C-come on!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0341.ogg"
    t "¡V-vamos!"

# game/script.rpy:7260
translate es cake_choice_972d05b7:

    # p "And makes me do a lot of his dirty work..."
    p "Y me hace hacer mucho de su trabajo sucio..."

# game/script.rpy:7266
translate es cake_choice_a7ba8c27:

    # p "{i}All{/i} of his dirty work..."
    p "{i}Todo{/i} su trabajo sucio..."

# game/script.rpy:7268
translate es cake_choice_d5ef8000:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0342.ogg"
    # t forward_half tch neutral sweat "... Okay fine, that part is fair."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0342.ogg"
    t forward_half tch neutral sweat "... Está bien, esa parte es justa."

# game/script.rpy:7276
translate es cake_choice_85d13c94:

    # p "Because at the end of the day, I know Taylor always has my back. We're always looking out for each other and I think that's what makes the stable foundation for romance."
    p "Porque al final del día, sé que Taylor siempre me respalda. Siempre nos cuidamos mutuamente y creo que eso es lo que hace una base estable para el romance."

# game/script.rpy:7282
translate es cake_choice_f529b66a:

    # "Taylor's jaw drops as a blush spreads across his face, while Elias studies the both of us silently."
    "La mandíbula de Taylor cae mientras un rubor se extiende por su rostro, mientras Elias nos estudia en silencio."

# game/script.rpy:7288
translate es cake_choice_a41a9641:

    # p "So marrying you like this just to fulfill your wish wouldn't be fair, because I can't give you the love you crave. The love you deserve."
    p "Así que casarme contigo solo para cumplir tu deseo no sería justo, porque no puedo darte el amor que deseas. El amor que mereces."

# game/script.rpy:7294
translate es cake_choice_1e652736:

    # p "I hope you'll understand and forgive me."
    p "Espero que lo entiendas y me perdones."

# game/script.rpy:7296
translate es cake_choice_72a33094:

    # e "..."
    e "..."

# game/script.rpy:7298
translate es cake_choice_4766898d:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0326.ogg"
    # e closed_sad ah_sad sad "This is nothing like the romances I've read in novels, nor the kind I've seen my parents or even siblings divulge in. It's clumsy, ridiculous even! Why, it's hardly romantic!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0326.ogg"
    e closed_sad ah_sad sad "Esto no se parece en nada a los romances que he leído en novelas, ni al tipo que he visto entre mis padres o incluso hermanos. ¡Es torpe, ridículo incluso! ¡Ni siquiera es romántico!"

# game/script.rpy:7308
translate es cake_choice_b68fdc44:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0327.ogg"
    # e "... And yet, those were the most genuine words I've heard from you this entire night. You hold those sentiments quite dear."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0327.ogg"
    e "... Y, sin embargo, esas fueron las palabras más genuinas que he escuchado de ti en toda esta noche. Guardas esos sentimientos muy cerca."

# game/script.rpy:7316
translate es cake_choice_037bf5db:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0328.ogg"
    # e "So this is what true love is."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0328.ogg"
    e "Así que esto es lo que es el verdadero amor."

# game/script.rpy:7320
translate es cake_choice_6472a01d:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0343.ogg"
    # t forward_small pout2 "Hang on [your_name], d-does that actually mean you'll go out with me?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0343.ogg"
    t forward_small pout2 "Espera [your_name], ¿eso significa que en realidad saldrás conmigo?"

# game/script.rpy:7324
translate es cake_choice_233db229:

    # p "I'm willing to give it the good ol' college try, at least."
    p "Estoy dispuest@ a intentarlo, al menos."

# game/script.rpy:7328
translate es cake_choice_d4c04cb7:

    # "Elias clasps his hands together and brightens up in spite of the fact that I just rejected him."
    "Elias junta sus manos y se ilumina a pesar de que acabo de rechazarlo."

# game/script.rpy:7332
translate es cake_choice_78cf8e43:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0329.ogg"
    # e forward_regular goofgrin_up "Waste not, want not! I shall officiate your wedding then!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0329.ogg"
    e forward_regular goofgrin_up "¡No desperdiciaré, no necesitaré! ¡Entonces oficiaré tu boda!"

# game/script.rpy:7336
translate es cake_choice_754d246d:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0344.ogg"
    # t right_regular upset "Whoa there, easy now! Are we really doing this? I-I'm not even ready—"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0344.ogg"
    t right_regular upset "¡Whoa, espera! ¿De verdad vamos a hacer esto? Yo—ni siquiera estoy listo—"

# game/script.rpy:7344
translate es cake_choice_ab4bcb86:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0330.ogg"
    # e "Do you, [your_name], take Taylor Potts to be your lawfully wedded husband, to live together in matrimony, to love him, comfort him, honor, and keep him..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0330.ogg"
    e "¿Tú, [your_name], tomas a Taylor Potts como tu esposo legítimo, para vivir juntos en matrimonio, amarlo, confortarlo, honrarlo y cuidarlo..."

# game/script.rpy:7352
translate es cake_choice_f55029e5:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0331.ogg"
    # e "In sickness and in health, in sorrow and in joy, to have and to hold, from this day forward, as long as you both shall live?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0331.ogg"
    e "En la enfermedad y en la salud, en la tristeza y en la alegría, para tenerlo y sostenerlo, desde este día en adelante, mientras vivan?"

# game/script.rpy:7360
translate es cake_choice_469ff937:

    # "Elias is really determined to see some kind of wedding today, so I might as well entertain him."
    "Elias está realmente decidido a ver algún tipo de boda hoy, así que más vale que lo entretenga."

# game/script.rpy:7366
translate es cake_choice_7988a01b_1:

    # p "I do."
    p "Sí, lo hago."

# game/script.rpy:7372
translate es cake_choice_6fa85f9e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0332.ogg"
    # e "And do you, Taylor, take [your_name] to be your lawfully wedded spouse, to return their affections and so on and so forth?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0332.ogg"
    e "¿Y tú, Taylor, tomas a [your_name] como tu espos@ legítim@, para corresponder a sus afectos y demás?"

# game/script.rpy:7380
translate es cake_choice_9179b692:

    # "Taylor scrunches up his face when Elias doesn't repeat the same ceremonial speech for his part of the vows."
    "Taylor frunce el ceño cuando Elias no repite el mismo discurso ceremonial para su parte de los votos."

# game/script.rpy:7382
translate es cake_choice_04422f74:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0345.ogg"
    # t ah blush forward_small "I uh, shoot. I guess? Aren't we moving a little fast—"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0345.ogg"
    t ah blush forward_small "Yo, eh, supongo. ¿No vamos un poco rápido—"

# game/script.rpy:7386
translate es cake_choice_fb9394e3:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0333.ogg"
    # e forward_heart oh_disapprove concerned "By the authority vested in me as the final heir of the Gallagher family, I now pronounce you married! "
    voice "audio/voice/" + persistent.lang_voice + "/Elias0333.ogg"
    e forward_heart oh_disapprove concerned "Por la autoridad que me confiere como el último heredero de la familia Gallagher, ¡ahora los declaro casados!"

# game/script.rpy:7390
translate es cake_choice_b8839ab2:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0334.ogg"
    # e happy grin_teeth forward_regular "You may now kiss."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0334.ogg"
    e happy grin_teeth forward_regular "Ahora pueden besarse."

# game/script.rpy:7396
translate es cake_choice_0a90f935:

    # "Taylor looks at me, then at Elias, then back at me; mouth opening and closing like a fish out of water."
    "Taylor me mira, luego a Elias, luego a mí de nuevo; abriendo y cerrando la boca como un pez fuera del agua."

# game/script.rpy:7402
translate es cake_choice_8d66c103:

    # "All Elias does is motion at him to do {i}something{/i}."
    "Todo lo que hace Elias es indicarle que haga {i}algo{/i}."

# game/script.rpy:7409
translate es cake_choice_08a5c7d6:

    # "Eventually I sigh and just pull Taylor towards me, smashing my face into his."
    "Eventualmente suspiro y simplemente atraigo a Taylor hacia mí, aplastando mi cara contra la suya."

# game/script.rpy:7411
translate es cake_choice_bf5b5978:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0346.ogg"
    # t "MMPPPPHHH???"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0346.ogg"
    t "MMPPPPHHH???"

# game/script.rpy:7419
translate es cake_choice_38f3a988:

    # "Elias laughs and claps his hands together, clearly elated by our antics."
    "Elias ríe y aplaude, claramente encantado con nuestras travesuras."

# game/script.rpy:7425
translate es cake_choice_8c0bc2e3:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0335.ogg"
    # e "Splendid show! Now quickly, follow me to the study!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0335.ogg"
    e "¡Espectacular espectáculo! ¡Ahora rápidamente, síganme al estudio!"

# game/script.rpy:7431
translate es cake_choice_24b2cb55:

    # "Elias glides out of the ballroom while I drag Taylor behind me, still sputtering and confused over what just happened. "
    "Elias se desliza fuera del salón mientras arrastro a Taylor detrás de mí, aún balbuceando y confundido por lo que acaba de pasar."

# game/script.rpy:7440
translate es cake_choice_df97b7f6_1:

    # "Elias pulls out a paper from the drawer and clasps his hands together, causing it to glow with a ghostly light."
    "Elias saca un papel del cajón y junta las manos, haciendo que brille con una luz fantasmal."

# game/script.rpy:7442
translate es cake_choice_41a3902c:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0336.ogg"
    # e forward_regular goofgrin_up happy "Here we are! My will, freshly written. I think you two will be pleased."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0336.ogg"
    e forward_regular goofgrin_up happy "¡Aquí estamos! Mi testamento, recién escrito. Creo que les gustará a ambos."

# game/script.rpy:7448
translate es cake_choice_26774eda_1:

    # "Taylor and I scan the document."
    "Taylor y yo revisamos el documento."

# game/script.rpy:7450
translate es cake_choice_bd190770:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0347.ogg"
    # t yell sweat forward_regular furrowed "\"I, Elias Gallagher, former head of the Gallagher estate... hereby leave all my material possessions, including the Gallagher family jewels... and the manor itself to the newlywed Potts...\""
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0347.ogg"
    t yell sweat forward_regular furrowed "\"Yo, Elias Gallagher, exjefe de la finca Gallagher... por la presente dejo todas mis posesiones materiales, incluyendo las joyas de la familia Gallagher... y la mansión misma a los recién casados Potts...\""

# game/script.rpy:7458
translate es cake_choice_cd4f84de:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0348.ogg"
    # t "The Potts!?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0348.ogg"
    t "¡Los Potts!?"

# game/script.rpy:7462
translate es cake_choice_0330c496:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0337.ogg"
    # e grin_teeth forward_lidded_regular "Farewell, my dear friends! Please use my family's fortune for your honeymoon, or whatever else you may need it for."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0337.ogg"
    e grin_teeth forward_lidded_regular "¡Adiós, mis queridos amigos! Por favor, usen la fortuna de mi familia para su luna de miel, o para lo que necesiten."

# game/script.rpy:7470
translate es cake_choice_26318873:

    # p "Elias, what are you doing—"
    p "Elias, ¿qué estás haciendo—"

# game/script.rpy:7474
translate es cake_choice_7f1d213c:

    # "With a final bow, Elias quickly fades from the room."
    "Con una última reverencia, Elias desaparece rápidamente de la habitación."

# game/script.rpy:7476
translate es cake_choice_815f9f13:

    # t right_regular squiggle "..."
    t right_regular squiggle "..."

# game/script.rpy:7483
translate es cake_choice_c8ea8a4a_1:

    # p "..."
    p "..."

# game/script.rpy:7485
translate es cake_choice_cac80494:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0349.ogg"
    # t forward_half pout2 blush "So um, what do you want to do for our first date?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0349.ogg"
    t forward_half pout2 blush "Entonces, eh, ¿qué quieres hacer en nuestra primera cita?"

# game/script.rpy:7489
translate es cake_choice_58de1be7:

    # p "Hibernate."
    p "Hibernar."

# game/script.rpy:7493
translate es cake_choice_bf03298c:

    # "After a full 24 hours of uninterrupted sleep, Taylor looked up whether my surname actually was legally going to be Potts now."
    "Después de 24 horas completas de sueño ininterrumpido, Taylor miró si mi apellido legalmente sería ahora Potts."

# game/script.rpy:7495
translate es cake_choice_96f78b19:

    # "Considering a ghost officiating a wedding (and not even an ordained ghost, at that!) isn't exactly legally binding, Taylor and I decided to take our relationship slow."
    "Considerando que un fantasma oficie una boda (¡y ni siquiera un fantasma ordenado!) no es exactamente legal, Taylor y yo decidimos llevar nuestra relación con calma."

# game/script.rpy:7497
translate es cake_choice_58585595:

    # "No marriage... Not yet. Hopefully Elias wasn't going to be too mad about that."
    "No matrimonio... todavía. Esperemos que Elias no se enfade demasiado por eso."

# game/script.rpy:7499
translate es cake_choice_0ca65bae:

    # "After doctoring the will a little bit to fix my last name, we laid claim to the fortunes left in the Gallagher Mansion."
    "Después de modificar un poco el testamento para arreglar mi apellido, reclamamos la fortuna dejada en la Mansión Gallagher."

# game/script.rpy:7501
translate es cake_choice_21e19e6e:

    # "The family jewels turned out to be worth a hell of a lot of money... enough to pay off both our student debts and then some."
    "Las joyas de la familia resultaron valer una enorme cantidad de dinero... suficiente para pagar nuestras deudas estudiantiles y algo más."

# game/script.rpy:7503
translate es cake_choice_388740fd:

    # "But we got so caught up in trying to figure out how to work with our sudden and unexpected inheritance that we forgot to recruit new members for the club."
    "Pero nos quedamos tan atrapados tratando de descubrir cómo manejar nuestra repentina e inesperada herencia que olvidamos reclutar nuevos miembros para el club."

# game/script.rpy:7509
translate es cake_choice_1d900a65:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0350.ogg"
    # t "It sucks that we lost the OHSIC, but who needs 'em? We can probably fund our own activities for a while!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0350.ogg"
    t "Es una lástima que perdimos el OHSIC, pero ¿quién los necesita? ¡Probablemente podemos financiar nuestras propias actividades por un tiempo!"

# game/script.rpy:7513
translate es cake_choice_1a2774b3:

    # p "I think we should go easy on the spending for a while. Or at least stop buying the name brand orange soda."
    p "Creo que deberíamos moderar el gasto por un tiempo. O al menos dejar de comprar la soda naranja de marca."

# game/script.rpy:7517
translate es cake_choice_2f505b82:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0351.ogg"
    # t "What!? But the generic store brand just doesn't have the same flavor profile!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0351.ogg"
    t "¿Qué!? ¡Pero la marca genérica de la tienda no tiene el mismo sabor!"

# game/script.rpy:7523
translate es cake_choice_6517496f:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0352.ogg"
    # t "The recipe is completely different and the ratios of high fructose corn syrup and—"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0352.ogg"
    t "La receta es completamente diferente y las proporciones de jarabe de maíz con alto contenido de fructosa y—"

# game/script.rpy:7531
translate es cake_choice_df2cd62d:

    # "I kiss him deeply on the mouth once more to shut him up. Stupid that it works, but he doesn't protest when I pull away with a wry smile."
    "Lo beso profundamente una vez más para callarlo. Estúpido que funcione, pero no protesta cuando me aparto con una sonrisa irónica."

# game/script.rpy:7533
translate es cake_choice_43701f23:

    # p "You're a dork."
    p "Eres un bobo."

# game/script.rpy:7537
translate es cake_choice_c7817bc8:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0353.ogg"
    # t "Yeah, I am."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0353.ogg"
    t "Sí, lo soy."

# game/script.rpy:7545
translate es cake_choice_06a30cec:

    # centered "{size=+150}{font=gui/font/Awugh.otf}Ending C\nFor Science{/font}{/size}" with dissolve
    centered "{size=+150}{font=gui/font/Awugh.otf}Final C\nPor Ciencia{/font}{/size}" with dissolve

# game/script.rpy:7567
translate es cake_choice_1c0dc855:

    # "The lights are flickering, the world is collapsing, and nothing makes any sense anymore."
    "Las luces parpadean, el mundo se está derrumbando y nada tiene sentido ya."

# game/script.rpy:7573
translate es cake_choice_971f25a1:

    # p "I... I don't know what to do!"
    p "Yo... ¡No sé qué hacer!"

# game/script.rpy:7577
translate es cake_choice_9397752c:

    # p "I should never have come here at all..."
    p "Nunca debí haber venido aquí..."

# game/script.rpy:7581
translate es cake_choice_abfd5cb1:

    # p "This whole thing was a mistake..."
    p "Todo esto fue un error..."

# game/script.rpy:7587
translate es cake_choice_f4d04b54:

    # "Both Elias and Taylor look away from me."
    "Tanto Elias como Taylor apartan la vista de mí."

# game/script.rpy:7589
translate es cake_choice_59fdf8d5:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0338.ogg"
    # e left_small upset_open "So that is it, then? It simply ends with nothing?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0338.ogg"
    e left_small upset_open "¿Entonces eso es todo? ¿Simplemente termina en nada?"

# game/script.rpy:7597
translate es cake_choice_62cef730:

    # "A tear culminates in the corner of his eye before rolling down his cheek."
    "Una lágrima se acumula en la esquina de su ojo antes de deslizarse por su mejilla."

# game/script.rpy:7599
translate es cake_choice_cd876e75:

    # p "Not nothing..."
    p "No en nada..."

# game/script.rpy:7605
translate es cake_choice_36286ff5:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0354.ogg"
    # t "Let's just go and forget this ha—"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0354.ogg"
    t "Vamos, olvidemos este ha—"

# game/script.rpy:7616
translate es cake_choice_85ce55b1:

    # p "... What was that?"
    p "... ¿Qué fue eso?"

# game/script.rpy:7625
translate es cake_choice_46b9fe70:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0355.ogg"
    # t "That came from above us!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0355.ogg"
    t "¡Vino desde arriba!"

# game/script.rpy:7633
translate es cake_choice_8410e1d6:

    # p "Oh no..."
    p "¡Oh no...!"

# game/script.rpy:7645
translate es cake_choice_663d44cf:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0339.ogg"
    # e "It's over, it's over, it's over..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0339.ogg"
    e "Se acabó, se acabó, se acabó..."

# game/script.rpy:7653
translate es cake_choice_69604eab:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0356.ogg"
    # t "Run!!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0356.ogg"
    t "¡Corre!!"

# game/script.rpy:7657
translate es cake_choice_a6a413cc:

    # "I can't. My feet are frozen... I can't move at all!"
    "No puedo. Mis pies están congelad@s... ¡No puedo moverme!"

# game/script.rpy:7661
translate es cake_choice_e4ffd21f:

    # "With Elias in so much distress, he can't focus his energy on maintaining the building anymore. We crushed his hopes and dreams."
    "Con Elias tan angustiado, no puede enfocar su energía en mantener el edificio. Hemos destruido sus esperanzas y sueños."

# game/script.rpy:7665
translate es cake_choice_7e36cfc8:

    # "Decades of waiting, all for an empty lie."
    "Décadas de espera, todo por una mentira vacía."

# game/script.rpy:7678
translate es cake_choice_a21014c8:

    # "I feel Taylor tackle me in an attempt to escape but—"
    "Siento a Taylor abalanzarse sobre mí en un intento de escapar, pero—"

# game/script.rpy:7685
translate es cake_choice_873b9e9f:

    # "It's too late."
    "Es demasiado tarde."

# game/script.rpy:7689
translate es cake_choice_de188bac:

    # "... My head should be spinning."
    "... Mi cabeza debería estar dando vueltas."

# game/script.rpy:7693
translate es cake_choice_2e0f3558:

    # "I imagine I've been out for hours, but I feel... fine."
    "Imagino que he estado fuera por horas, pero me siento... bien."

# game/script.rpy:7695
translate es cake_choice_192643c9:

    # "Like nothing's happened."
    "Como si nada hubiera pasado."

# game/script.rpy:7697
translate es cake_choice_6972bb05:

    # "Cautiously, I move my hand out into the darkness..."
    "Con cautela, muevo mi mano en la oscuridad..."

# game/script.rpy:7699
translate es cake_choice_f307078d:

    # "And find nothing."
    "Y no encuentro nada."

# game/script.rpy:7701
translate es cake_choice_cb88785f:

    # "Even though I should find something."
    "Aunque debería encontrar algo."

# game/script.rpy:7703
translate es cake_choice_ac9cb1d4:

    # "Oh no..."
    "¡Oh no...!"

# game/script.rpy:7705
translate es cake_choice_c8bc5a93:

    # "I hold my hands up to my face in the darkness..."
    "Levanto mis manos hacia mi rostro en la oscuridad..."

# game/script.rpy:7707
translate es cake_choice_0649ede1:

    # "And I can see right through them. Like they aren't there to begin with."
    "Y puedo ver a través de ellas. Como si no estuvieran allí para empezar."

# game/script.rpy:7709
translate es cake_choice_0d909d33:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0357.ogg"
    # g "Hey! HEY!!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0357.ogg"
    g "¡Oye! ¡¡OYE!!"

# game/script.rpy:7713
translate es cake_choice_cab676f2:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0358.ogg"
    # g "Someone help me!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0358.ogg"
    g "¡Que alguien me ayude!"

# game/script.rpy:7717
translate es cake_choice_5bfb2a54:

    # "Taylor's panicked voice rings out in the gloom."
    "La voz de pánico de Taylor resuena en la penumbra."

# game/script.rpy:7719
translate es cake_choice_9ef20f9c:

    # p "Taylor! Are you..."
    p "¡Taylor! ¿Estás...?"

# game/script.rpy:7721
translate es cake_choice_9e6953cc:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0359.ogg"
    # g "Something's wrong! I can't feel my limbs!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0359.ogg"
    g "¡Algo anda mal! ¡No puedo sentir mis extremidades!"

# game/script.rpy:7725
translate es cake_choice_8cad0bc1:

    # p "Taylor... I think... Did you get caught by the rubble, too?"
    p "Taylor... creo que... ¿También te atrapó el escombro?"

# game/script.rpy:7727
translate es cake_choice_f4c03034:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0360.ogg"
    # g "Yeah, but..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0360.ogg"
    g "Sí, pero..."

# game/script.rpy:7731
translate es cake_choice_8ae3faac:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0361.ogg"
    # g "... Oh. Oh shit, fuck."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0361.ogg"
    g "... Oh. Mierda, joder."

# game/script.rpy:7739
translate es cake_choice_2031190b:

    # p "Yeah, uh... I think we're dead."
    p "Sí, eh... creo que estamos muertos."

# game/script.rpy:7745
translate es cake_choice_16b3765e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0340.ogg"
    # e "It's true. Sorry that the mansion couldn't hold you. I did warn you about that rickety second floor... a few times, in fact."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0340.ogg"
    e "Es cierto. Lamento que la mansión no pudiera sostenerte. Te advertí sobre ese segundo piso endeble... varias veces, de hecho."

# game/script.rpy:7753
translate es cake_choice_74499ff8:

    # "Elias floats between us, an indiscernible look on his face. He almost seems... happy?"
    "Elias flota entre nosotros, con una expresión indescifrable en su rostro. ¿Parece casi... feliz?"

# game/script.rpy:7755
translate es cake_choice_3f4c9cac:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0341.ogg"
    # e happy grin_teeth "And as you also know, it has been close to a century since the estate has seen proper maintenance. Who do you think ensured that the facade and outer gardens kept well and proper? You entered at your own risk."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0341.ogg"
    e happy grin_teeth "Y como también sabes, ha pasado casi un siglo desde que la finca tuvo un mantenimiento adecuado. ¿Quién crees que se aseguró de que la fachada y los jardines exteriores se mantuvieran en buen estado? Entraste bajo tu propio riesgo."

# game/script.rpy:7763
translate es cake_choice_090878c9:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0342.ogg"
    # e "And now, I think we'll all be together for some time!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0342.ogg"
    e "¡Y ahora, creo que estaremos juntos por algún tiempo!"

# game/script.rpy:7771
translate es cake_choice_ba0a1843:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0343.ogg"
    # e "I cannot tell you how excited I am to have some company at long last! In fact, I didn't expect your souls to stay in this world..."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0343.ogg"
    e "¡No puedo decirte lo emocionado que estoy de tener compañía al fin! De hecho, no esperaba que sus almas se quedaran en este mundo..."

# game/script.rpy:7775
translate es cake_choice_f9c313cf:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0343-5.ogg"
    # e goofgrin_up "But I suppose that you two have some lingering regrets anchoring you to this place, same as me."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0343-5.ogg"
    e goofgrin_up "Pero supongo que ustedes dos tienen algunos arrepentimientos persistentes que los atan a este lugar, igual que a mí."

# game/script.rpy:7783
translate es cake_choice_1e711493:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0362.ogg"
    # g "Whoa, hang on..."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0362.ogg"
    g "Espera, espera..."

# game/script.rpy:7789
translate es cake_choice_6abe7d9e:

    # p "Elias, we never meant to—"
    p "Elias, nunca quisimos—"

# game/script.rpy:7791
translate es cake_choice_5bf43e5b:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0344.ogg"
    # e grin_tilted closed_happy sad "Leave if you want to try, but don't expect to get very far. I strongly suggest that we all learn to like each other very quickly, instead of letting this situation fester."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0344.ogg"
    e grin_tilted closed_happy sad "Vete si quieres intentarlo, pero no esperes llegar muy lejos. Sugiero encarecidamente que tod@s aprendamos a querernos rápidamente, en lugar de dejar que esta situación se pudra."

# game/script.rpy:7795
translate es cake_choice_11f2ae9f:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0363.ogg"
    # g forward_half hmph "... Uh."
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0363.ogg"
    g forward_half hmph "... Eh."

# game/script.rpy:7799
translate es cake_choice_8eeb4196:

    # p "... There's no hope for us?"
    p "... ¿No hay esperanza para nosotros?"

# game/script.rpy:7805
translate es cake_choice_bdeacf15:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0345.ogg" 
    # e "I never said that. Personally, I was never able to leave the mansion even after my death, much to my own chagrin, so I doubt you will have much more success."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0345.ogg" 
    e "Nunca dije eso. Personalmente, nunca pude dejar la mansión incluso después de mi muerte, para mi propio disgusto, así que dudo que tú tengas mucho más éxito."

# game/script.rpy:7813
translate es cake_choice_601f6395:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0346.ogg"
    # e "But I welcome you to your new life. Or should I say death."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0346.ogg"
    e "Pero te doy la bienvenida a tu nueva vida. O debería decir, muerte."

# game/script.rpy:7821
translate es cake_choice_7ef4a332:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0347.ogg"
    # e "Enjoy it for what it is!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0347.ogg"
    e "¡Disfrútala por lo que es!"

# game/script.rpy:7827
translate es cake_choice_cd4595cc:

    # "Taylor and I exchange glances, then look back at our new host. I can't tell if Elias has lost it, or if he's making more sense now than ever."
    "Taylor y yo intercambiamos miradas, luego volvemos a mirar a nuestro nuevo anfitrión. No puedo decir si Elias ha perdido la cabeza, o si ahora tiene más sentido que nunca."

# game/script.rpy:7831
translate es cake_choice_4b340443:

    # g "..."
    g "..."

# game/script.rpy:7839
translate es cake_choice_84b50551:

    # "Several months(?) later..."
    "¿Varios meses después...?"

# game/script.rpy:7845
translate es cake_choice_813ec821:

    # "It's taken some time, but I've finally managed to get my soul to climb high enough to return to the bedroom."
    "Me tomó algo de tiempo, pero finalmente logré que mi alma subiera lo suficiente para regresar al dormitorio."

# game/script.rpy:7847
translate es cake_choice_d6d74ce2:

    # "I didn't think moving would be so hard! Elias made it look so easy."
    "¡No pensé que moverme sería tan difícil! Elias lo hacía parecer tan fácil."

# game/script.rpy:7849
translate es cake_choice_e2d80a56:

    # "Taylor still hasn't quite figured it out. Maybe it's despair, maybe it's Elias helping me more than him."
    "Taylor todavía no lo ha descifrado del todo. Tal vez sea desesperación, tal vez sea Elias ayudándome más a mí que a él."

# game/script.rpy:7855
translate es cake_choice_7714da7e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0348.ogg"
    # e "I thought you might return here."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0348.ogg"
    e "Pensé que podrías regresar aquí."

# game/script.rpy:7859
translate es cake_choice_b13620fb:

    # p "Oh! Elias..."
    p "¡Oh! Elias..."

# game/script.rpy:7861
translate es cake_choice_3b305388:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0349.ogg"
    # e forward_heart lipbite_small "It's a nice little bedroom, isn't it?"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0349.ogg"
    e forward_heart lipbite_small "Es un dormitorio bonito, ¿verdad?"

# game/script.rpy:7865
translate es cake_choice_fbd02c20:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0350.ogg"
    # e normal neutral "If you want to lie down, go ahead."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0350.ogg"
    e normal neutral "Si quieres recostarte, adelante."

# game/script.rpy:7869
translate es cake_choice_9cf70b0e:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0351.ogg"
    # e closed_happy happy grin_teeth "No reason not to relax, even for the dead!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0351.ogg"
    e closed_happy happy grin_teeth "¡No hay razón para no relajarse, incluso para los muertos!"

# game/script.rpy:7873
translate es cake_choice_bcbf18e5:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0352.ogg"
    # e smug sad closed_sad "While you rest I'll go talk to Taylor."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0352.ogg"
    e smug sad closed_sad "Mientras descansas, iré a hablar con Taylor."

# game/script.rpy:7877
translate es cake_choice_5021a43a:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0353.ogg"
    # e forward_heart goofgrin_drool "I think it's high time things changed around here."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0353.ogg"
    e forward_heart goofgrin_drool "Creo que ya es hora de que las cosas cambien por aquí."

# game/script.rpy:7881
translate es cake_choice_fa04665e:

    # p "Changed how?"
    p "¿Cambiar cómo?"

# game/script.rpy:7883
translate es cake_choice_624c51ce:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0354.ogg"
    # e forward_regular lipbite_big happy "For the better, I hope. Wait here."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0354.ogg"
    e forward_regular lipbite_big happy "Para mejor, espero. Espera aquí."

# game/script.rpy:7889
translate es cake_choice_649198ef:

    # "And with his signature bow, Elias is gone."
    "Y con su reverencia característica, Elias se va."

# game/script.rpy:7893
translate es cake_choice_60e9530e:

    # "I take up his offer and lie my soul down on the bed. It's as soft as I remember. "
    "Acepto su oferta y recuesto mi alma en la cama. Es tan suave como la recuerdo."

# game/script.rpy:7895
translate es cake_choice_0b146bed:

    # "And I can't help but fall into a deep, long sleep..."
    "Y no puedo evitar caer en un sueño profundo y largo..."

# game/script.rpy:7903
translate es cake_choice_9b444290:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0355.ogg"
    # e "Wake up, dear."
    voice "audio/voice/" + persistent.lang_voice + "/Elias0355.ogg"
    e "Despierta, querida."

# game/script.rpy:7907
translate es cake_choice_9b765241:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0364.ogg"
    # g "Yeah, come on!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0364.ogg"
    g "¡Sí, vamos!"

# game/script.rpy:7920
translate es cake_choice_f9c7c632:

    # "I open my eyes, stretch my limbs, and look towards my morning greeters."
    "Abro los ojos, estiro mis extremidades y miro hacia mis saludadores matutinos."

# game/script.rpy:7926
translate es cake_choice_983fa59d:

    # "Taylor and Elias float nearby, hand in han—"
    "Taylor y Elias flotan cerca, de la mano—"

# game/script.rpy:7934
translate es cake_choice_6cbf7fca:

    # "Hand in hand?"
    "¿De la mano?"

# game/script.rpy:7936
translate es cake_choice_8e2afe07:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0365.ogg"
    # g forward_half grin_open "So, we decided to start dating, and we'd like you to join us!"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0365.ogg"
    g forward_half grin_open "Entonces, decidimos empezar a salir, ¡y nos gustaría que te unieras a nosotros!"

# game/script.rpy:7942
translate es cake_choice_8f60b8d6:

    # p "What, really?"
    p "¿Qué, en serio?"

# game/script.rpy:7944
translate es cake_choice_ab8a1cd8:

    # "I couldn't help but wonder what kind of conversation — or how many conversations — they'd had while I was out."
    "No pude evitar preguntarme qué tipo de conversación —o cuántas conversaciones— tuvieron mientras estaba fuera."

# game/script.rpy:7946
translate es cake_choice_7b2343af:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0366.ogg"
    # g right_half satisfied "We both have feelings for you, and maybe you still have some feelings for the two of us. Whaddya say? Wanna try it out?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0366.ogg"
    g right_half satisfied "Ambos tenemos sentimientos por ti, y tal vez tú todavía tienes algunos sentimientos por nosotros dos. ¿Qué dices? ¿Quieres intentarlo?"

# game/script.rpy:7950
translate es cake_choice_cbcce9dc:

    # voice "audio/voice/" + persistent.lang_voice + "/Elias0356.ogg"
    # e forward_heart sad grin_tilted "Yes, how about it? We can repair the ballroom if the three of us work together... and we can spend the rest of eternity dancing in each others' arms!"
    voice "audio/voice/" + persistent.lang_voice + "/Elias0356.ogg"
    e forward_heart sad grin_tilted "Sí, ¿qué tal? Podemos reparar el salón de baile si los tres trabajamos juntos... ¡y podemos pasar el resto de la eternidad bailando en los brazos del otro!"

# game/script.rpy:7954
translate es cake_choice_1fda5535:

    # voice "audio/voice/" + persistent.lang_voice + "/Taylor0367.ogg"
    # g forward_half grin "[your_name]... will you marry us?"
    voice "audio/voice/" + persistent.lang_voice + "/Taylor0367.ogg"
    g forward_half grin "[your_name]... ¿te casarás con nosotros?"

# game/script.rpy:7964
translate es cake_choice_feecb30a:

    # "... Oh sure, what the heck. After all, if death hasn't done us part... nothing ever will."
    "... Oh, claro, qué demonios. Después de todo, si la muerte no nos ha separado... nada lo hará."

# game/script.rpy:7966
translate es cake_choice_3bccae2d:

    # p "... I do."
    p "... Sí, quiero."

# game/script.rpy:7972
translate es cake_choice_e319a469:

    # centered "{size=+150}{font=gui/font/Awugh.otf}Ending D\nForever{/font}{/size}" with dissolve
    centered "{size=+150}{font=gui/font/Awugh.otf}Final D\nPara siempre{/font}{/size}" with dissolve

# game/script.rpy:8076
translate es long_pause_a20cefa7:

    # "..."
    "..."

# game/script.rpy:8078
translate es long_pause_6e6f6c85:

    # extend "\n..."
    extend "\n..."

# game/script.rpy:8080
translate es long_pause_6e6f6c85_1:

    # extend "\n..."
    extend "\n..."

# game/script.rpy:8102
translate es honeymoon_079d76e4:

    # "Evening descends upon the Gallagher Mansion once more as you and your spouse settle into your new shared bedroom."
    "La noche cae una vez más sobre la Mansión Gallagher mientras tú y tu esposo se instalan en su nuevo dormitorio compartido."

# game/script.rpy:8104
translate es honeymoon_af4728ba:

    # "Today the air is charged with intent; desire and wanting, a cocktail of impatience and hesitation. After all..."
    "Hoy el aire está cargado de intenciones; deseo y anhelo, un cóctel de impaciencia y vacilación. Después de todo..."

# game/script.rpy:8108
translate es honeymoon_5b1b159c:

    # "Theory and research cannot compare to experience when it comes to what Elias is about to do at last, after a lifetime and afterlife of waiting for this moment."
    "La teoría y la investigación no se comparan con la experiencia cuando se trata de lo que Elias está a punto de hacer al fin, después de una vida y una postvida esperando este momento."

# game/script.rpy:8115
translate es honeymoon_7a2e3c89:

    # "He stares at you, unsure of how to proceed. Oh, how he's dreamed of the day he'd become one with his beloved! But now that the time has come, he's frozen to the bed."
    "Te mira, inseguro de cómo proceder. ¡Oh, cómo ha soñado con el día en que se convertiría en uno con su amad@! Pero ahora que ha llegado el momento, está congelado en la cama."

# game/script.rpy:8121
translate es honeymoon_3da3f78b:

    # "With his permission, your hands work on the buttons of his suit. Slowly, gently, peeling away his attire."
    "Con su permiso, tus manos trabajan en los botones de su traje. Lentamente, con suavidad, despojándolo de su atuendo."

# game/script.rpy:8130
translate es honeymoon_a2b281b5:

    # "Elias' breath hitches as you get to his trousers and relieve some of the growing pressure down there, causing him to make a noise of embarrassment."
    "La respiración de Elias se entrecorta mientras llegas a sus pantalones y alivia un poco la presión creciente ahí abajo, haciéndolo emitir un sonido de vergüenza."

# game/script.rpy:8132
translate es honeymoon_64502852:

    # "You can't help but admire the package before you, wondering how it looks underneath all the unnecessary fabric."
    "No puedes evitar admirar el paquete frente a ti, preguntándote cómo se ve debajo de toda esa tela innecesaria."

# game/script.rpy:8141
translate es honeymoon_4aeaeca1:

    # "You look back up at your dearest with a smile, appreciating his low breaths as he concentrates on your touch."
    "Vuelves a mirar a tu querid@ con una sonrisa, apreciando sus respiraciones bajas mientras se concentra en tu toque."

# game/script.rpy:8145
translate es honeymoon_5033affb:

    # "He looks at you once more, this time with a little more lust than before. This, you understand, is a silent request to continue."
    "Te mira una vez más, esta vez con un poco más de lujuria que antes. Esto, entiendes, es una solicitud silenciosa para continuar."

# game/script.rpy:8147
translate es honeymoon_16ed760f:

    # "And who are you to deny your loving husband this pleasure of the flesh? The sheer anticipation could very well kill him again."
    "¿Y quién eres tú para negarle a tu amado esposo este placer de la carne? La mera anticipación bien podría matarlo de nuevo."

# game/script.rpy:8151
translate es honeymoon_464cd9ac:

    # "It's a cooperative effort to remove his outer layers and begin on his undergarments. The translucent, pale blue glow of his body dazzles your eyes."
    "Es un esfuerzo cooperativo quitar sus capas externas y comenzar con su ropa interior. El brillo translúcido y azul pálido de su cuerpo deslumbra tus ojos."

# game/script.rpy:8153
translate es honeymoon_114edf19:

    # "It's more skin than you're accustomed to seeing from Elias, but it's certainly not an unwelcome sight."
    "Es más piel de la que estás acostumbrad@ a ver de Elias, pero ciertamente no es una vista desagradable."

# game/script.rpy:8157
translate es honeymoon_6a2de196:

    # "He closes his eyes and murmurs something underneath his breath. You chuckle in response and work your way down again."
    "Cierra los ojos y murmura algo por lo bajo. Tú ríes en respuesta y trabajas tu camino hacia abajo otra vez."

# game/script.rpy:8166
translate es honeymoon_130106fc:

    # "How vulnerable he's made himself in order to receive your love. And your love he will receive, for you have an overabundance to share of it."
    "Qué vulnerable se ha puesto para recibir tu amor. Y tu amor recibirá, porque tienes una abundancia para compartir."

# game/script.rpy:8168
translate es honeymoon_fec08cc8:

    # "You teasingly trace your finger over his bulge one last time and savor the sound of the quiet moan escaping his lips."
    "Trazas burlonamente tu dedo sobre su bulto una última vez y saboreas el sonido del gemido silencioso que escapa de sus labios."

# game/script.rpy:8176
translate es honeymoon_230d6d8d:

    # "He draws your attention upwards again, a bashful look gracing his features. He's no longer above begging at this point."
    "Vuelve a atraer tu atención hacia arriba, una mirada tímida adornando sus rasgos. Ya no está por encima de suplicar en este punto."

# game/script.rpy:8180
translate es honeymoon_e6f6938c:

    # "Finally, he sheds the last of his undergarments. The evening chill over his body causes him to shiver as he brings up his arm to cover his mouth."
    "Finalmente, se quita lo último de su ropa interior. El frío de la noche sobre su cuerpo lo hace estremecerse mientras levanta su brazo para cubrir su boca."

# game/script.rpy:8184
translate es honeymoon_30d6e475:

    # "How cute your husband is! You nudge his arm away to place a chaste kiss on his lips."
    "¡Qué lindo es tu esposo! Apartas su brazo para colocar un beso casto en sus labios."

# game/script.rpy:8193
translate es honeymoon_5b9fc7f4:

    # "Elias whimpers as your other hand wanders downward, gripping the base of his manhood gently."
    "Elias gime mientras tu otra mano se aventura hacia abajo, agarrando suavemente la base de su virilidad."

# game/script.rpy:8197
translate es honeymoon_c520a0c0:

    # "You add another hand to his girth, enjoying the slight twitch beneath the silk of your gloves."
    "Agregas otra mano a su grosor, disfrutando del ligero estremecimiento bajo la seda de tus guantes."

# game/script.rpy:8201
translate es honeymoon_6254492b:

    # "Then, you begin to move."
    "Entonces, comienzas a moverte."

# game/script.rpy:8205
translate es honeymoon_954b6851:

    # "Stroking with feather-light touches, your fingers and palms apply just enough pressure to pleasure Elias, but not so much that he would finish so quickly."
    "Acariciando con toques ligeros como plumas, tus dedos y palmas aplican la presión justa para complacer a Elias, pero no tanta como para que termine tan rápido."

# game/script.rpy:8209
translate es honeymoon_61527766:

    # "After all, you intend to take your sweet time."
    "Después de todo, tienes la intención de tomarte tu tiempo."

# game/script.rpy:8213
translate es honeymoon_8a4229d6:

    # "Up..."
    "Arriba..."

# game/script.rpy:8217
translate es honeymoon_219f2fd1:

    # "Down..."
    "Abajo..."

# game/script.rpy:8221
translate es honeymoon_e391e6e8:

    # "Up again..."
    "Arriba otra vez..."

# game/script.rpy:8225
translate es honeymoon_13f18995:

    # "Down once more..."
    "Abajo una vez más..."

# game/script.rpy:8228
translate es honeymoon_7ee6fa05:

    # "A twist of the hand here, a careful press there."
    "Un giro de la mano aquí, una presión cuidadosa allá."

# game/script.rpy:8232
translate es honeymoon_9f0454b6:

    # "You fall into a rhythmic pattern of strokes and taps, listening to Elias' labored breath above."
    "Caes en un patrón rítmico de caricias y toques, escuchando la respiración trabajosa de Elias arriba."

# game/script.rpy:8236
translate es honeymoon_fd2d44b6:

    # "The quiet ritual is punctuated only by his panting and moaning above, and you lift your eyes to observe his expression."
    "El ritual silencioso solo es interrumpido por sus jadeos y gemidos arriba, y levantas tus ojos para observar su expresión."

# game/script.rpy:8245
translate es honeymoon_a3b11e06:

    # "Utter bliss. If Elias isn't careful, he could ascend to literal heaven at any given time."
    "Pura dicha. Si Elias no tiene cuidado, podría ascender literalmente al cielo en cualquier momento."

# game/script.rpy:8249
translate es honeymoon_a4590181:

    # "You give a light squeeze to test the waters and watch his reaction closely."
    "Das un ligero apretón para probar las aguas y observas su reacción de cerca."

# game/script.rpy:8253
translate es honeymoon_f3018700:

    # "Elias' glazed gaze washes over you in wonder and awe of your ministrations."
    "La mirada vidriosa de Elias te recorre con maravilla y asombro por tus atenciones."

# game/script.rpy:8257
translate es honeymoon_8ea3391d:

    # "But a look of confusion comes over him as your hands release his girth."
    "Pero una mirada de confusión lo invade cuando tus manos sueltan su grosor."

# game/script.rpy:8266
translate es honeymoon_f0bdee98:

    # "You watch as Elias' dick twitches again, as if asking why you would be so cruel as to deprive him of sensation now."
    "Observas cómo el miembro de Elias se estremece de nuevo, como si preguntara por qué serías tan cruel como para privarlo de la sensación ahora."

# game/script.rpy:8268
translate es honeymoon_6d98df29:

    # "Above, a small whine escapes from your lover, and you can't help but laugh quietly to yourself."
    "Arriba, un pequeño gemido escapa de tu amante, y no puedes evitar reírte silenciosamente para ti mism@."

# game/script.rpy:8270
translate es honeymoon_b09c98bd:

    # "Perhaps you can tease him more some other day, but today..."
    "Tal vez puedas burlarte de él más otro día, pero hoy..."

# game/script.rpy:8274
translate es honeymoon_7914677e:

    # "You will be merciful."
    "Serás misericordios@."

# game/script.rpy:8283
translate es honeymoon_ac69930c:

    # "Elias yelps as you take him into your mouth, twirling your tongue around the sensative tip."
    "Elias suelta un grito cuando lo tomas en tu boca, girando tu lengua alrededor de la punta sensible."

# game/script.rpy:8287
translate es honeymoon_b961fdb6:

    # "This sensation is softer, warmer, and much more wet than your hands. The thought of your mouth on his manhood confuses him, but is nonetheless enjoyable."
    "Esta sensación es más suave, más cálida y mucho más húmeda que tus manos. El pensamiento de tu boca en su virilidad lo confunde, pero no por eso deja de ser placentero."

# game/script.rpy:8291
translate es honeymoon_ec2bb1d1:

    # "And the pleasure? Absolutely divine."
    "¿Y el placer? Absolutamente divino."

# game/script.rpy:8295
translate es honeymoon_591f39f9:

    # "In fact, it is almost so unbearable that Elias lowers his arm and grips the sheets of the bed below him to brace himself."
    "De hecho, es casi tan insoportable que Elias baja su brazo y agarra las sábanas de la cama debajo de él para sostenerse."

# game/script.rpy:8299
translate es honeymoon_c3ed110b:

    # "Your tongue continues to explore every inch of his cock and bring him ever closer towards release."
    "Tu lengua continúa explorando cada centímetro de su miembro y lo lleva cada vez más cerca de la liberación."

# game/script.rpy:8303
translate es honeymoon_24e16703:

    # "Every sensation causes Elias to moan and tremble, a personal symphony of the sweetest sounds just for you."
    "Cada sensación hace que Elias gima y tiemble, una sinfonía personal de los sonidos más dulces solo para ti."

# game/script.rpy:8307
translate es honeymoon_73f15bd3:

    # "Alas, all good things must come to an end."
    "Ay, todas las cosas buenas deben llegar a su fin."

# game/script.rpy:8317
translate es honeymoon_71ea2da0:

    # "You take Elias' dick down your throat as far as you can handle, and in mere seconds you taste his seed filling your mouth."
    "Tomas el miembro de Elias en tu garganta tan lejos como puedes manejar, y en pocos segundos saboreas su semilla llenando tu boca."

# game/script.rpy:8321
translate es honeymoon_1b24d641:

    # "You milk him for all that he has to offer and drink it gratefully. Not a single drop is wasted."
    "Lo ordeñas por todo lo que tiene para ofrecer y lo bebes agradecid@. No se desperdicia ni una sola gota."

# game/script.rpy:8331
translate es honeymoon_7654a54a:

    # "And when you've had your fill, you step back and make a show of licking your lips. Elias, in his dazed state, can only stare back in awe."
    "Y cuando has tenido suficiente, te retiras y haces un espectáculo lamiéndote los labios. Elias, en su estado aturdido, solo puede mirarte con asombro."

# game/script.rpy:8335
translate es honeymoon_56afcc7b:

    # "Perhaps this was still too much for his first time, you think. Your man is utterly spent."
    "Tal vez esto fue demasiado para su primera vez, piensas. Tu hombre está completamente agotado."

# game/script.rpy:8339
translate es honeymoon_8727b4ae:

    # "But it's alright."
    "Pero está bien."

# game/script.rpy:8345
translate es honeymoon_be6d38a8:

    # "After all, you have the rest of eternity to enjoy each other's company now."
    "Después de todo, ahora tienen el resto de la eternidad para disfrutar de la compañía del otros."

translate es strings:

    # game/script.rpy:282
    old "\"My tuxedo is a little hard to breathe in.\""
    new "\"Mi esmoquin me resulta un poco difícil de respirar.\""

    # game/script.rpy:282
    old "\"I'm worried about tripping on my gown.\""
    new "\"Me preocupa tropezar con mi vestido.\""

    # game/script.rpy:282
    old "\"My wedding attire is a lot to get used to.\""
    new "\"Mi atuendo de boda es mucho a lo que acostumbrarse.\""

    # game/script.rpy:550
    old "\"... someone's Groom...\""
    new "\"... el Novio de alguien...\""

    # game/script.rpy:550
    old "\"someone's Bride...\""
    new "\"la Novia de alguien...\""

    # game/script.rpy:550
    old "\"someone's Betrothed...\""
    new "\"le Prometide...\""

    # game/script.rpy:864
    old "\"Why am I here?\""
    new "\"¿Por qué estoy aquí?\""

    # game/script.rpy:864
    old "\"Who were the Gallaghers?\""
    new "\"¿Quiénes eran los Gallagher?\""

    # game/script.rpy:864
    old "\"How did the Gallaghers die?\""
    new "\"¿Cómo murieron los Gallagher?\""

    # game/script.rpy:864
    old "\"Who killed Elias Gallagher?\""
    new "\"¿Quién mató a Elias Gallagher?\""

    # game/script.rpy:864
    old "\"This feels different compared to last time.\""
    new "\"Esto se siente diferente comparado con la última vez.\""

    # game/script.rpy:864
    old "\"I think I'm all caught up.\""
    new "\"Creo que ya estoy al día.\""

    # game/script.rpy:1117
    old "\"Please calm down.\""
    new "\"Por favor, cálmate.\""

    # game/script.rpy:1117
    old "\"I'm sorry for worrying you.\""
    new "\"Perdón por preocuparte.\""

    # game/script.rpy:1643
    old "The rose"
    new "La rosa"

    # game/script.rpy:1643
    old "The zinnia"
    new "La zinnia"

    # game/script.rpy:1643
    old "The lyreflower"
    new "La flor de lira"

    # game/script.rpy:2606
    old "Inspect the deer head"
    new "Inspeccionar la cabeza de ciervo"

    # game/script.rpy:2606
    old "Inspect the clock"
    new "Inspeccionar el reloj"

    # game/script.rpy:2606
    old "Inspect the painting"
    new "Inspeccionar la pintura"

    # game/script.rpy:2606
    old "Finish looking"
    new "Terminar de mirar"

    # game/script.rpy:2780
    old "Inspect the fireplace"
    new "Inspeccionar la chimenea"

    # game/script.rpy:2780
    old "Inspect the table"
    new "Inspeccionar la mesa"

    # game/script.rpy:2780
    old "Inspect the floor lamps"
    new "Inspeccionar las lámparas de pie"

    # game/script.rpy:3224
    old "Stay in the dining room"
    new "Quedarse en el comedor"

    # game/script.rpy:3224
    old "Return to the study"
    new "Regresar al estudio"

    # game/script.rpy:3224
    old "Find Elias' bedroom"
    new "Encontrar el dormitorio de Elias"

    # game/script.rpy:4257
    old "\"What sorts of things strike your fancy?\""
    new "\"¿Qué tipo de cosas te llaman la atención?\""

    # game/script.rpy:4257
    old "\"I'm sure you'll perform well in the bedroom.\""
    new "\"Estoy seguro de que lo harás bien en el dormitorio.\""

    # game/script.rpy:4257
    old "\"I'll guide you through it.\""
    new "\"Te guiaré en ello.\""

    # game/script.rpy:4393
    old "Vanilla"
    new "Vainilla"

    # game/script.rpy:4393
    old "Earl Grey"
    new "Earl Grey"

    # game/script.rpy:4393
    old "Lemon & Lavender"
    new "Limón y Lavanda"

    # game/script.rpy:5083
    old "Choose the ring"
    new "Elegir el anillo"

    # game/script.rpy:5083
    old "Choose the necklace"
    new "Elegir el collar"

    # game/script.rpy:5083
    old "Choose the earrings"
    new "Elegir los aretes"
