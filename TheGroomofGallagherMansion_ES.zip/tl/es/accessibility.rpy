﻿# TODO: Translation updated at 2025-10-03 10:41

translate es strings:

    # game/accessibility.rpy:122
    old "Sound: "
    new "Sonido: "

    # game/accessibility.rpy:125
    old "Music: "
    new "Música: "

    # game/accessibility.rpy:161
    old "A door opens softly"
    new "Una puerta se abre suavemente"

    # game/accessibility.rpy:161
    old "A door creaks loudly"
    new "Una puerta cruje fuertemente"

    # game/accessibility.rpy:161
    old "Something falls down"
    new "Algo cae"

    # game/accessibility.rpy:161
    old "Something is moved"
    new "Algo es movido"

    # game/accessibility.rpy:161
    old "A classic spooky theremin sound"
    new "Un clásico sonido espeluznante de theremín"

    # game/accessibility.rpy:161
    old "A revelation"
    new "Una revelación"

    # game/accessibility.rpy:161
    old "A hard slap"
    new "Una bofetada fuerte"

    # game/accessibility.rpy:161
    old "A door opens"
    new "Una puerta se abre"

    # game/accessibility.rpy:161
    old "Knocking on a surface"
    new "Golpes sobre una superficie"

    # game/accessibility.rpy:161
    old "Something is hit hard"
    new "Algo es golpeado con fuerza"

    # game/accessibility.rpy:161
    old "Cloth being shifted around"
    new "Tela siendo movida"

    # game/accessibility.rpy:161
    old "Creaking of old wood"
    new "Crujido de madera vieja"

    # game/accessibility.rpy:161
    old "The beating of a heart"
    new "El latido de un corazón"

    # game/accessibility.rpy:161
    old "An unwanted visitor appears"
    new "Aparece un visitante no deseado"

    # game/accessibility.rpy:161
    old "Static interference"
    new "Interferencia estática"

    # game/accessibility.rpy:161
    old "The laughter of a dead woman"
    new "La risa de una mujer muerta"

    # game/accessibility.rpy:161
    old "Papers being flipped through"
    new "Hojas siendo hojeadas"

    # game/accessibility.rpy:161
    old "Whispers of a crowd"
    new "Susurros de una multitud"

    # game/accessibility.rpy:161
    old "A loud crash"
    new "Un fuerte estruendo"

    # game/accessibility.rpy:161
    old "Crickets chirping"
    new "Grillos cantando"

    # game/accessibility.rpy:161
    old "The ceiling cracks"
    new "El techo se agrieta"

    # game/accessibility.rpy:161
    old "The ceiling falls down"
    new "El techo se derrumba"

    # game/accessibility.rpy:161
    old "A phone battery losing power"
    new "Batería del teléfono perdiendo energía"

    # game/accessibility.rpy:161
    old "A round of applause"
    new "Un aplauso"

    # game/accessibility.rpy:207
    old "A bouncy, spooky theme song"
    new "Una canción temática animada y espeluznante"

    # game/accessibility.rpy:207
    old "A quiet, slow piano song"
    new "Una canción de piano lenta y tranquila"

    # game/accessibility.rpy:207
    old "The theme of Taylor"
    new "La temática de Taylor"

    # game/accessibility.rpy:207
    old "The theme of Elias"
    new "La temática de Elias"

    # game/accessibility.rpy:207
    old "A nostalgic music box melody"
    new "Una melodía nostálgica de caja musical"

    # game/accessibility.rpy:207
    old "A creepy atmospheric ambience"
    new "Un ambiente espeluznante y atmosférico"

    # game/accessibility.rpy:207
    old "The Wedding March"
    new "La Marcha Nupcial"

    # game/accessibility.rpy:207
    old "Distorted Static"
    new "Estática distorsionada"

