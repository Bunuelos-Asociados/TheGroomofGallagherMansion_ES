﻿# TODO: Translation updated at 2025-10-03 10:4

translate es strings:

# game/research.rpy:79
    old """Taylor Potts — My best friend and the President of the OHSIC. He's a huge nerd and makes me do his dirty work."""
    new """Taylor Potts — Mi mejor amigo y el presidente del OHSIC. Es un gran nerd y me hace hacer su trabajo sucio."""

# game/research.rpy:80
    old """OHSIC — AKA the Occult History & Sciences Investigation Club. I'm the only other consistent member."""
    new """OHSIC — También conocido como el Club de Investigación de Historia y Ciencias Ocultas. Soy el único otro miembro constante."""

# game/research.rpy:81
    old """Elias Gallagher — The famous last heir of the Gallagher family. Rumors say he haunts the old mansion on the hill..."""
    new """Elias Gallagher — El famoso último heredero de la familia Gallagher. Los rumores dicen que ronda la vieja mansión en la colina..."""

# game/research.rpy:83
    old """The Mission — I'm here to investigate Gallagher Mansion and prove that ghosts exist. Mission accomplished?"""
    new """La Misión — Estoy aquí para investigar la Mansión Gallagher y demostrar que los fantasmas existen. ¿Misión cumplida?"""

# game/research.rpy:84
    old """The Gallaghers — A European military family whose patriarch became a rich cornmeal baron and came to wealth in America."""
    new """Los Gallagher — Una familia militar europea cuyo patriarca se convirtió en un rico barón del maíz y alcanzó la riqueza en América."""

# game/research.rpy:85
    old """The \"Curse\" — The entire family died off in a series of unrelated deaths, and no one is sure {i}why{/i} that happened."""
    new """La \"Maldición\" — Toda la familia murió en una serie de muertes no relacionadas, y nadie sabe con certeza {i}por qué{/i} sucedió eso."""

# game/research.rpy:86
    old """Gerard Dupont — The Gallagher family's groundskeeper, and the brother of Violet."""
    new """Gerard Dupont — El jardinero de la familia Gallagher y hermano de Violet."""

# game/research.rpy:87
    old """Violet Dupont — Gerard's sister, who he introduced as a fellow heiress for Elias to marry."""
    new """Violet Dupont — Hermana de Gerard, a quien presentó como otra heredera para que Elias se casara con ella."""

# game/research.rpy:88
    old """Elias' Death — The Duponts tricked Elias and murdered him the night before his planned wedding. How tragic..."""
    new """La Muerte de Elias — Los Dupont engañaron a Elias y lo asesinaron la noche antes de su boda planeada. Qué trágico..."""


# game/research.rpy:90
    old """Mildred Gallagher — The Gallagher matriarch and host of many a tea party. She loved to show off the family jewels."""
    new """Mildred Gallagher — La matriarca de los Gallagher y anfitriona de muchas fiestas de té. Le encantaba mostrar las joyas de la familia."""

# game/research.rpy:91
    old """Archibald Gallagher — The Gallagher patriarch and ruthless cornmeal baron. He was not a very pleasant person."""
    new """Archibald Gallagher — El patriarca de los Gallagher y despiadado barón del maíz. No era una persona muy agradable."""

# game/research.rpy:92
    old """Mirror Shards — Elias kept some of these in an ornate box... but why? Were these important to him?"""
    new """Fragmentos de Espejo — Elias guardaba algunos de estos en una caja ornamentada... pero ¿por qué? ¿Eran importantes para él?"""

# game/research.rpy:94
    old "Deformidad Congénita — Una condición donde ocurren anomalías estructurales o funcionales durante la vida intrauterina. En el caso de Elias, esto resultó en dedos faltantes, lo que dificultaba que caminara sin un bastón durante su vida."
    new "Deformidad Congénita — Una condición donde ocurren anomalías estructurales o funcionales durante la vida intrauterina. En el caso de Elias, esto resultó en dedos faltantes, lo que dificultaba que caminara sin un bastón durante su vida."

# game/research.rpy:95
    old """Congenital Deformity — A condition where structural or functional anomalies occur during intrauterine life. In Elias' case, this resulted in missing toes, which made it difficult for him to walk without a cane during his life."""
    new """Esclerosis Múltiple — Una enfermedad potencialmente discapacitante del cerebro y la médula espinal que puede causar fatiga, espasmos musculares, problemas de movilidad y dolor, entre otros síntomas. A veces se clasifica como enfermedad del nervio y del sistema nervioso y actualmente es incurable."""

# game/research.rpy:97
    old """Taylor's Parents — He confessed that he had a rough childhood when we got wasted at a house party this one time, away from everyone else. The divorce was a long and drawn out process, mostly because neither of his parents could afford the fees associated with it."""
    new """Los Padres de Taylor — Confesó que tuvo una infancia difícil cuando nos embriagamos en una fiesta en una casa una vez, lejos de todos los demás. El divorcio fue un proceso largo y prolongado, principalmente porque ninguno de sus padres podía costear los honorarios asociados."""

# game/research.rpy:98
    old """The Truth Behind The \"Curse\" — The curse that killed the entire Gallagher clan, sans Elias, began when an antique hand mirror meant as a wedding gift shattered one day when Elias was younger. As the mirror was never repaired and never served its purpose, it caused the death of each Gallagher child, and eventually the parents themselves."""
    new """La Verdad Detrás de la \"Maldición\" — La maldición que mató a todo el clan Gallagher, salvo a Elias, comenzó cuando un espejo de mano antiguo destinado como regalo de bodas se rompió un día cuando Elias era más joven. Como el espejo nunca se reparó y nunca cumplió su propósito, causó la muerte de cada niño Gallagher, y eventualmente de los padres mismos."""
